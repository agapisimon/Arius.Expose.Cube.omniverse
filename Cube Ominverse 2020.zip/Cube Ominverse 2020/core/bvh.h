#ifndef BVH_H
#define BVH_H

#include<QtOpenGL>
#include <vector>
#include <map>
#include <string>

using namespace  std;

class  BVH
{
  public:

    enum  ChannelEnum
    {
        X_ROTATION, Y_ROTATION, Z_ROTATION,

        X_POSITION, Y_POSITION, Z_POSITION
    };

    struct  Joint;
    struct  Channel
    {
        int  index;
        Joint * joint;
        ChannelEnum type;
    };

    struct  Joint
    {
        bool has_site;
        string name;
        int  index;
        Joint * parent;

        vector< Joint * > children;
        vector< Channel * > channels;

        double offset[3];
        double  site[3];
    };


  private:

    bool  is_load_success;
    string file_name;
    string motion_name;

    vector< Channel * >channels;
    vector< Joint * >joints;
    map< string, Joint * > joint_index;

    int  num_channel;
    int num_frame;
    double interval;
    double *  motion;


  public:

    BVH();
    BVH( const char * bvh_file_name );
    ~BVH();


    void  Clear();
    void  Load( const char * bvh_file_name );

  public:

    bool  IsLoadSuccess() const { return is_load_success; }
    const string &  GetFileName() const { return file_name; }
    const string &  GetMotionName() const { return motion_name; }
    const int       GetNumJoint() const { return  joints.size(); }
    const Joint *   GetJoint( int no ) const { return  joints[no]; }
    const int       GetNumChannel() const { return  channels.size(); }
    const Channel * GetChannel( int no ) const { return  channels[no]; }

    const Joint *   GetJoint( const string & j ) const
    {
        map< string, Joint * >::const_iterator  i = joint_index.find( j );
        return  ( i != joint_index.end() ) ? (*i).second : NULL;
    }

    const Joint *   GetJoint( const char * j ) const
    {
        map< string, Joint * >::const_iterator  i = joint_index.find( j );
        return  ( i != joint_index.end() ) ? (*i).second : NULL;
    }


    int     GetNumFrame() const { return  num_frame; }
    double  GetInterval() const { return  interval; }
    double  GetMotion( int f, int c ) const { return  motion[ f*num_channel + c ]; }


    void  SetMotion( int f, int c, double v ) { motion[ f*num_channel + c ] = v; }

  public:

    void  RenderFigure( int frame_no, float scale = 1.0f );
    static void  RenderFigure( const Joint * root, const double * data, float scale = 1.0f );
    static void  RenderBone( float x0, float y0, float z0, float x1, float y1, float z1 );
};


class BVHImporter
{
public:

    bool   on_animation = true;
    float  animation_time = 0.0f;
    int    frame = 0;
    BVH *   bvh = NULL;

    BVHImporter()
    {
       import();
    }

    void import()
    {
        qDebug()<<"Importing BVH file";
        char  file_name[ 256 ] = "D:\QT docs\Cube Omiverse C++ version 1 - QT 4.8.6\Cube\bvh\idles.bvh";

        bvh = new BVH(file_name );

        if ( !bvh->IsLoadSuccess() )
        {
            delete  bvh;
            bvh = NULL;
        }

        animation_time = 0.0f;
        frame = 1;

    }

    void  drawBVH()
    {


        if (bvh)
            bvh->RenderFigure( frame, 0.02f );

        if(frame<bvh->GetNumFrame())
            frame+=1;
        else
            frame = 1;
        /*

        char  message[ 64 ];

        if ( bvh )
            sprintf( message, "%.2f (%d)", animation_time, frame_no );
        else
            sprintf( message, "Press 'L' key to Load a BVH file" );
            */

    }


    void  idle( void )
    {

        if ( on_animation )
        {

            static DWORD  last_time = 0;
            DWORD  curr_time = timeGetTime();

            float  delta = ( curr_time - last_time ) * 0.001f;

            if ( delta > 0.03f )
                delta = 0.03f;

            last_time = curr_time;

            animation_time += delta;



            if ( bvh )
            {
                frame = animation_time / bvh->GetInterval();
                frame = frame % bvh->GetNumFrame();
            }
            else
                frame = 0;

        }
    }

    void  keyboard( unsigned char key, int mx, int my )
    {

        if ( key == 's' )
            on_animation = !on_animation;

        if ( ( key == 'n' ) && !on_animation )
        {
            animation_time += bvh->GetInterval();
            frame ++;
            frame = frame % bvh->GetNumFrame();
        }


        if ( ( key == 'p' ) && !on_animation && ( frame > 0 ) && bvh )
        {
            animation_time -= bvh->GetInterval();
            frame --;
            frame = frame % bvh->GetNumFrame();
        }


        if ( key == 'r' )
        {
            animation_time = 0.0f;
            frame = 0;
        }
    }

};

#endif // BVH_H
