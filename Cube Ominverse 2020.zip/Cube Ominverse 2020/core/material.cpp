#include "material.h"

Material1::Material1()
{

}

