#ifndef MATH_H
#define MATH_H

#include<qmath.h>
#include<QtWidgets>
#include<QtOpenGL>
#include<GL/glu.h>
#include<glm/glm.hpp>

// something small to avoid division overflow but the granularity is to small to be detected in the OpenGL modelview matrix elements
//#define EPSILON 1.0e-8
#define EPSILON 2.5e-8 // something still very small to avoid division overflow but now also big enough to detect OpenGL modelview matrix elements
#define ZERO EPSILON

class Sphere
{
public:
    QVector3D center;
    qreal radius;
};


class Triangle
{
public:
    QVector3D p1;
    QVector3D p2;
    QVector3D p3;
    int index1;
    int index2;
    int index3;

};

class Quad
{
public:
    QVector3D p1;
    QVector3D p2;
    QVector3D p3;
    QVector3D p4;

    int index1;
    int index2;
    int index3;
    int index4;
};


// axes/plane to transform scene contents in
enum TRANSFORMAXES
{
    XTRANS,
    YTRANS,
    ZTRANS,
    XYTRANS,
    ZXTRANS,
    YZTRANS,
};

//Plane defined by a point and a normal
//The normal and point are expressed in non-opengl 3D cartesian co-ordinates.
//where the Z axis in vertical. In OpenGL the Y axis is vertical.

class Plane
{
public:
    glm::vec3 position;
    glm::vec3 center;
    glm::vec3 normal;
    DWORD axesAlignment;

    Plane()
    {
       normal = glm::vec3(0,0,0);
       position = glm::vec3(0,0,0);
    }

    Plane(glm::vec3 norm,glm::vec3 pos, DWORD axes)
    {
       normal = glm::vec3(norm.x,norm.y,norm.z);
       position = glm::vec3(pos.x,pos.y,pos.z);
       axesAlignment = axes;
   }



   void DrawNormal()
   {
       glDisable(GL_LIGHTING);
       glEnable(GL_LINE_SMOOTH);
       glDisable( GL_TEXTURE_2D );
       glLineWidth(2.0);
       glBegin(GL_LINES);
       glColor3f(1.0f,1.0f,0.0f);
       glVertex3f(position.x,position.z,position.y);
       glVertex3f(normal.x*10+position.x,normal.z*10+position.z,normal.y*10+position.y);
       glEnd();
       glEnable(GL_LIGHTING);
       glDisable(GL_LINE_SMOOTH);
       glEnable( GL_TEXTURE_2D );
   }

   void Draw()
   {
       glDisable(GL_LIGHTING);
       glEnable(GL_LINE_SMOOTH);
       glDisable( GL_TEXTURE_2D );
       glEnable(GL_COLOR_MATERIAL);
       glLineWidth(1.0);
       //glColor3f(1.0f,0.0f,0.0f);

       float size = 5.0f;
       // xy plane default
       float x = position.x;
       float y = position.z;
       float z = position.y;
       glPushMatrix();

       if(axesAlignment == XYTRANS)
       {
          x = position.x;
          y = position.z;
          z = position.y;
       }
       else if(axesAlignment == ZXTRANS)
       {
           glRotatef(90.0f,1.0f,0.0f,0.0f);



           x = position.x;
           y = position.y;
           z = -position.z;
       }
       else if(axesAlignment == YZTRANS)
       {
           glRotatef(-90.0f,0.0f,0.0f,1.0f);
           x = -position.z;
           y = position.x;
           z = position.y;
       }

       glEnable(GL_BLEND);
       glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
       glColor4f(1.0f,0.0f,1.0f,0.2f);
       glBegin(GL_QUADS);
         glVertex3f(x-size,y,z-size);
         glVertex3f(x-size,y,z+size);
         glVertex3f(x+size,y,z+size);
         glVertex3f(x+size,y,z-size);
       glEnd();
       glDisable(GL_BLEND);

       glColor3f(1.0f,0.0f,0.0f);

       glBegin(GL_LINES);
          glVertex3f(x-size,y,z-size);
          glVertex3f(x-size,y,z+size);
          glVertex3f(x+size,y,z-size);
          glVertex3f(x+size,y,z+size);
          glVertex3f(x-size,y,z-size);
          glVertex3f(x+size,y,z-size);
          glVertex3f(x-size,y,z+size);
          glVertex3f(x+size,y,z+size);
       glEnd();


       glPopMatrix();

       glEnable(GL_LIGHTING);
       glDisable(GL_LINE_SMOOTH);
       glEnable( GL_TEXTURE_2D );

   }
   void set(DWORD value)
   {
       axesAlignment = value;
   }

   DWORD AxesAlignment()
   {
       return axesAlignment;
   }
};


//===========================================================================================
//	Ray defined by 2 points (can we call it a segment?)
//
//	The 2 points p0 and p1 are expressed in non-opengl cartesian co-ordinates.
//	where the Z axis in vertical. In opengl the screen and the Y axis is vertical.
//===========================================================================================

class Ray
{

public:
    glm::vec3 p0;
    glm::vec3 p1;

    Ray()
    {
        p0 = glm::vec3(0,0,0);
        p1 = glm::vec3(0,0,0);
    }

    Ray(glm::vec3 P0,glm::vec3 P1)
    {
        p0 = glm::vec3();
        p1 = glm::vec3();

        p0.x = P0.x;
        p0.y = P0.y;
        p0.z = P0.z;
        p1.x = P1.x;
        p1.y = P1.y;
        p1.z = P1.z;

    }

    Ray(int x2D, int y2D)
    {
        p0 = glm::vec3();
        p1 = glm::vec3();
        Generate3DRay(x2D, y2D);
    }

    void Generate3DRay(int x2D, int y2D)
    {
        //if(p0 == nullptr)
            p0 = glm::vec3();
        //if(p1 == nullptr)
            p1 = glm::vec3();

        int x =x2D;
        int y =y2D;

        GLint viewport[4];
        GLdouble modelview[16];
        GLdouble projection[16];
        GLdouble winX, winY;
        GLdouble winZ0 = 0.0f; GLdouble winZ1 = 1.0f;
        GLdouble posX0, posY0, posZ0;
        GLdouble posX1, posY1, posZ1;

        glGetDoublev(GL_MODELVIEW_MATRIX, modelview);
        glGetDoublev(GL_PROJECTION_MATRIX, projection);
        glGetIntegerv(GL_VIEWPORT, viewport);

        winX = (GLdouble)x;
        winY = (GLdouble)viewport[3] - (GLdouble)y;

        glReadBuffer( GL_BACK );

        gluUnProject( winX, winY, winZ0, modelview, projection, viewport, &posX0, &posY0, &posZ0);
        gluUnProject( winX, winY, winZ1, modelview, projection, viewport, &posX1, &posY1, &posZ1);
        // flip opengl co-ordinates to flight simulator co-ordinates
        p0.x = (float)posX0;
        p0.y = (float)posZ0;
        p0.z = (float)posY0;
        //
        p1.x = (float)posX1;
        p1.y = (float)posZ1;
        p1.z = (float)posY1;
    }

    //=======================================================
    // Intersects(): intersect a segment and a plane
    //    Input:  p = a plane
    //    Output: I = the intersection point (when it exists)
    //    Return: 0 = disjoint (no intersection)
    //            1 = intersection in the unique point I
    //            2 = the segment lies in the plane

    //		- the plane is in flight simulator co-ordinate system form, where the Z axis in vertical
    //		  (whereas in OpenGL the Y axis is vertical ).
    //
    //=======================================================
    int Intersects(Plane p, glm::vec3 I)
    {
        glm::vec3 intersectPoint;

        glm::vec3 u = p1 - p0;
        glm::vec3 w = p0 - p.position;



        float     D = glm::dot(p.normal,u);
        float     N = glm::dot(-p.normal,w);

        if (abs(D) < ZERO)			// segment is parallel to plane
        {
            if (N == 0)                     // segment lies in plane
                return 2;
            else
                return 0;                   // no intersection
        }

        float s = N / D;
        if (s < 0 || s > 1)
            return 0;                       // no intersection

        intersectPoint = p0 + u*s;         // compute segment intersect point

        I.x  = intersectPoint.x;
        I.y  = intersectPoint.y;
        I.z  = intersectPoint.z;

        return 1;
    }

};


//This class controls how the mouse translates objects in an opengl 3D space
//However, it currently has one very specific use:
//It finds (mouse)ray-(axis aligned)plane intersections points.
//When an intersection point is generated it is modified based on the
//translation constraint then stored in the position member variable.
//It is more of a RayPlaneIntersectionPointFinder
//than anything else at the moment( and could/should be renamed as such?).

//Vectors and points in 3D space given to this class to manipulate must conform to the flight simulator
//co-ordinate system and not the OpenGL co-ordinate system. The difference is: The Z axis is vertical in
//a flight simulator; where the Y axis is vertical in OpenGL rendering.

class MouseTranslationController
{
private:

    Ray ray;
    Plane plane;
    glm::vec3 position;				// the resulting translation position
    DWORD translationConstraint;	// The plane or axis that translation is constrained to

    glm::vec3 displacement;
    static glm::vec3 lastposition;

protected:

    void CreatePlane()
    {
        glm::vec3 pt = glm::vec3(0.0f,0.0f,0.0f);
        glm::vec3 normXY = glm::vec3(0.0f,0.0f,1.0f);
        plane =  Plane(normXY,pt,XYTRANS);
    }

    void CreateRay(int x2D, int y2D)
    {
        ray.Generate3DRay(x2D, y2D);
    }

    void SetPlaneOrientation(DWORD theTranslationConstraint )
    {

        if(theTranslationConstraint == XTRANS )
        {
            glm::vec3 n = glm::vec3();

            n = ray.p0-ray.p1;

            plane.axesAlignment = XYTRANS;

            plane.normal.x = 0;
            plane.normal.y = n.y;
            plane.normal.z = n.z;
        }
        else if(theTranslationConstraint == YTRANS)
        {
            glm::vec3 n = glm::vec3();
            n = ray.p0-ray.p1;
            plane.axesAlignment = XYTRANS;
            plane.normal.x = n.x;
            plane.normal.y = 0;
            plane.normal.z = n.z;
        }
        else if(theTranslationConstraint == ZTRANS)
        {
            glm::vec3 n = glm::vec3();
            n = ray.p0-ray.p1;
            plane.axesAlignment = ZXTRANS;
            plane.normal.x = n.x;
            plane.normal.y = n.y;
            plane.normal.z = 0;
        }
        else if(theTranslationConstraint == ZXTRANS )
        {
            plane.axesAlignment = ZXTRANS;
            plane.normal.x = 0.0f;
            plane.normal.y = 1.0f;
            plane.normal.z = 0.0f;
        }
        else if(theTranslationConstraint == YZTRANS)
        {
            plane.axesAlignment = YZTRANS;
            plane.normal.x = 1.0f;
            plane.normal.y = 0.0f;
            plane.normal.z = 0.0f;
        }
        else//if(TransformAxes == XYTRANS
        {
            plane.axesAlignment = XYTRANS;
            plane.normal.x = 0.0f;
            plane.normal.y = 0.0f;
            plane.normal.z = 1.0f;
        }

    }

    void InitializePlane(DWORD theTranslationConstaint)
    {
        // Check for the special case when the viewing plane is orthogonal to the virtual plane
        // and re-align the virtual plane to be in a parallel axis alignment to it.

        GLdouble modelview[16];
        glGetDoublev(GL_MODELVIEW_MATRIX, modelview);

        DWORD newPlaneAlignment = theTranslationConstaint;
        DWORD newTranslationContraint = theTranslationConstaint;

        if((modelview[6] <  1.0f+EPSILON && modelview[6] >  1.0f-EPSILON)	// top view
        || (modelview[6] < -1.0f+EPSILON && modelview[6] > -1.0f-EPSILON))	// bottom view
        {
            if(theTranslationConstaint == ZXTRANS || theTranslationConstaint == XTRANS)
            {
                newPlaneAlignment = XYTRANS;
                newTranslationContraint = XTRANS;
            }
            else if(theTranslationConstaint == YZTRANS || theTranslationConstaint == YTRANS)
            {
                newPlaneAlignment = XYTRANS;
                newTranslationContraint = YTRANS;
            }
        }
        else if((modelview[6] <  0.0f+EPSILON && modelview[6] >  0.0f-EPSILON))//No pitch front/back/right/left
        {
            if((modelview[8] <= 0.7071f && modelview[8] >= -0.7071f)) //front or back view
            {
                if(theTranslationConstaint == XYTRANS || theTranslationConstaint == XTRANS)
                {
                    newPlaneAlignment = ZXTRANS;
                    newTranslationContraint = XTRANS;
                }
                else if(theTranslationConstaint == YZTRANS || theTranslationConstaint == ZTRANS)
                {
                    newPlaneAlignment = ZXTRANS;
                    newTranslationContraint = ZTRANS;
                }

            }
            else if((modelview[8] <= -0.7071f || modelview[8] >= 0.7071f))// left view // right view
            {
                if(theTranslationConstaint == XYTRANS || theTranslationConstaint == YTRANS)
                {
                    newPlaneAlignment = YZTRANS;
                    newTranslationContraint = YTRANS;
                }
                else if(theTranslationConstaint == ZXTRANS || theTranslationConstaint == ZTRANS)
                {
                    newPlaneAlignment = YZTRANS;
                    newTranslationContraint = ZTRANS;
                }
            }

        }

        SetPlaneOrientation(newPlaneAlignment);
        translationConstraint = newTranslationContraint;

    }

    void ApplyTranslationConstraint(glm::vec3 intersectPos)
    {
        if(translationConstraint == XTRANS)
        {
            position.x= intersectPos.x;
        }
        else if(translationConstraint == YTRANS )
        {
            position.y = intersectPos.y;
        }
        else if(translationConstraint == ZTRANS )
        {
            position.z = intersectPos.z;
        }
        else
        {
            position.x = intersectPos.x;
            position.z = intersectPos.z;
            position.y = intersectPos.y;
        }
    }

    glm::vec3 setPosition(glm::vec3 pos)
    {
            position.x = pos.x;
            position.y = pos.y;
            position.z = pos.z;
    }


    glm::vec3 getPosition()
    {


         return position;
    }

    glm::vec3 setLastPosition(glm::vec3 pos)
    {
       lastposition.x = pos.x;
       lastposition.y = pos.y;
       lastposition.z = pos.z;
    }

    glm::vec3 getLastPosition()
    {
        return lastposition;
    }

    void setPlanePosition(glm::vec3 pos)
    {
            plane.position.x = pos.x;
            plane.position.y = pos.y;
            plane.position.z = pos.z;
    }

    glm::vec3 PlanePosition()
    {
       return plane.position;
    }

    DWORD TranslationConstraint()
    {
        return translationConstraint;
    }

    void setTranslationConstraint(DWORD value)
    {
        translationConstraint = value;
    }

public:

    MouseTranslationController()
    {
        translationConstraint = XYTRANS;
        position = glm::vec3(0.0f,0.0f,0.0f);
        ray = Ray();
        CreatePlane();
        displacement = glm::vec3(0.0f,0.0f,0.0f);
        lastposition = glm::vec3(0.0f,0.0f,0.0f);

    }


    //Initialize the ray, virtual plane, ray-plane
    //intersection point and displacement vector.
    //params
    //int x2D, int y2D: the 2D mouse cursor position in a viewport panel
    //DWORD theTranslationConstraint: A flag Indicating the plane or axis that translation is constrained to ( X, Y, Z, XY, ZX or ZY).
    //glm::vec3 planePos: 3D position picked on the object as it was selected. Object translation starts from this point.


    void Initialize(int x2D, int y2D,DWORD theTranslationConstraint, glm::vec3 planePos)
    {
        ray.Generate3DRay(x2D, y2D);
        setPlanePosition(planePos);
        setPosition(planePos);
        setLastPosition(position);
        setDisplacement( glm::vec3());
        InitializePlane(theTranslationConstraint);
    }

    void Update(int x2D, int y2D)
    {
        glm::vec3 intersection = glm::vec3();
        ray.Generate3DRay(x2D, y2D);
        ray.Intersects(plane,intersection);
        ApplyTranslationConstraint(intersection);
        setPlanePosition(position);
        setDisplacement(position - lastposition);
        setLastPosition(position);
    }

    void DrawPlane()
    {

        if(translationConstraint == XYTRANS || translationConstraint == ZXTRANS || translationConstraint == YZTRANS)
        {
            plane.DrawNormal();
            plane.Draw();
        }
    }

    void setDisplacement(glm::vec3 pos)
    {
            displacement.x = pos.x;
            displacement.y = pos.y;
            displacement.z = pos.z;
    }


    glm::vec3 getDisplacement()
    {
         return displacement;
    }

};












#endif // MATH_H
