#include "sound.h"

Sound::Sound()
{

}

