#include <core/camera.h>
/*
cameraObject::cameraObject()
{
   resetCameraProperties();

   sensitivity = 25;

   vertices.append(QVector3D(0.6536, 1.0, 1.0));
   vertices.append(QVector3D(0.6536, 1.0, -1.0));//1
   vertices.append(QVector3D(0.6536, -1.0, 1.0));//2
   vertices.append(QVector3D(0.6536, -1.0, -1.0));//3
   vertices.append(QVector3D(-0.6536, 1.0, 1.0));//4
   vertices.append(QVector3D(-0.6536, 1.0, -1.0));//5
   vertices.append(QVector3D(-0.6536, -1.0, 1.0));//6
   vertices.append(QVector3D(-0.6536, -1.0, -1.0));//7
   vertices.append(QVector3D(0.5277, 1.0, 0.5277));//8
   vertices.append(QVector3D(0.5277, 1.0, -0.5277));//9
   vertices.append(QVector3D(-0.5277, 1.0, 0.5277));//10
   vertices.append(QVector3D(-0.5277, 1.0, -0.5277));//11
   vertices.append(QVector3D(0.5277, 2.4265, 0.5277));//12
   vertices.append(QVector3D(0.5277, 2.4265, -0.5277));//13
   vertices.append(QVector3D(-0.5277, 2.4265, 0.5277));//14
   vertices.append(QVector3D(-0.5277, 2.4265, -0.5277));//15
   vertices.append(QVector3D(-0.5277, 2.2400, -0.5277));//16
   vertices.append(QVector3D(-0.5277, 2.2400, 0.5277));//17
   vertices.append(QVector3D(0.5277, 2.2400, -0.5277));//18
   vertices.append(QVector3D(0.5277, 2.2400, 0.5277));//19
   vertices.append(QVector3D(0.3502, 2.4265, 0.3502));//20
   vertices.append(QVector3D(0.3502, 2.4265, -0.3502));//21
   vertices.append(QVector3D(-0.3502, 2.4265, 0.3502));//22
   vertices.append(QVector3D(-0.3502, 2.4265, -0.3502));//23
   vertices.append(QVector3D(-0.4780, -1.0, -0.7313));//24
   vertices.append(QVector3D(0.4780, -1.0, -0.7313));//25
   vertices.append(QVector3D(0.4780, -1.0, 0.7313));//26
   vertices.append(QVector3D(-0.4780, -1.0, 0.7313));//27
   vertices.append(QVector3D(-0.4375, -1.3223, -0.6694));//28
   vertices.append(QVector3D(0.4375, -1.3223, -0.6694));//29
   vertices.append(QVector3D(0.4375, -1.3223, 0.6694));//30
   vertices.append(QVector3D(-0.4375, -1.3223, 0.6694));//31


   edges.append(QPair<int,int>(7,3));
   edges.append(QPair<int,int>(3,1));
   edges.append(QPair<int,int>(2,3));
   edges.append(QPair<int,int>(2,6));
   edges.append(QPair<int,int>(0,2));
   edges.append(QPair<int,int>(0,1));
   edges.append(QPair<int,int>(4,0));
   edges.append(QPair<int,int>(5,7));
   edges.append(QPair<int,int>(1,5));
   edges.append(QPair<int,int>(6,4));
   edges.append(QPair<int,int>(7,6));
   edges.append(QPair<int,int>(4,5));
   edges.append(QPair<int,int>(8,9));
   edges.append(QPair<int,int>(10,8));
   edges.append(QPair<int,int>(9,11));
   edges.append(QPair<int,int>(10,11));
   edges.append(QPair<int,int>(1,9));
   edges.append(QPair<int,int>(8,0));
   edges.append(QPair<int,int>(10,4));
   edges.append(QPair<int,int>(5,11));
   edges.append(QPair<int,int>(12,13));
   edges.append(QPair<int,int>(14,12));
   edges.append(QPair<int,int>(13,15));
   edges.append(QPair<int,int>(14,15));
   edges.append(QPair<int,int>(16,11));
   edges.append(QPair<int,int>(17,14));
   edges.append(QPair<int,int>(18,9));
   edges.append(QPair<int,int>(19,12));
   edges.append(QPair<int,int>(15,16));
   edges.append(QPair<int,int>(10,17));
   edges.append(QPair<int,int>(13,18));
   edges.append(QPair<int,int>(8,19));
   edges.append(QPair<int,int>(18,19));
   edges.append(QPair<int,int>(19,17));
   edges.append(QPair<int,int>(16,18));
   edges.append(QPair<int,int>(17,16));
   edges.append(QPair<int,int>(20,21));
   edges.append(QPair<int,int>(22,20));
   edges.append(QPair<int,int>(21,23));
   edges.append(QPair<int,int>(22,23));
   edges.append(QPair<int,int>(13,21));
   edges.append(QPair<int,int>(20,12));
   edges.append(QPair<int,int>(22,14));
   edges.append(QPair<int,int>(15,23));
   edges.append(QPair<int,int>(24,25));
   edges.append(QPair<int,int>(26,25));
   edges.append(QPair<int,int>(26,27));
   edges.append(QPair<int,int>(24,27));
   edges.append(QPair<int,int>(3,25));
   edges.append(QPair<int,int>(24,7));
   edges.append(QPair<int,int>(2,26));
   edges.append(QPair<int,int>(6,27));
   edges.append(QPair<int,int>(28,29));
   edges.append(QPair<int,int>(30,29));
   edges.append(QPair<int,int>(30,31));
   edges.append(QPair<int,int>(28,31));
   edges.append(QPair<int,int>(31,27));
   edges.append(QPair<int,int>(24,28));
   edges.append(QPair<int,int>(30,26));
   edges.append(QPair<int,int>(29,25));
}
*/
