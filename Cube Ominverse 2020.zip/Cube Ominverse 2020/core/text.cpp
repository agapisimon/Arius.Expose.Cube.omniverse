#include "text.h"

Text::Text(QString str)
{
    text = str;

    color = QColor(Qt::white);

    pos = QVector3D(0,1,0);

}

