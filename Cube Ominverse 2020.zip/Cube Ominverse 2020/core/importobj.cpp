#include "importobj.h"
/*
    Face Elements
    Faces are defined using lists of vertex,
    texture and normal indices. Polygons such
    as quadrilaterals can be defined by using
    more than three vertex/texture/normal indices.

token: f <Vertex index>
    f v1 v2 v3 ....
    Vertex Indices
    A valid vertex index starts from 1 and
    matches the corresponding vertex elements
    of a previously defined vertex list.
    Each face can contain three or more vertices.


token:  f <Vertex index/ Texture Coordinate index>
        f v1/vt1 v2/vt2 v3/vt3 ...
    Optionally, texture coordinate indices can
    be used to specify texture coordinates when
    defining a face. To add a texture coordinate
    index to a vertex index when defining a face,
    one must put a slash immediately after the vertex
    index and then put the texture coordinate index.
    No spaces are permitted before or after the slash.
    A valid texture coordinate index starts from 1 and
    matches the corresponding element in the previously
    defined list of texture coordinates. Each face can
    contain three or more elements.



token:  f <Vertex index/ Normal index>
        f v1/vt1/vn1 v2/vt2/vn2 v3/vt3/vn3 ....

    Vertex Normal Indices Optionally, normal indices can
    be used to specify normal vectors for vertices when defining a face.
    To add a normal index to a vertex index when defining a face, one must
     put a second slash after the texture coordinate index and then put the
    normal index. A valid normal index starts from 1 and matches the corresponding element
    in the previously defined list of normals. Each face can contain three or more elements.



token: f <Vertex index/ Normal index>
     f v1//vn1 v2//vn2 v3//vn3 ...


    Vertex Normal Indices Without Texture Coordinate Indices
    As texture coordinates are optional,
    one can define geometry without them,
    but one must put two slashes after the vertex
    index before putting the normal index.
*/
/*
char const* Obj::parseCorner(char const* buf,tagTriangle  face,int i)
{
    qDebug()<<"parseCorner:"<<buf;

    int v, t, n ;

    v=t=n = 0;

    //handle all four cases of the format

    //scan v/t/n    case1
    handle = sscanf(buf, "%d/%d/%d ", &v, &t, &n);
    if ( handle != 1)
    {
       handlecase = 1;
       qDebug()<<"Handle:"<<handle;
       goto end;
    }

    //scan  v/t case2
    handle = sscanf(buf, "%d/%d ", &v, &t);
    if(handle != 1)
    {
        handlecase = 2;
        qDebug()<<"Handle:"<<handle;

        goto end;
    }

    //scan  v//n case3
    handle = sscanf(buf, "%d//%d " , &v,&n);
    if(handle != 1)
    {
        handlecase =3;
        qDebug()<<"Handle:"<<handle;
        goto end;
    }

    //scan  v   case4
    handle=sscanf(buf, "%d " , &v);
    if(handle != 1)
    {
        handlecase = 4;
        qDebug()<<"Handle:"<<handle;
        goto end;
    }



    //sscanf(buf,"%*d//%d", &v);


        //qDebug()<<"last v:"<<v;


    end:
    //v=t=n = NULL;

    switch(handlecase)
    {
    case 1://scan v/t/n    case1
        sscanf(buf, "%d/%d/%d ", &v, &t, &n);
        face.v.append(v);
        face.t.append(t);
        face.n.append(n);
        qDebug()<<"Corner:"<<"v:"<<face.v[i]<<"t:"<<face.t[i]<<"n:"<<face.n[i];
        break;

    case 2://scan  v/t case2
        sscanf(buf, "%d/%d ", &v, &t);
        face.v.append(v);
        face.t.append(t);
        qDebug()<<"Corner:"<<"v:"<<face.v[i]<<"t:"<<face.t[i];
        break;

    case 3://scan  v//n case3
        sscanf(buf, "%d//%d ", &v,&n);
        face.v.append(v);
        face.n.append(n);
        qDebug()<<"Corner:"<<"v:"<<face.v[i]<<"n:"<<face.n[i];
        break;

    case 4://scan  v   case4
        sscanf(buf, "%d ", &v);
        face.v.append(v);
        qDebug()<<"Handle:"<<handle;
        qDebug()<<"Corner:"<<"v:"<<face.v[i];
        break;
    }

    //qDebug()<<"Corner:"<<"v:"<<face.v[i]<<"t:"<<face.t[i]<<"n:"<<face.n[i];


    buf += strcspn(buf, " \t");
    buf += strspn(buf, " \t");

    return buf;
}

char const* Obj::parseTriangle(char const* buf,tagTriangle  face)
{
    qDebug()<<"parseCorner:"<<buf;

    int v, t, n ;

    v=t=n = 0;

    //handle all four cases of the format

    //scan v/t/n    case1
    handle = sscanf(buf, "%d/%d/%d ", &v, &t, &n);
    if ( handle != 1)
    {
       handlecase = 1;
       qDebug()<<"Handle:"<<handle;
       goto end;
    }

    //scan  v/t case2
    handle = sscanf(buf, "%d/%d ", &v, &t);
    if(handle != 1)
    {
        handlecase = 2;
        qDebug()<<"Handle:"<<handle;

        goto end;
    }

    //scan  v//n case3
    handle = sscanf(buf, "%d//%d " , &v,&n);
    if(handle != 1)
    {
        handlecase =3;
        qDebug()<<"Handle:"<<handle;
        goto end;
    }

    //scan  v   case4
    handle=sscanf(buf, "%d " , &v);
    if(handle != 1)
    {
        handlecase = 4;
        qDebug()<<"Handle:"<<handle;
        goto end;
    }

    end:
    //v=t=n = NULL;
    int a,b,c,d,e,f,g,h,i;
    a=b=c=d=e=f=g=h=i=0;
    switch(handlecase)
    {
    case 1://scan v/t/n    case1

        //int a,b,c,d,e,f,g,h,i=0;
        sscanf(buf, "%d/%d/%d %d/%d/%d %d/%d/%d ", &a, &b, &c, &d, &e, &f, &g, &h, &i);
        face.v.append(a); face.t.append(b);face.n.append(c);
        face.v.append(d); face.t.append(e);face.n.append(f);
        face.v.append(g); face.t.append(h);face.n.append(i);

        //qDebug()<<"Corner:"<<"v:"<<face.v[i]<<"t:"<<face.t[i]<<"n:"<<face.n[i];
        break;

    case 2://scan  v/t case2
        //int a,b,c,d,e,f=0;
        sscanf(buf, "%d/%d %d/%d %d/%d ", &a, &b, &c, &d, &e, &f);
        face.v.append(a); face.t.append(b);
        face.v.append(c); face.t.append(d);
        face.v.append(e); face.t.append(f);
        //qDebug()<<"Corner:"<<"v:"<<face.v[i]<<"t:"<<face.t[i];
        break;

    case 3://scan  v//n case3

        //f 17//5 16//5 4//5
        //int a,b,c,d,e,f=0;

        sscanf(buf, "%d//%d %d//%d %d//%d", &a,&b,&c,&d,&e,&f);
        face.v.append(a);face.n.append(b);
        face.v.append(c);face.n.append(d);
        face.v.append(e);face.n.append(f);
        //qDebug()<<"Corner:"<<"v:"<<face.v[i]<<"n:"<<face.n[i];
        break;

    case 4://scan  v   case4
        //int a=0;
        sscanf(buf, "%d ", &a);
        face.v.append(a);
        //qDebug()<<"Handle:"<<handle;
        //qDebug()<<"Corner:"<<"v:"<<face.v[i];
        break;
    }

    //qDebug()<<"Corner:"<<"v:"<<face.v[i]<<"t:"<<face.t[i]<<"n:"<<face.n[i];


    //buf += strcspn(buf, " \t");
    //buf += strspn(buf, " \t");

    return buf;
}


void Obj::parseFace(char const* buf,tagObjMesh  mesh)
{

    tagTriangle face;

    //size_t strspn ( const char * str1, const char * str2 );
    //Get span of character set in string
    //Returns the length of the initial portion
    //of str1 which consists only of characters
    //that are part of str2.
    //The search does not include the terminating
    //null-characters of either strings, but ends there.

    //We are working with only triangles  and not QUADS or more
    buf = buf + strspn(buf, " \tf");

    qDebug()<<"Buffer:"<<buf;

    parseTriangle(buf,face);


    //for(int i =0;i<3;i++)
    //{
    //    buf = parseCorner(buf,face,i);
     //   qDebug()<<"Corner:"<<"v:"<<face.v[i]<<"t:"<<face.t[i]<<"n:"<<face.n[i];


    //}


    switch(handlecase)
    {
    case 1://scan v/t/n    case1

        //int a,b,c,d,e,f,g,h,i=0;
        //sscanf(buf, "%d/%d/%d %d/%d/%d %d/%d/%d ", &a, &b, &c, &d, &e, &f, &g, &h, &i);


        qDebug()<<"face:"<<"v:"<<face.v[0]<<"t:"<<face.t[0]<<"n:"<<face.n[0];
        qDebug()<<"face:"<<"v:"<<face.v[1]<<"t:"<<face.t[1]<<"n:"<<face.n[1];
        qDebug()<<"face:"<<"v:"<<face.v[2]<<"t:"<<face.t[2]<<"n:"<<face.n[2];

        break;

    case 2://scan  v/t case2
        //int a,b,c,d,e,f=0;
        //sscanf(buf, "%d/%d %d/%d %d/%d ", &a, &b, &c, &d, &e, &f);


        qDebug()<<"face:"<<"v:"<<face.v[0]<<"t:"<<face.t[0];
        qDebug()<<"face:"<<"v:"<<face.v[1]<<"t:"<<face.t[1];
        qDebug()<<"face:"<<"v:"<<face.v[2]<<"t:"<<face.t[2];

        //qDebug()<<"Corner:"<<"v:"<<face.v[i]<<"t:"<<face.t[i];
        break;

    case 3://scan  v//n case3

        //f 17//5 16//5 4//5
        //int a,b,c,d,e,f=0;

        //sscanf(buf, "%d//%d %d//%d %d//%d", &a,&b,&c,&d,&e,&f);

        qDebug()<<"face:"<<"v:"<<face.v[0]<<"n:"<<face.n[0];
        qDebug()<<"face:"<<"v:"<<face.v[1]<<"n:"<<face.n[1];
        qDebug()<<"face:"<<"v:"<<face.v[2]<<"n:"<<face.n[2];

        //qDebug()<<"Corner:"<<"v:"<<face.v[i]<<"n:"<<face.n[i];
        break;

    case 4://scan  v   case4
        //int a=0;
        //sscanf(buf, "%d ", &a);

        qDebug()<<"face:"<<"v:"<<face.v[0];
        qDebug()<<"face:"<<"v:"<<face.v[1];
        qDebug()<<"face:"<<"v:"<<face.v[2];
        //face.v.append(a);
        //qDebug()<<"Handle:"<<handle;
        //qDebug()<<"Corner:"<<"v:"<<face.v[i];
        break;
    }

    mesh.triangles.append(face);
    //qDebug()<<"Triangles added:"<<mesh.triangles.length();

    /*

    //push(&mesh.triangles, &mesh.nfaces, &face, sizeof(face));

    //In case the face was not a triangle, read the rest in as a triangle fan
    while (*buf)
    {
        face.v[1] = face.v[2];
        face.t[1] = face.t[2];
        face.n[1] = face.n[2];

        buf = parseCorner(buf,mesh, face.v[2], face.t[2], face.n[2]);

        mesh.triangles.append(face);

    }

}


tagObjMesh Obj::loadObjFile(const char* filename)
{
    qDebug()<<"Load Obj file";
    tagObjMesh mesh;

    FILE*  file = NULL;
    char buf[256];
    char token[16];
    int line = 0;

    Xyz vertex;

    file = fopen(filename, "r");

    if (file == NULL)
    {
        qDebug()<<"File not found";

    }
    else
    {
        qDebug()<<"File found";
    }


    qDebug()<<"reading file:"<<sizeof(buf);



    while (fgets(buf, sizeof(buf), file))
    {
        //qDebug()<<"Reading line:"<<sizeof(buf);

        if (sscanf(buf, " %s ", token) == 1)
        {
            //qDebug()<<"token:"<<token;

            if (strcmp(token, "v") == 0)
            {
                //qDebug()<<"v :vertices";

                sscanf(buf, " %*s %f %f %f", &vertex.x, &vertex.y, &vertex.z);
                //qDebug()<<"vertex:"<<vertex.x<<vertex.y<<vertex.z;

                mesh.vertices.append(vertex);
                //push(&mesh.vertices, &mesh.nvertices, &vertex, sizeof(vertex));

                //printf("Vertices: %f %f %f",&vertex.x, &vertex.y, &vertex.z);

            }
            else if (strcmp(token, "vt") == 0)
            {
                //qDebug()<<"vt : textureCoords";

                sscanf(buf, " %*s %f %f %f", &vertex.x, &vertex.y, &vertex.z);
                //qDebug()<<"textureCoords:"<<vertex.x<<vertex.y<<vertex.z;

                //push(&mesh.texcoords, &mesh.ntexcoords, &vertex, sizeof(vertex));
                mesh.texcoords.append(vertex);

            }
            else if (strcmp(token, "vn") == 0)
            {
                //qDebug()<<"vn : normals";

                sscanf(buf, " %*s %f %f %f", &vertex.x, &vertex.y, &vertex.z);
                //qDebug()<<"Normals:"<<vertex.x<<vertex.y<<vertex.z;

                //push(&mesh.normals, &mesh.nnormals, &vertex, sizeof(vertex));
                mesh.normals.append(vertex);

            }
            else if (strcmp(token, "f") == 0)
            {
                qDebug()<<"token:"<<token;
                qDebug()<<"Vertices Count:"<<mesh.vertices.length();
                qDebug()<<"Normals Count:"<<mesh.normals.length();
                qDebug()<<"Texturecoods Count:"<<mesh.texcoords.length();

                qDebug()<<"token:"<<token;

                parseFace(buf,mesh);
            }
        }
    }


    fclose(file);

    return mesh;
}



char const* Obj::parseCorner(char const* buf,tagTriangle face,int i)
{
    qDebug()<<"parseCorner:"<<buf;

    int v, t, n ; v=t=n =0;

    if (sscanf(buf, "%d/%d/%d ", &v, &t, &n) == 1)
    {
        qDebug()<<"v:"<<v<<"t:"<<t<<"n:"<<n;

        sscanf(buf,"%*d//%d", &v);

        //qDebug()<<"last v:"<<v;
    }

    if (v < 0)
        v  = g_mesh.vertices.length()  + v;
    else v  -= 1;

    if (t < 0)
        t = g_mesh.texcoords.length() + t;
    else t -= 1;

    if (n < 0)
        n = g_mesh.normals.length()+ n;
    else n -= 1;

    face.v[i] = v;
    face.t[i] = t;
    face.n[i] = n;

    buf += strcspn(buf, " \t");
    buf += strspn(buf, " \t");

    return buf;
}
*/







