#include "selection.h"

selection::selection()
{

}

