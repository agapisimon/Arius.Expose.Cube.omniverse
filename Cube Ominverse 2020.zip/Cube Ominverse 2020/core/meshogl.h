#ifndef MESHOGL_H
#define MESHOGL_H

#include<QtOpenGL>



#endif // MESHOGL_H
