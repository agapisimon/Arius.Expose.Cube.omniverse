#ifndef VIEWNAVIGATION_H
#define VIEWNAVIGATION_H

#include<QtWidgets>
#include<glm/glm.hpp>

enum CameraState
{
    OFF,
    PAN,
    ROTATION,
    ZOOM,
};

class viewCamera
{
    viewCamera()
    {

    }

};

class viewNavigation
{
public:
    viewNavigation();
};

#endif // VIEWNAVIGATION_H
