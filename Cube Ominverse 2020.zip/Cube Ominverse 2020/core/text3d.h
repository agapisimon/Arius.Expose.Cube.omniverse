#ifndef TEXT3D_H
#define TEXT3D_H
#include<QtWidgets>
#include<QtOpenGL>
#include<GL/glu.h>


class Text3D
{
public:
     Text3D();
     void init();
     void setText(QString text);
     void drawText3D(); // print it in 3D!


private:
     void print();
     void initfont(QFont & f, float thickness); // set up a font and specify the "thickness"
     void buildglyph(GLuint b, int c); // create one displaylist for character "c"
     void buildglyph();
     QFont * font;
     QFontMetricsF *fm;
     float glyphthickness;
     GLuint base; // the "base" of our displaylists
     QString text;
     float textwidth;

};


class Text3DOutline
{
public:
     Text3DOutline(){}
     void init(){}
     void setText(QString text){}
     void drawText3D(){} // print it in 3D!


private:
     void print(){}
     void initfont(QFont & f, float thickness){} // set up a font and specify the "thickness"
     void buildglyph(GLuint b, int c){} // create one displaylist for character "c"
     QFont * font;
     QFontMetricsF *fm;
     float glyphthickness;
     GLuint base; // the "base" of our displaylists
     QString text;
     float textwidth;

};

#endif // TEXT3D_H
