#ifndef TEXT_H
#define TEXT_H

#include<QtWidgets>
#include<QGLWidget>
#include<QtOpenGL>

class Text
{
    QString text;
    QColor color;
    QVector3D pos;

public:
    Text(QString str);

    QColor getColor()
    {
        return color;
    }

    void setColor(QColor _color)
    {
        color =_color;
    }

    QVector3D getPos()
    {
        return pos;
    }

    void setPos(const QVector3D &_pos)
    {
        pos =_pos;
    }

    void setText(const QString &str)
    {
        text = str;
    }

    QString getText()
    {
        return text;
    }

    void drawtext2D(QGLWidget *w,QColor c)
    {
        //qglColor(color);
        //glColor3f(color.red()/255,color.blue()/255,color.green()/255);
        glColor3f(c.red()/255,color.blue()/255,color.green()/255);
        w->renderText(pos.x(),pos.y(),pos.z(),text,QFont("Arial", 8, QFont::Bold, false));

    }

    void drawTextOGL()
    {
        //not tested
        QPainterPath path;
        glDisable(GL_LIGHTING);
        QFont font("Arial", 40);

        path.addText(QPointF(0, 0), QFont("Arial", 40), QString("Painter Fonts in opengl"));
        QList<QPolygonF> poly = path.toSubpathPolygons();
        for (QList<QPolygonF>::iterator i = poly.begin(); i != poly.end(); i++)
        {
            glBegin(GL_LINE_LOOP);
            for (QPolygonF::iterator p = (*i).begin(); p != i->end(); p++)
                glVertex3f(p->rx()*0.1f, -p->ry()*0.1f, 0);
            glEnd();
        }
        glEnable(GL_LIGHTING);
    }
};

#endif // TEXT_H
