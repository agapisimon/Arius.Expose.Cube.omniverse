#ifndef LIGHT_H
#define LIGHT_H
#include<QtWidgets>
#include<QtOpenGL>
class Light
{
    QVector3D position;
public:
    Light();

    void CreateLighting()
    {
        position = QVector3D();

        //glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);

        //glShadeModel(GL_FLAT);

        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);

        static GLfloat light_position[4] = { 5, 5, 5, 1.0 };
        glLightfv(GL_LIGHT0, GL_POSITION, light_position);
        glEnable(GL_DEPTH_TEST);

    }

    void CreateFullLighting()
    {
        position = QVector3D();
        //glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);

        glShadeModel(GL_SMOOTH);

        ///ligt affects materials colors
        /*
        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);

        static GLfloat light_position[4] = { 0, 0, 10, 1.0 };
        glLightfv(GL_LIGHT0, GL_POSITION, light_position);
        */
        GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
        GLfloat mat_shininess[] = { 50.0 };
        GLfloat light_position[] = { 10, 10, 0, 1.0};
        //GLfloat light_position[] = { 1.0, 1.0, 1.0, 0.0 };
        GLfloat white_light[] = { 1, 1, 1, 1.0 };
        GLfloat lmodel_ambient[] = { 0.1, 0.2, 0.2, 1.0 };

        //glClearColor(0.0, 0.0, 0.0, 0.0);
        glShadeModel(GL_FLAT);
        glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
        glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);

        glLightfv(GL_LIGHT1, GL_POSITION, light_position);
        glLightfv(GL_LIGHT1, GL_DIFFUSE, white_light);
        glLightfv(GL_LIGHT1, GL_SPECULAR, white_light);
        glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);

        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT1);
        glEnable(GL_DEPTH_TEST);

    }

    void translate()
    {

    }
};

#endif // LIGHT_H
