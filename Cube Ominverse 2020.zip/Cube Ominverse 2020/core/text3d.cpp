#include "text3d.h"


Text3D::Text3D() // nothing special in the constructor
 : glyphthickness(1.0f)
 , base(0)
{

}

void Text3D::init()
{
     text = QString("CUBE OMNIVERSE");
     QFont dfont("Comic Sans MS", 20);
     QFontMetrics fm(dfont);

     textwidth = fm.width(text);
     qDebug() << "width of text: " << textwidth;

     initfont(dfont,5);
}


void Text3D::initfont(QFont & f, float thickness)
{
     qDebug() << "init font started";

     font = &f;

     fm = new QFontMetricsF(f);

     glyphthickness = thickness;

     if(base) // if we have display lists already, delete them first
       glDeleteLists(base, 256);

     base = glGenLists(256); // generate 256 display lists

     if(base == 0)
     {
         qDebug() << "cannot create display lists.";
         throw;
     }
     qDebug() << "build glyph create started";

     // loop to build the first 256 glyphs
      for(int i=0; i<256;++i)
      {
          //buildglyph(base+i, (char)i);
      }


      buildglyph();


      qDebug() << "build glyph create";

}

void Text3D::setText(QString _text)
{
    text = _text;
}

void Text3D::print()
{
     glPushAttrib(GL_LIST_BIT); // Pushes The Display List Bits
     glListBase(base); // Sets The Base Character to 0
     glCallLists(text.length(), GL_UNSIGNED_BYTE, text.toLocal8Bit()); // Draws The Display List Text
     glPopAttrib(); // Pops The Display List Bits
}



void CALLBACK beginCallback(GLenum which)
{
   glBegin(which);
}
void CALLBACK errorCallback(GLenum errorCode)
{
   const GLubyte *estring;

   estring = gluErrorString(errorCode);
   fprintf(stderr, "Tessellation Error: %s\n", (char *) estring);
   exit(0);
}

void CALLBACK endCallback(void)
{
   glEnd();
}

void Text3D::buildglyph()
{
    //not tested
    QPainterPath path;
    //glDisable(GL_LIGHTING);
    QFont font("Arial", 8);

    path.addText(QPointF(0, 0), QFont("Arial", 8), QString("CUBE OMNIVERSE"));

    //QList<QPolygonF> poly = path.toSubpathPolygons();
    QList<QPolygonF> poly = path.toFillPolygons();

    for (QList<QPolygonF>::iterator i = poly.begin(); i != poly.end(); i++)
    {
        glBegin(GL_LINE_LOOP);

        for (QPolygonF::iterator p = (*i).begin(); p != i->end(); p++)
        {
            glVertex3f(p->rx()*0.1f, -p->ry()*0.1f, 0);
        }

        glEnd();
    }
    //glEnable(GL_LIGHTING);
}

void Text3D::buildglyph(GLuint listbase, int c) // this is the main "workhorse" function. Create a displaylist with
{

    // ID "listbase" from character "c"

    GLUtriangulatorObj *tobj;
    QPainterPath path;

    path.addText(QPointF(0,0),*font, QString((char)c));

    //QList<QPolygonF> poly = path.toSubpathPolygons(); // get the glyph outline as a list of paths
    QList<QPolygonF> poly = path.toFillPolygons(); // get the glyph fill as a list of paths



    // set up the tesselation
    tobj = gluNewTess();

    gluTessCallback(tobj, GLU_TESS_VERTEX,(GLvoid (CALLBACK*) ()) &glVertex3dv);
    gluTessCallback(tobj, GLU_TESS_BEGIN,(GLvoid (CALLBACK*) ()) &beginCallback);
    gluTessCallback(tobj, GLU_TESS_END,(GLvoid (CALLBACK*) ()) &endCallback);
    gluTessCallback(tobj, GLU_TESS_ERROR,(GLvoid (CALLBACK*) ()) &errorCallback);

    //gluTessCallback(tobj, GLU_TESS_BEGIN,glVertex3fv);
    //gluTessCallback(tobj, GLU_TESS_VERTEX, beginCallback);
    //gluTessCallback(tobj, GLU_TESS_END, endCallback);
    //gluTessProperty(tobj, GLU_TESS_WINDING_RULE, GLU_TESS_WINDING_ODD);

    glNewList(listbase, GL_COMPILE); // start a new list
    glShadeModel(GL_FLAT);

    gluTessBeginPolygon(tobj, 0 );

    int j = 0;
    GLdouble  vertices[1000];

    for (QList<QPolygonF>::iterator it = poly.begin(); it != poly.end(); it)
    {
        gluTessBeginContour(tobj);

        int i = 0;

        for (QPolygonF::iterator p = (*it).begin(); p != it->end(); p)
        {
            int offset = j+i;
            vertices[offset+0] = p->rx();
            vertices[offset+1] = -p->ry();
            vertices[offset+2] = -glyphthickness; // Z offset set to "minus glyphtickness"

            gluTessVertex(tobj, &vertices[offset], &vertices[offset] );
            i+=3;
        }
        gluTessEndContour(tobj);
        j += (*it).size()*3;
    }
    gluTessEndPolygon(tobj);

    free(vertices); // no need for the vertices anymore

    for (QList<QPolygonF>::iterator it = poly.begin(); it != poly.end(); it)
    {
        glBegin(GL_QUAD_STRIP);

        QPolygonF::iterator p;

        for (p = (*it).begin(); p != it->end(); p)
        {
           glVertex3f(p->rx(), -p->ry(), 0.0f);
           glVertex3f(p->rx(), -p->ry(), -glyphthickness);
        }

        p = (*it).begin();
        glVertex3f(p->rx(), -p->ry(), 0.0f); // draw the closing quad
        glVertex3f(p->rx(), -p->ry(), -glyphthickness); // of the "wrapping"
        glEnd();
   }

   //GLfloat gwidth = (float)fm->width©;
   GLfloat gwidth = (float)fm->width(QChar('©'));

   glTranslatef(gwidth ,0.0f,0.0f);

   glEndList();
   gluDeleteTess(tobj);


}



void Text3D::drawText3D()
{
    glEnable(GL_DEPTH_TEST);

    glMatrixMode(GL_MODELVIEW); // To operate on model-view matrix
    glLoadIdentity(); // Reset the model-view matrix
    glTranslatef(0, 3.0f,0.0f); // Move right and into the screen

    //glRotatef(rot, 1.0f, 0.0f, 0.0f); // Rotate On The X Axis
    //glRotatef(rot*1.5f, 0.0f, 1.0f, 0.0f); // Rotate On The Y Axis
    //glRotatef(rot*1.4f, 0.0f, 0.0f, 1.0f); // Rotate On The Z Axis

    //glColor3f( 1.0f*float(cos(rot/20.0f)), // Animate the color
     //1.0f*float(sin(rot/25.0f)),
     //1.0f-0.5f*float(cos(rot/17.0f))
     //);


    glTranslatef(-textwidth/2.0f, 0.0f, 0.0f); // textwidth holds the pixel width of the text
     // Print GL Text To The Screen
    print();

    glDisable(GL_DEPTH_TEST);

     //rot +=0.3f; // increase rot value

     //if(rot > 2000.f)
      //   rot = 0.0f; // wrap around at 2000
}


