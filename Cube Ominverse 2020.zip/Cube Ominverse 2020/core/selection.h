#ifndef SELECTION_H
#define SELECTION_H
#include<QtWidgets>
#include<QtOpenGL>
#include<GL/glu.h>

class selection
{
    GLint hits;
    GLuint selectBuf[512];

    void drawScene(void)
    {
    }
    void processHits(GLint hits, GLuint buffer[])
    {
    }
    void selectObjects(void)
    {
    }

public:
    selection();

    void picking(int x, int y)
    {
    }

    void display(void)
    {
    }
    void grabKeyBoard(QKeyEvent *event)
    {
        if(event->key()==Qt::Key_Space)
        {

            processHits(hits, selectBuf);
        }

    }
};

#endif // SELECTION_H
