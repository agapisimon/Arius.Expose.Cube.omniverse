#ifndef MESH_H
#define MESH_H
#include<QtWidgets>
#include<QtOpenGL>
#include<QGLWidget>
#include<GL/glu.h>

#include<core/math.h>
#include<core/curve.h>
#include<core/text.h>
#include<core/text3d.h>
#include<core/importobj.h>
#include<core/bvh.h>
#include<glm/glm.hpp>
#include<glm/gtx/intersect.hpp>
#include<vector>

class Material
{
public:
    int id;
    int texObj;
    QString name;

    Material1()
    {
        id =0;
        texObj =0;
    }


};

class Mesh
{    
public:
    QList<int> indices;

    QList<QVector3D> vertices;
    QList<QVector3D> normals;

    QList<QVector3D> uvw;
    QList<QVector2D> uvs;

    QList<Triangle> triangles;
    QList<Material> materials;

    bool hasNormals;
    bool hasUVW;
    bool hasUVS;
    bool useMaterials;

    QVector3D boundingSpherePos;
    QVector3D boundingBoxPos;

    float boundingSphereRadius;
    int displayListObj;

    Mesh()
    {

        boundingSphereRadius = 1.0f;

        boundingSpherePos = QVector3D(0.0f, 0.0f, 0.0f);

        displayListObj = 0;

    }
};

class Model
{
public:
    std::vector<Mesh>MeshList;

    glm::vec3 localpos;
    glm::vec3 worldpos;

    glm::vec3 localRot;
    glm::vec3 worldRot;

    glm::vec3 localScale;
    glm::vec3 worldScale;

    glm::mat3x3 worldMatrix;
    glm::mat3x3 localMatrix;
};

class MeshOGL
{
    qreal worldAxisRadius;
    QColor color;

    GLUquadric* cone;
    GLUquadric* cylinder;

    float lightblue[3] = {76,202,255};
    float lightcyan[3] = {9,232,214};
    float creamcyan[3]  = {130,177,168};
    float ligthorange[3] = {225,177,109};
    float blueplus[3] = {0,157,255};
    float Dark[3] = {60,63,6};
    float gray[3] = {128,128,128};
    float graylighter[3] = {195,195,195};


public:


    ObjMeshExtended obj;

    Curve3D *curve;

    //BVHImporter skeleton;

    MeshOGL()
    {
        curve = new Curve3D;
        worldAxisRadius = 0.5;
        color = QColor(255,255,255);

        cylinder =  gluNewQuadric();
        cone =  gluNewQuadric();


        //objmesh.LoadModel();
    }

    void drawObj()
    {
        if(obj.vertices.size()>0)
            obj.drawOBJ();

        //skeleton.drawBVH();
    }

    void drawtext3D()
    {
        //not tested
        QPainterPath path;
        QFont font("Arial", 5);

        path.addText(QPointF(0, 0),font, QString("CUBE OMNIVERSE"));
        QList<QPolygonF> poly = path.toSubpathPolygons();

        for (QList<QPolygonF>::iterator i = poly.begin(); i != poly.end(); i++)
        {
            glBegin(GL_LINE_LOOP);

            for (QPolygonF::iterator p = (*i).begin(); p != i->end(); p++)
            {
                glVertex3f(p->rx()*0.1f, -p->ry()*0.1f, 0);
            }
            glEnd();
        }

        //////////////////////////////////////
    }

    void drawtext2D(QGLWidget *w,Text text)
    {
        text.setText(text.getText());
        text.drawtext2D(w,QColor(255,255,255));
    }

    void enableSmoothLines()
    {
        GLfloat values[2];
        glGetFloatv(GL_LINE_WIDTH_GRANULARITY, values);
        printf("GL_LINE_WIDTH_GRANULARITY value is %3.1f\n",
        values[0]);
        glGetFloatv(GL_LINE_WIDTH_RANGE, values);
        printf("GL_LINE_WIDTH_RANGE values are %3.1f %3.1f\n",
        values[0], values[1]);
        glEnable(GL_LINE_SMOOTH);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glHint(GL_LINE_SMOOTH_HINT, GL_DONT_CARE);
        glLineWidth(.5);
    }

    void disableSmoothLines()
    {
        glDisable(GL_LINE_SMOOTH);
        glDisable(GL_BLEND);
    }

    void drawSphere(qreal radius =.2)
    {
        float p[3] ={5,0,0};
        glPushMatrix();
        glTranslatef(p[0],p[1],p[2]);
        static GLUquadric* quadric = gluNewQuadric();
        gluSphere(quadric,radius,10,10);
        glPopMatrix();
    }

    void drawCornerAxis(int x,int y,glm::vec3 rotation)
    {
        glViewport(x,y, 200,200 );
        glScissor(x, y, 200, 200 );

        //glMatrixMode( GL_MODELVIEW );
        //glLoadIdentity();

        static GLUquadric *cone0 = gluNewQuadric();
        static GLUquadric *cone1 = gluNewQuadric();
        static GLUquadric *cone2 = gluNewQuadric();

        static GLUquadric *cylinder0 = gluNewQuadric();
        static GLUquadric *cylinder1 = gluNewQuadric();
        static GLUquadric *cylinder2 = gluNewQuadric();

        glPushMatrix();
        /*
        glTranslatef(0,0,0);

        glRotatef(rotation.x, 1, 0, 0);
        glRotatef(rotation.y, 0, 1, 0);
        glRotatef(rotation.z, 0, 0, 1);
        */

        glBegin(GL_LINES);
          glVertex3f(0,0,0);glVertex3f(0,1,0);
          glVertex3f(0,0,0);glVertex3f(1,0,0);
          glVertex3f(0,0,0);glVertex3f(0,0,1);
        glEnd();
        glPopMatrix();

        glColor3f (0.0, color.green()/255, 0.0);
        glPushMatrix();
        //gluCylinder(cylinder0,1,1,5,6,0);
        gluCylinder(cone0,1,0,1,6,0);
        glPopMatrix();

        glColor3f(color.red()/255,0.0,0.0);
        glPushMatrix();
        glRotatef(90,1,0,0);
        //gluCylinder(cylinder1,1,1,5,6,0);
        gluCylinder(cone1,1,0,1,6,0);
        glPopMatrix();

        glColor3f(0.0,0.0,color.blue()/255);
        glPushMatrix();
        glRotatef(90,0,1,0);
        //gluCylinder(cylinder2,1,1,5,6,0);
        gluCylinder(cone2,1,0,1,6,0);
        glPopMatrix();

        glPushMatrix();
    }

    void drawCornerAxis()
    {


        static GLUquadric *cone0 = gluNewQuadric();
        static GLUquadric *cone1 = gluNewQuadric();
        static GLUquadric *cone2 = gluNewQuadric();

        static GLUquadric *cylinder0 = gluNewQuadric();
        static GLUquadric *cylinder1 = gluNewQuadric();
        static GLUquadric *cylinder2 = gluNewQuadric();

        glPushMatrix();

        glBegin(GL_LINES);
          glVertex3f(0,0,0);glVertex3f(0,1,0);
          glVertex3f(0,0,0);glVertex3f(1,0,0);
          glVertex3f(0,0,0);glVertex3f(0,0,1);
        glEnd();
        glPopMatrix();

        glColor3f (0.0, color.green()/255, 0.0);
        glPushMatrix();
        //gluCylinder(cylinder0,1,1,5,6,0);
        gluCylinder(cone0,1,0,1,6,0);
        glPopMatrix();

        glColor3f(color.red()/255,0.0,0.0);
        glPushMatrix();
        glRotatef(90,1,0,0);
        //gluCylinder(cylinder1,1,1,5,6,0);
        gluCylinder(cone1,1,0,1,6,0);
        glPopMatrix();

        glColor3f(0.0,0.0,color.blue()/255);
        glPushMatrix();
        glRotatef(90,0,1,0);
        //gluCylinder(cylinder2,1,1,5,6,0);
        gluCylinder(cone2,1,0,1,6,0);
        glPopMatrix();

        glPushMatrix();
    }

    void Arrow (void)
    {
        glPushMatrix();
        glLoadIdentity();
        glTranslatef(0,5,0);
        static GLUquadric *cyl = gluNewQuadric();
        static GLUquadric *cy2 = gluNewQuadric();

        gluCylinder (cyl, 0.02, 0.02, 0.8, 16, 1);        // Body of axis.

        glColor3f (1,1,1);                                // Make arrow head white.
        glPushMatrix ();
           glTranslatef (0.0, 0.0, 0.8);
           gluCylinder  (cy2, 0.04, 0.001, 0.1, 12, 1);   // Cone at end of axis.
        glPopMatrix ();
        glPopMatrix();
    }

    void drawWorldAxis(QGLWidget *w)
    {
          glPushMatrix(); // Don't forget to pop the Matrix

          // Draw the positive side of the lines x,y,z
          glLineWidth(3);
          glBegin(GL_LINES);

          glColor3f (0.0, color.green()/255, 0.0); // Green for x axis
          glVertex3f(0,0,0);
          glVertex3f(worldAxisRadius,0,0);


          glColor3f(color.red()/255,0.0,0.0); // Red for y axis
          glVertex3f(0,0,0);
          glVertex3f(0,worldAxisRadius,0);

          glColor3f(0.0,0.0,color.blue()/255); // Blue for z axis
          glVertex3f(0,0,0);
          glVertex3f(0,0,worldAxisRadius);

          glEnd();
          glLineWidth(1);

          glPopMatrix(); // Don't forget to pop the Matrix

          Text txtX(QString("Y"));
          txtX.setPos(QVector3D(0,worldAxisRadius,0));
          txtX.drawtext2D(w,QColor(0,255,0));

          Text txtY(QString("X"));
          txtY.setPos(QVector3D(worldAxisRadius,0,0));
          txtY.drawtext2D(w,QColor(255,0,0));

          Text txtZ(QString("Z"));
          txtZ.setPos(QVector3D(0,0,worldAxisRadius));
          txtZ.drawtext2D(w,QColor(0,0,255));

     }

    void drawCube(qreal radius)
    {
        //need more work
        glPushMatrix();
        glTranslatef(-0.5*radius,-0.5*radius,-0.5*radius);
        glScalef(radius,radius,radius);

        glBegin(GL_QUADS);
        // front
        glColor3f(1.0f, 0.0f, 0.0f);
        glVertex3f(-10.0f, -10.0f, 10.0f);
        glVertex3f(10.0f, -10.0f, 10.0f);
        glVertex3f(10.0f, 10.0f, 10.0f);
        glVertex3f(-10.0f, 10.0f, 10.0f);
        // back
        glColor3f(0.0f, 1.0f, 0.0f);
        glVertex3f(10.0f, -10.0f, -10.0f);
        glVertex3f(-10.0f, -10.0f, -10.0f);
        glVertex3f(-10.0f, 10.0f, -10.0f);
        glVertex3f(10.0f, 10.0f, -10.0f);
        // left
        glColor3f(0.0f, 0.0f, 1.0f);
        glVertex3f(-10.0f, -10.0f, -10.0f);
        glVertex3f(-10.0f, -10.0f, 10.0f);
        glVertex3f(-10.0f, 10.0f, 10.0f);
        glVertex3f(-10.0f, 10.0f, -10.0f);
        // right
        glColor3f(1.0f, 1.0f, 0.0f);
        glVertex3f(10.0f, -10.0f, 10.0f);
        glVertex3f(10.0f, -10.0f, -10.0f);
        glVertex3f(10.0f, 10.0f, -10.0f);
        glVertex3f(10.0f, 10.0f, 10.0f);
        // top
        glColor3f(1.0f, 0.0f, 1.0f);
        glVertex3f(-10.0f, 10.0f, 10.0f);
        glVertex3f(10.0f, 10.0f, 10.0f);
        glVertex3f(10.0f, 10.0f, -10.0f);
        glVertex3f(-10.0f, 10.0f, -10.0f);
        // bottom
        glColor3f(0.0f, 1.0f, 1.0f);
        glVertex3f(-10.0f, -10.0f, -10.0f);
        glVertex3f(10.0f, -10.0f, -10.0f);
        glVertex3f(10.0f, -10.0f, 10.0f);
        glVertex3f(-10.0f, -10.0f, 10.0f);
        glEnd();

        glPopMatrix();
    }

    void drawIcosahedron()
    {

        qreal X =.525731112119133606;
        qreal Z =.850650808352039932;

        GLfloat vdata[12][3] =
        {
           {-X, 0.0, Z}, {X, 0.0, Z}, {-X, 0.0, -Z}, {X, 0.0, -Z},
           {0.0, Z, X}, {0.0, Z, -X}, {0.0, -Z, X}, {0.0, -Z, -X},
           {Z, X, 0.0}, {-Z, X, 0.0}, {Z, -X, 0.0}, {-Z, -X, 0.0}
        };
        GLuint tindices[20][3] =
        {
           {0,4,1}, {0,9,4}, {9,5,4}, {4,5,8}, {4,8,1},
           {8,10,1}, {8,3,10}, {5,3,8}, {5,2,3}, {2,7,3},
           {7,10,3}, {7,6,10}, {7,11,6}, {11,0,6}, {0,1,6},
           {6,1,10}, {9,0,11}, {9,11,2}, {9,2,5}, {7,2,11} };
        int i;

        glBegin(GL_TRIANGLES);

        for (i = 0; i < 20; i++)
        {
           // color information here
           glVertex3fv(&vdata[tindices[i][0]][0]);
           glVertex3fv(&vdata[tindices[i][1]][0]);
           glVertex3fv(&vdata[tindices[i][2]][0]);
        }
        glEnd();
    }

    void drawPyramid()
    {
        glColor3f(.5,.5,.5);

        glBegin(GL_QUADS);
            glNormal3f(0,0,-1);
            glVertex3f(-1,-1,0);
            glVertex3f(-1,1,0);
            glVertex3f(1,1,0);
            glVertex3f(1,-1,0);

        glEnd();
        glBegin(GL_TRIANGLES);
            glNormal3f(0,-1,0.707);
            glVertex3f(-1,-1,0);
            glVertex3f(1,-1,0);
            glVertex3f(0,0,1.2);
        glEnd();
        glBegin(GL_TRIANGLES);
            glNormal3f(1,0, 0.707);
            glVertex3f(1,-1,0);
            glVertex3f(1,1,0);
            glVertex3f(0,0,1.2);
        glEnd();
        glBegin(GL_TRIANGLES);
            glNormal3f(0,1,0.707);
            glVertex3f(1,1,0);
            glVertex3f(-1,1,0);
            glVertex3f(0,0,1.2);
        glEnd();
        glBegin(GL_TRIANGLES);
            glNormal3f(-1,0,0.707);
            glVertex3f(-1,1,0);
            glVertex3f(-1,-1,0);
            glVertex3f(0,0,1.2);
        glEnd();
    }

    void drawGrid()
    {
        drawGrid(3,0.5);
    }

    void drawGrid(float size, float step)
    {
        // disable lighting
        glDisable(GL_LIGHTING);

        glBegin(GL_LINES);

        //glColor3f(0.3f, 0.3f, 0.3f);
        glColor3f((float)128/255,(float)128/255,(float)128/255);

        for(float i=step; i <= size; i+= step)
        {
            glVertex3f(-size, 0,  i);   // lines parallel to X-axis
            glVertex3f( size, 0,  i);
            glVertex3f(-size, 0, -i);   // lines parallel to X-axis
            glVertex3f( size, 0, -i);

            glVertex3f( i, 0, -size);   // lines parallel to Z-axis
            glVertex3f( i, 0,  size);
            glVertex3f(-i, 0, -size);   // lines parallel to Z-axis
            glVertex3f(-i, 0,  size);
        }

        // x-axis
        glColor3f(0.5f, 0, 0);
        glVertex3f(-size, 0, 0);
        glVertex3f( size, 0, 0);

        // z-axis
        glColor3f(0,0,0.5f);
        glVertex3f(0, 0, -size);
        glVertex3f(0, 0,  size);

        glEnd();

        // enable lighting back
        glEnable(GL_LIGHTING);
    }

    static void drawGrid2D( float scale, int steps )
    {
        int   i;
        float x, y;

        glPushMatrix();

        // Set background to some dark bluish grey
        glClearColor( 0.05f, 0.05f, 0.2f, 0.0f);
        glClear( GL_COLOR_BUFFER_BIT );

        // Setup modelview matrix (flat XY view)
        glLoadIdentity();
        gluLookAt( 0.0, 0.0, 1.0,
                   0.0, 0.0, 0.0,
                   0.0, 1.0, 0.0 );

        // We don't want to update the Z-buffer
        glDepthMask( GL_FALSE );

        // Set grid color
        glColor3f( 0.0f, 0.5f, 0.5f );

        glBegin( GL_LINES );

        // Horizontal lines
        x = scale * 0.5f * (float)(steps-1);
        y = -scale * 0.5f * (float)(steps-1);
        for( i = 0; i < steps; i ++ )
        {
            glVertex3f( -x, y, 0.0f );
            glVertex3f( x, y, 0.0f );
            y += scale;
        }

        // Vertical lines
        x = -scale * 0.5f * (float)(steps-1);
        y = scale * 0.5f * (float)(steps-1);
        for( i = 0; i < steps; i ++ )
        {
            glVertex3f( x, -y, 0.0f );
            glVertex3f( x, y, 0.0f );
            x += scale;
        }

        glEnd();

        // Enable Z-buffer writing again
        glDepthMask( GL_TRUE );

        glPopMatrix();
    }

    void drawTorus(int sides, int slices)
    {
       int i, j, k;
       double s, t, x, y, z, pie;

       pie = 2 * (double)M_PI;

       for (i = 0; i < sides; i++)
       {
          glBegin(GL_QUAD_STRIP);

          for (j = 0; j <= slices; j++)
          {
             for (k = 1; k >= 0; k--)
             {
                s = (i + k) % sides + 0.5;
                t = j % slices;

                x = (1+.1*cos(s*pie/sides))*cos(t*pie/slices);
                y = (1+.1*cos(s*pie/sides))*sin(t*pie/slices);
                z = .1 * sin(s * pie / sides);

                glVertex3f(x, y, z);
             }
          }
          glEnd();
       }
    }    
};

#endif // MESH_H
