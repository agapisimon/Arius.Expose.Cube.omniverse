#ifndef IMPORTOBJ_H
#define IMPORTOBJ_H
#include <stdio.h>
#include<string>
#include<QtWidgets>
//#include<fstream>
//#include<sstream>
#include<QtOpenGL>
#include<GL/glu.h>

#include<glm/glm.hpp>

/*
    Face Elements
    Faces are defined using lists of vertex,
    texture and normal indices. Polygons such
    as quadrilaterals can be defined by using
    more than three vertex/texture/normal indices.

token: f <Vertex index>
    f v1 v2 v3 ....
    Vertex Indices
    A valid vertex index starts from 1 and
    matches the corresponding vertex elements
    of a previously defined vertex list.
    Each face can contain three or more vertices.


token:  f <Vertex index/ Texture Coordinate index>
        f v1/vt1 v2/vt2 v3/vt3 ...
    Optionally, texture coordinate indices can
    be used to specify texture coordinates when
    defining a face. To add a texture coordinate
    index to a vertex index when defining a face,
    one must put a slash immediately after the vertex
    index and then put the texture coordinate index.
    No spaces are permitted before or after the slash.
    A valid texture coordinate index starts from 1 and
    matches the corresponding element in the previously
    defined list of texture coordinates. Each face can
    contain three or more elements.



token:  f <Vertex index/ Normal index>
        f v1/vt1/vn1 v2/vt2/vn2 v3/vt3/vn3 ....

    Vertex Normal Indices Optionally, normal indices can
    be used to specify normal vectors for vertices when defining a face.
    To add a normal index to a vertex index when defining a face, one must
     put a second slash after the texture coordinate index and then put the
    normal index. A valid normal index starts from 1 and matches the corresponding element
    in the previously defined list of normals. Each face can contain three or more elements.



token: f <Vertex index/ Normal index>
     f v1//vn1 v2//vn2 v3//vn3 ...


    Vertex Normal Indices Without Texture Coordinate Indices
    As texture coordinates are optional,
    one can define geometry without them,
    but one must put two slashes after the vertex
    index before putting the normal index.
*/


class ObjPolygon
{
public:
    glm::vec3 center;
    glm::vec3 normal;

    std::vector<int> v;
    std::vector<int> n;
    std::vector<int> uv;
};

class ObjMeshExtended
{
public:
    std::vector< unsigned int > vertexIndices;
    std::vector< unsigned int > uvIndices;
    std::vector< unsigned int > normalIndices;

    std::vector< glm::vec3> vertices;
    std::vector< glm::vec2> uvs;
    std::vector< glm::vec3> normals;
    std::vector< ObjPolygon> polygons;

    float normalsScale =0.05;
    float boundingSphereRadius;

    glm::vec3 boundingSpherePos;

    ObjMeshExtended()
    {
       //qDebug()<<"Importing Obj";
       //bool res = loadOBJ("D:/QT docs/Cube Omiverse C++ version 1 - QT 4.8.6/Cube/agapi.obj");
       //bool res = loadOBJ("D:/QT docs/Cube Omiverse C++ version 1 - QT 4.8.6/Cube/textcube.obj");
       //bool res = loadOBJ("D:/QT docs/Cube Omiverse C++ version 1 - QT 4.8.6/Cube/saucer.obj");
       //bool res = loadOBJ("D:/QT docs/Cube Omiverse C++ version 1 - QT 4.8.6/Cube/saucer1.obj");
       bool res = loadOBJ("D:/QT docs/Cube Omiverse C++ version 1 - QT 4.8.6/Cube/castle.obj");
       //bool res = loadOBJ("D:/QT docs/Cube Omiverse C++ version 1 - QT 4.8.6/Cube/ameaba.obj");
       //bool res = loadOBJ("D:/QT docs/Cube Omiverse C++ version 1 - QT 4.8.6/Cube/bipustriangulateduv.obj");
        //qDebug()<<"Importing Obj completed";
    }



    void drawOBJ()
    {
        if(vertices.size()>0)
        {
            //selectionStencil();
            drawMesh();
            //drawVertices();
            //drawNormals();
            //drawFaceNormals();
            //drawEdges();
        }
    }
    bool loadSTL()
    {
        reset();

    }
    bool loadMd5()
    {
        reset();


    }
    bool load3DS()
    {
        reset();

    }

    void reset()
    {
        vertexIndices.clear();
        uvIndices.clear();
        normalIndices.clear();
        vertices.clear();
        uvs.clear();
        normals.clear();
        polygons.clear();
    }

    bool loadOBJ(const char * path)
    {
        reset();

        FILE * file = fopen(path, "r");       

        if( file == NULL )
        {
            printf("Impossible to open the file !\n");
            return false;
        }

        while( 1)
        {

            char lineHeader[128];

            // read the first word of the line
            int res = fscanf(file, "%s", lineHeader);

            if (res == EOF)
                break; // EOF = End Of File. Quit the loop.

            // else : parse lineHeader

            if ( strcmp( lineHeader, "v" ) == 0 )
            {
                glm::vec3 vertex;
                fscanf(file, "%f %f %f\n", &vertex.x, &vertex.y, &vertex.z );
                //temp_vertices.push_back(vertex);
                vertices.push_back(vertex);

            }
            else if ( strcmp( lineHeader, "vt" ) == 0 )
            {
                glm::vec2 uv;
                fscanf(file, "%f %f\n", &uv.x, &uv.y );
                //temp_uvs.push_back(uv);
                uvs.push_back(uv);
            }
            else if ( strcmp( lineHeader, "vn" ) == 0 )
            {
                glm::vec3 normal;
                fscanf(file, "%f %f %f\n", &normal.x, &normal.y, &normal.z );
                //temp_normals.push_back(normal);
                normals.push_back(normal);
            }
            else if ( strcmp( lineHeader, "f" ) == 0 )
            {
                std::string vertex1, vertex2, vertex3;

                unsigned int vertexIndex[3], uvIndex[3], normalIndex[3];

                int matches = fscanf(file, "%d/%d/%d %d/%d/%d %d/%d/%d\n", &vertexIndex[0], &uvIndex[0], &normalIndex[0], &vertexIndex[1], &uvIndex[1], &normalIndex[1], &vertexIndex[2], &uvIndex[2], &normalIndex[2] );

                if (matches != 9)
                {
                    printf("File can't be read by our simple parser : ( Try exporting with other options\n");
                    return false;
                }

                vertexIndices.push_back(vertexIndex[0]);
                vertexIndices.push_back(vertexIndex[1]);
                vertexIndices.push_back(vertexIndex[2]);

                uvIndices.push_back(uvIndex[0]);
                uvIndices.push_back(uvIndex[1]);
                uvIndices.push_back(uvIndex[2]);

                normalIndices.push_back(normalIndex[0]);
                normalIndices.push_back(normalIndex[1]);
                normalIndices.push_back(normalIndex[2]);
            }
        }

        processPolygons();
        calculateFaceNormals_Centers();
        computeBoundingRadius();
    }
    void drawEdges()
    {

    }
    void evaluateModifiers()
    {

    }

    void selectionStencil()
    {
        glClearStencil(0);
        glClear(GL_STENCIL_BUFFER_BIT);

        // Render the mesh into the stencil buffer.

        glEnable(GL_STENCIL_TEST);

        glStencilFunc(GL_ALWAYS, 1, -1);
        glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);


        //glColor3f(0,1,1);

        drawMesh();

        // Render the thick wireframe version.

        glStencilFunc(GL_NOTEQUAL, 1, -1);
        glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);

        glLineWidth(3);
        glPolygonMode(GL_FRONT, GL_LINE);
        glDisable(GL_STENCIL_TEST);
    }



private:
    void processPolygons()
    {
        //triangles have the correct indices
        for (int i =0; i < vertexIndices.size(); i+=3)
        {
            ObjPolygon poly;

            for (int j = 0; j < 3; j++)
            {
                unsigned int vertexIndex = vertexIndices[i+j];
                unsigned int normalIndex = normalIndices[i+j];
                unsigned int uvIndex     = uvIndices[i+j];

                poly.v.push_back(vertexIndex -1);
                poly.n.push_back(normalIndex -1);
                poly.uv.push_back(uvIndex -1);
            }

            polygons.push_back(poly);
        }
    }

    void flipNormals()
    {
        for (int i =0;i<polygons.size();i++)
        {
            //((ObjPolygon)polygons[i]).normal *= -1;

            ObjPolygon poly = polygons[i];
            poly.normal *= -1;
            polygons[i]= poly;
        }
    }

    void computeBoundingRadius()
    {
        //compute bounding sphere
        boundingSpherePos = glm::vec3(0.0f, 0.0f, 0.0f);

        for (int i =0;i<vertices.size();i++)
        {
            boundingSpherePos += vertices[i];
        }

        boundingSpherePos /= (float)vertices.size();

        boundingSphereRadius = 0.0f;

        for (int i =0;i<vertices.size();i++)
        {
            glm::vec3 v = vertices[0] - boundingSpherePos;
            boundingSphereRadius = std::max<float>(boundingSphereRadius, v.length());
        }
    }

    void calculateFaceNormalsAndCenters()
    {
        //normal flippingmust be determined of object has no normals

        for (int i =0;i<polygons.size();i++)
        {
            ObjPolygon poly = polygons[i];

            if(poly.v.size()==3)//triangles
            {
                glm::vec3 v1 = vertices[poly.v[0]];
                glm::vec3 v2 = vertices[poly.v[1]];
                glm::vec3 v3 = vertices[poly.v[2]];

                poly.center  += (v1+v2+v3);
                poly.center /= 3.0;

                glm::vec3 tmp1 = v3-v1; glm::normalize(tmp1);
                glm::vec3 tmp2 = v3-v1; glm::normalize(tmp2);

                poly.normal = glm::cross( tmp1, tmp2 );

                polygons[i] = poly;
            }

            if(poly.v.size()==4)//Quads
            {

            }
        }
    }

    void calculateFaceNormals_Centers()
    {
        //normals by average

        for (int i =0;i<polygons.size();i++)
        {
            ObjPolygon poly = polygons[i];

            if(poly.v.size()==3)//triangles
            {

                glm::vec3 v1 = vertices[poly.v[0]];
                glm::vec3 v2 = vertices[poly.v[1]];
                glm::vec3 v3 = vertices[poly.v[2]];

                poly.center  += (v1+v2+v3);
                poly.center /= 3.0;

                glm::vec3 n1 = normals[poly.n[0]];
                glm::vec3 n2 = normals[poly.n[1]];
                glm::vec3 n3 = normals[poly.n[2]];

                poly.normal += (n1+n2+n3);
                poly.normal /= 3.0;

                polygons[i] = poly;
            }

            if(poly.v.size()==4)//Quads
            {

            }
        }
    }

public:

    void drawVertices()
    {
        int i, j;

        glPointSize(5);
        glShadeModel(GL_POINT_SMOOTH);
        glBegin(GL_POINTS);

        //qDebug()<<"Drawing Points:"<<g_mesh.vertices.length();

        for (i =0; i < vertices.size(); i++)
        {
            glm::vec3 v = vertices[i];
            //qDebug()<<"Point:"<<g_mesh.vertices[i].x<<","<<g_mesh.vertices[i].y<<","<<g_mesh.vertices[i].z;
            glVertex3f(v.x,v.y,v.z);
        }
        glEnd();

    }

    void drawNormals()
    {
        int i, j;
        glPushAttrib(GL_LIGHTING_BIT | GL_CURRENT_BIT);
        glDisable(GL_LIGHTING);
        glBegin(GL_LINES);
        glColor3f(0,0,0);

        for (i =0; i < polygons.size(); ++i)
        {
            ObjPolygon poly = polygons[i];

            for (j = 0; j < poly.v.size(); ++j)
            {
                 int vindex = poly.v[j];
                 int nindex = poly.n[j];

                 if (poly.n[j] != NULL)
                 {
                     glm::vec3 v = vertices[vindex];
                     glm::vec3 n = normals[nindex];

                     QVector3D a(v.x,v.y,v.z);
                     QVector3D b(n.x,n.y,n.z);

                     QVector3D m = a+ normalsScale*b;


                     glm::vec3 v1 = glm::vec3(m.x(),m.y(),m.z());

                     // * 0.1 / g_scale;

                     glVertex3f(v.x,v.y,v.z);
                     glVertex3f(v1.x,v1.y,v1.z );
                 }
             }
        }

        glEnd();

        glPopAttrib();
    }

    void drawFaceNormals()
    {
        int i, j;
        glPushAttrib(GL_LIGHTING_BIT | GL_CURRENT_BIT);
        glDisable(GL_LIGHTING);
        glBegin(GL_LINES);
        glColor3f(0,0,0);

        for (i =0; i < polygons.size(); ++i)
        {
            ObjPolygon poly = polygons[i];
            glm::vec3 v = poly.center;

            glm::vec3 v1(0,0,0);
            v1+= poly.center;

            v1 += (poly.normal*normalsScale);

            glVertex3f(v.x,v.y,v.z);
            glVertex3f(v1.x,v1.y,v1.z );

        }

        glEnd();

        glPopAttrib();
    }

    void drawMesh()
    {
        int i, j;


        glEnable(GL_LIGHTING);

        /*
        qDebug()<<"Vertices Count:"<<vertices.size();
        qDebug()<<"normals Count:"<<normals.size();
        qDebug()<<"uvs Count:"<<uvs.size();

        qDebug()<<"vertexIndices:"<<vertexIndices.size();
        qDebug()<<"normalIndices:"<<normalIndices.size();
        qDebug()<<"uvIndices:"<<uvIndices.size();

        */


        glBegin(GL_TRIANGLES);

        for (i =0; i < polygons.size(); i++)
        {
             ObjPolygon poly = polygons[i];

             for (j =0; j < poly.v.size(); j++)
             {
                 unsigned int vertexIndex = poly.v[j];
                 unsigned int normalIndex = poly.n[j];
                 unsigned int uvIndex     = poly.uv[j];

                 glm::vec3 v  = vertices[vertexIndex];
                 glm::vec3 n  = normals[normalIndex];
                 glm::vec2 uv = uvs[uvIndex];

                 glVertex3f(v.x,v.y,v.z);

                 if(normals.size()>0)
                 glNormal3f(n.x,n.y,n.z);

                 if(uvs.size()>0)
                     glTexCoord2f(uv.x,uv.y);
            }
        }

        glEnd();
        glDisable(GL_LIGHTING);

        //drawVertices();

        drawNormals();

        //drawFaceNormals();
    }

};




//using namespace glm;
/*
class Xyz
{
public:
    float x, y, z;
};

class Uvw
{
public:
    float u, v, w;
};



class tagTriangle
{
public:
    QList<int> v;
    QList<int> n;
    QList<int> t;


} ;
class tagTriangle
{
public:
    int v[3];
    int n[3];
    int t[3];
} ;




class tagObjMesh
{
public:
    QList<Xyz>vertices;
    QList<Xyz>normals;
    QList<Xyz>texcoords;

    QList<tagTriangle> triangles;
};


class Obj
{
    float g_scale = 1;
    bool g_normalize = true;
    bool g_lighting = true;
    tagObjMesh g_mesh;// = NULL;
    int handlecase = 0;
    int handle =0;


public:

    Obj()
    {
        qDebug()<<"Obj class initialised";
        //LoadModel();
        //g_mesh = loadObjFile("torus.obj");
        //g_mesh = loadObjFile("D:/QT docs/Cube Omiverse C++ version 1 - QT 4.8.6/Cube/sponge.obj");
        //g_mesh = loadObjFile("D:/QT docs/Cube Omiverse C++ version 1 - QT 4.8.6/Cube/particles1.obj");
        //g_mesh = loadObjFile("D:/QT docs/Cube Omiverse C++ version 1 - QT 4.8.6/Cube/agapi.obj");
        g_mesh = loadObjFile("D:/QT docs/Cube Omiverse C++ version 1 - QT 4.8.6/Cube/wall.obj");


    }

    ~Obj()
    {

    }
    void LoadModel()
    {
        //g_mesh = loadObjFile(":/torus.obj");

    }


private:


    tagObjMesh loadObjFile(const char* filename);


    void parseFace(char const* buf,tagObjMesh mesh);
    char const* parseCorner(char const* buf,tagTriangle face,int i);
    char const* parseTriangle(char const* buf,tagTriangle face);


    void drawNormals()
    {
        int i, j;
        glPushAttrib(GL_LIGHTING_BIT | GL_CURRENT_BIT);
        glDisable(GL_LIGHTING);
        glBegin(GL_LINES);
        glColor3f(0,0,0);       

        for (i =0; i < g_mesh.triangles.length(); ++i)
        {
            tagTriangle face = g_mesh.triangles[i];

            for (j = 0; j < 3; ++j)
            {
                 int vj = face.v[j];
                 int nj = face.n[j];

                 if (face.n[j] != NULL)
                 {
                     glVertex3fv(&g_mesh.vertices[vj].x);

                     glVertex3f( g_mesh.vertices[vj].x + g_mesh.normals[nj].x * 0.1 / g_scale,
                                    g_mesh.vertices[vj].y + g_mesh.normals[nj].y * 0.1 / g_scale,
                                    g_mesh.vertices[vj].z + g_mesh.normals[nj].z * 0.1 / g_scale );

                 }
             }
        }

        glEnd();

        glPopAttrib();
    }

    void drawMesh()
    {
        int i, j;

        glPointSize(3);
        glShadeModel(GL_POINT_SMOOTH);
        glBegin(GL_POINTS);

        //qDebug()<<"Drawing Points:"<<g_mesh.vertices.length();

        for (i =0; i < g_mesh.vertices.length(); ++i)
        {
            //qDebug()<<"Point:"<<g_mesh.vertices[i].x<<","<<g_mesh.vertices[i].y<<","<<g_mesh.vertices[i].z;
            glVertex3f(g_mesh.vertices[i].x,g_mesh.vertices[i].y,g_mesh.vertices[i].z);
        }
        glEnd();

        //glBegin(GL_TRIANGLES);



        //qDebug()<<"Number of triangels:"<<g_mesh.triangles.length();

        for (i =0; i < g_mesh.triangles.length(); ++i)
        {
            tagTriangle face = g_mesh.triangles[i];

            for (j = 0; j < 3; ++j)
            {
                glVertex3fv(&g_mesh.vertices[g_mesh.triangles[i].v[j]].x);


                if (face.n[j] !=NULL)
                    glNormal3fv(&g_mesh.normals[face.n[j]].x);

                if (face.t[j]!=NULL)
                    glTexCoord3fv(&g_mesh.texcoords[face.t[j]].x);


            }
        }

        glEnd();


    }
public:

    void displayObj()
    {
        drawMesh();

        float red[] = {1,0,0,1};
        float blue[] = {0,0,1,1};

        //glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        if (g_lighting)
        {
            glEnable(GL_LIGHTING);
        }

        else
        {
            glDisable(GL_LIGHTING);
        }

        glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);
        glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, red);
        glMaterialfv(GL_BACK,  GL_AMBIENT_AND_DIFFUSE, blue);

       //
        //if (g_normalize)
            //glEnable(GL_NORMALIZE);
       // else
//            glDisable(GL_NORMALIZE);
       //
         //glEnable(GL_NORMALIZE);



       // glLoadIdentity();

       //

        //glRotated(g_y_angle, 0, 1,0);
        //drawAxes(0.2);

        //glRotated(g_x_angle, 1, 0,0);

        //drawAxes(0.2);




        glScalef(g_scale, g_scale, g_scale);

        glPushAttrib(GL_LIGHTING_BIT | GL_CURRENT_BIT);
        glDisable(GL_LIGHTING);
        glColor3f(0,0,0);

        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
        drawMesh();

        glColor3f(0,0,0);

        glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
        glPointSize(7);
        glEnable(GL_POINT_SMOOTH);
        drawMesh();

        drawNormals();

        glPopAttrib();

        glEnable(GL_POLYGON_OFFSET_FILL);
        glPolygonOffset(1,1);
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
        glColor3f(1,1,1);
        drawMesh();
        glDisable(GL_POLYGON_OFFSET_FILL);


        //drawNormals();
    }

};
*/


#endif // IMPORTOBJ_H
