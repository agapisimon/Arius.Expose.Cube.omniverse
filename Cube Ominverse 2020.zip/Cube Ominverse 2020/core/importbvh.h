#ifndef IMPORTBVH_H
#define IMPORTBVH_H
#include<QtOpenGL>
#include<stdio.h>
#include<stdlib.h>
#include<istream>
#include<vector>
#include<glm/glm.hpp>
#include<glm/gtc/matrix_transform.hpp>
#include<fstream>
#include <algorithm>
#include <string>
#include <sstream>

// trim from start
static inline std::string &ltrim(std::string &s)
{
   s.erase(s.begin(), std::find_if(s.begin(), s.end(), std::not1(std::ptr_fun<int, int>(std::isspace))));
   return s;
}

// trim from end
static inline std::string &rtrim(std::string &s)
{
   s.erase(std::find_if(s.rbegin(), s.rend(), std::not1(std::ptr_fun<int, int>(std::isspace))).base(), s.end());
   return s;
}

// trim from both ends
static inline std::string &trim(std::string &s)
{
   return ltrim(rtrim(s));
}


#define Xposition 0x01
#define Yposition 0x02
#define Zposition 0x04
#define Zrotation 0x10
#define Xrotation 0x20
#define Yrotation 0x40



typedef struct
{
    float x, y, z;
} OFFSET;



//typedef struct JOINT JOINT;

class JOINT
{
public:
    const char* name = NULL;        // joint name
    JOINT* parent = NULL;           // joint parent
    std::vector<JOINT*> children;   // joint's children

    glm::mat4 matrix;         // local transofrmation matrix (premultiplied with parents)
    OFFSET offset;                  // offset data

    unsigned int num_channels = 0;  // num of channels joint has
    short* channels_order = NULL;   // ordered list of channels


    unsigned int channel_start = 0; // index of joint's channel data in motion array
};

typedef struct
{
    JOINT* rootJoint;
    int num_channels;
} HIERARCHY;

typedef struct
{
    unsigned int num_frames;              // number of frames
    unsigned int num_motion_channels = 0; // number of motion channels
    float* data = NULL;                   // motion float data array
    unsigned* joint_channel_offsets;      // number of channels from beggining of hierarchy for i-th joint
} MOTION;



class Bvh
{
    JOINT* loadJoint(std::istream& stream, JOINT* parent = NULL);
    void loadHierarchy(std::istream& stream);
    void loadMotion(std::istream& stream);
public:
    Bvh();
    ~Bvh();

    // loading
    void load(const std::string& filename);

    /** Loads motion data from a frame into local matrices */
    void moveTo(unsigned frame);

    const JOINT* getRootJoint() const { return rootJoint; }
    unsigned getNumFrames() const { return motionData.num_frames; }
private:
    JOINT* rootJoint;
    MOTION motionData;
};



class importbvh
{
public:
    importbvh();

    std::vector<glm::vec4> vertices;
    std::vector<GLshort>   indices;

    GLuint bvhVAO;
    GLuint bvhVBO;
    Bvh* bvh = NULL;

    void tmpProcess(JOINT*            joint,
                    std::vector<glm::vec4>& vertices,
                    std::vector<GLshort>&   indices,
                    GLshort                 parentIndex = 0)
    {
        // translated vertex is last column(row of transponse) joint's matrix
        glm::vec4 translatedVertex = joint->matrix[3];

        vertices.push_back(translatedVertex);

        GLshort myindex = vertices.size() - 1;

        if( parentIndex != myindex )
        {
            indices.push_back(parentIndex);
            indices.push_back(myindex);
        }

        /////////////////////////////
        //for(auto& child : joint->children)
        //    tmpProcess(child, vertices, indices, myindex);
    }


    /** put translated joint vertices into array */
    void bvh_to_vertices(JOINT*                  joint,
                         std::vector<glm::vec4>& vertices,
                         std::vector<GLshort>&   indices,
                         GLshort                 parentIndex = 0)
    {
        // vertex from current joint is in 4-th ROW (column-major ordering)
        glm::vec4 translatedVertex = joint->matrix[3];

        // pushing current
        vertices.push_back(translatedVertex);

        // avoid putting root twice
        GLshort myindex = vertices.size() - 1;
        if( parentIndex != myindex )
        {
            indices.push_back(parentIndex);
            indices.push_back(myindex);
        }

        // foreach child same thing
        ////////////
        /*
        for(auto& child : joint->children)
            tmpProcess(child, vertices, indices, myindex);
        */
    }

    void bvh_load_upload(int frame = 1)
    {
        // using Bvh class
        if( bvh == NULL )
        {
            bvh = new Bvh;
            bvh->load("file.bvh");
        }

        bvh->moveTo(frame);

        JOINT* rootJoint = (JOINT*) bvh->getRootJoint();
        bvh_to_vertices(rootJoint, vertices, indices);

        // here goes OpenGL stuff with gen/bind buffer and sending data
        // basically you want to use GL_DYNAMIC_DRAW so you can update same VBO
    }
};


/*
typedef struct
{
    float x, y, z;
} OFFSET;

typedef struct JOINT JOINT;

struct JOINT
{
    const char* name = NULL;        // joint name
    JOINT* parent = NULL;           // joint parent
    OFFSET offset;                  // offset data
    unsigned int num_channels = 0;  // num of channels joint has
    short* channels_order = NULL;   // ordered list of channels
    std::vector<JOINT*> children;   // joint's children
    glm::mat4 matrix;               // local transofrmation matrix (premultiplied with parents'
    unsigned int channel_start = 0; // index of joint's channel data in motion array
};

typedef struct
{
    JOINT* rootJoint;
    int num_channels;
} HIERARCHY;

typedef struct
{
    unsigned int num_frames;              // number of frames
    unsigned int num_motion_channels = 0; // number of motion channels
    float* data = NULL;                   // motion float data array
    unsigned* joint_channel_offsets;      // number of channels from beggining of hierarchy for i-th joint
} MOTION;

class Bvh
{
    JOINT* loadJoint(std::istream& stream, JOINT* parent = NULL);
    void loadHierarchy(std::istream& stream);
    void loadMotion(std::istream& stream);
public:
    Bvh();
    ~Bvh();

    // loading
    void load(const std::string& filename);

    // Loads motion data from a frame into local matrices
    void moveTo(unsigned frame);

    const JOINT* getRootJoint() const { return rootJoint; }
    unsigned getNumFrames() const { return motionData.num_frames; }
private:
    JOINT* rootJoint;
    MOTION motionData;
};



class importbvh
{
public:
    importbvh();

    std::vector<glm::vec4> vertices;
    std::vector<GLshort>   indices;

    GLuint bvhVAO;
    GLuint bvhVBO;
    Bvh* bvh = NULL;

    void tmpProcess(JOINT*            joint,
                    std::vector<glm::vec4>& vertices,
                    std::vector<GLshort>&   indices,
                    GLshort                 parentIndex = 0)
    {
        // translated vertex is last column(row of transponse) joint's matrix
        glm::vec4 translatedVertex = joint->matrix[3];

        vertices.push_back(translatedVertex);

        GLshort myindex = vertices.size() - 1;

        if( parentIndex != myindex )
        {
            indices.push_back(parentIndex);
            indices.push_back(myindex);
        }

        /////////////////////////////
        //for(auto& child : joint->children)
        //    tmpProcess(child, vertices, indices, myindex);
    }


    /// put translated joint vertices into array
    void bvh_to_vertices(JOINT*                  joint,
                         std::vector<glm::vec4>& vertices,
                         std::vector<GLshort>&   indices,
                         GLshort                 parentIndex = 0)
    {
        // vertex from current joint is in 4-th ROW (column-major ordering)
        glm::vec4 translatedVertex = joint->matrix[3];

        // pushing current
        vertices.push_back(translatedVertex);

        // avoid putting root twice
        GLshort myindex = vertices.size() - 1;
        if( parentIndex != myindex )
        {
            indices.push_back(parentIndex);
            indices.push_back(myindex);
        }

        // foreach child same thing
        ////////////

        //for(auto& child : joint->children)
        //    tmpProcess(child, vertices, indices, myindex);

    }

    void bvh_load_upload(int frame = 1)
    {
        // using Bvh class
        if( bvh == NULL )
        {
            bvh = new Bvh;
            bvh->load("file.bvh");
        }

        bvh->moveTo(frame);

        JOINT* rootJoint = (JOINT*) bvh->getRootJoint();
        bvh_to_vertices(rootJoint, vertices, indices);

        // here goes OpenGL stuff with gen/bind buffer and sending data
        // basically you want to use GL_DYNAMIC_DRAW so you can update same VBO
    }
};

*/

#endif // IMPORTBVH_H
