#ifndef SCENE_H
#define SCENE_H
#include<QtWidgets>

#include<core/mesh.h>
#include<core/light.h>
#include<core/camera.h>
#include<core/Material.h>
#include<core/curve.h>
#include<core/text.h>
#include<core/text3d.h>
#include<vector>



// Edit mode
enum EDITSTATE
{
    NOEDIT,
    SELECTOBJECT,
    ROTATEOBJECT,
    MOVEOBJECT,
    SCALEOBJECT,
    SELROTATEOBJECT,
    SELMOVEOBJECT,
};

// Edit Level
enum EDITLEVEL
{
    OBJ,
    MODEL,
    MESH,
    TRIANGLE,
    POLYGON,
    EDGE,
    VERTEX,
    ATCH_POINTS, //Auran Jet specific: Attachment points
    BONES,
    CAMERAS,
    LIGHTS
};
// object manipulation mode
enum  EditMode
{
    Off = 0, //All features are off.
    Select = 1,
    Rotate = 2,
    SelectAndMove = 3,
    SelectFromList = 4,
};


class Scene
{
public:
    std::vector<Text> texts;
    std::vector<Text3D> _3dtexts;
    std::vector<Curve2D> curves;
    std::vector<Curve3D> curves_3d;
    //std::vector<Camera> cameras;
    std::vector<Mesh> meshes;
    std::vector<Light> lights;
    std::vector<Material1>materials;

    bool drawLights;
    bool drawMeshes;
    bool drawCameras;
    bool useMaterials;

private:
    void RemoveMeshes()
    {
        m_OpaqueMeshList.clear();
        m_SemiOpaqueMeshList.clear();
        m_AlphaMeshList.clear();
    }

    void DrawMeshesOrdered(DWORD curRenderMode)
    {
        DrawMeshList(m_OpaqueMeshList, curRenderMode);
        DrawMeshList(m_SemiOpaqueMeshList, curRenderMode);
        DrawMeshList(m_AlphaMeshList, curRenderMode);
    }

    void DrawMeshList(std::vector<Mesh>meshList, DWORD curRenderMode)
    {
        for(int meshIndex = 0; meshIndex < meshList.size();meshIndex++)
        {
            //((Mesh)(meshList[meshIndex]))->Draw(curRenderMode);

        }
    }


    std::vector<Mesh>m_MeshList;

    static  std::vector<Mesh> m_OpaqueMeshList;	  // all opaque meshes
    static  std::vector<Mesh> m_SemiOpaqueMeshList;// meshes that belong to a model with at least one opaque mesh
    static  std::vector<Mesh> m_AlphaMeshList;	  // meshes that belong to a model with no opaque meshes

    std::vector<Model>drawableObjects;
    std::vector<Model>selectionSet;

    Model m_PickedModel;
    bool m_bRotateSelSet;

public:
    bool m_bMoveSelSet;
    bool m_bSelect;

    Scene();

    /*



    void LoadModel(Model model)
    {
        Model m = (Model)model;

        drawableObjects.push_back(m);

        for(int meshIndex = 0; meshIndex < m->MeshCount;meshIndex++)
        {
            //add all meshes to global mesh list
            Mesh mesh = m->MeshList[meshIndex];
            m_MeshList.push_back(mesh);
        }

        bool bModelHasOpaqueMesh = false;
        for(int meshIndex = 0; meshIndex < m->MeshCount;meshIndex++)
        {
            Mesh mesh = m.MeshList[meshIndex];
            if(!mesh->HasAlphaChannel)
            {
                bModelHasOpaqueMesh = true;
                m_OpaqueMeshList->Add(mesh);
            }
        }

        if(bModelHasOpaqueMesh)
        {
            //put alpha meshes into semi-opaque list
            for(int meshIndex = 0; meshIndex < m->MeshCount;meshIndex++)
            {
                Mesh^ mesh = m->MeshList[meshIndex];
                if(mesh->HasAlphaChannel)
                {
                    m_SemiOpaqueMeshList->Add(mesh);
                }
            }
        }
        else
        {
            //put alpha meshes into all alpha list
            for(int meshIndex = 0; meshIndex < m->MeshCount;meshIndex++)
            {
                Mesh mesh = m->MeshList[meshIndex];
                if(mesh->HasAlphaChannel)
                {
                    m_AlphaMeshList->Add(mesh);
                }
            }
        }
    }

    void MoveSelectionSetDelta(glm::vec3 deltaPos)
    {
        UpdateSelSetWorldPos(deltaPos.x, deltaPos.z, deltaPos.y);
    }

    void MoveSelectionSet(glm::vec3 next3DPos)
    {

        static bool bMouseIsMoving = false;
        // ready for some over engineering
        static float LastXPos = 0;
        static float LastYPos = 0;
        static float LastZPos = 0;

        float NextXPos = next3DPos.x;
        float NextYPos = next3DPos.y;
        float NextZPos = next3DPos.z;

        float xDelta = 0.0f;
        float yDelta = 0.0f;
        float zDelta = 0.0f;

        if(m_bMoveSelSet == true)
        {
             if(bMouseIsMoving)
             {
                 // from flight sim co-ordinates back to opengl co-ordinates
                 // TO DO: abstract the co-ordinate system change to some lower and more
                 // consistent level
                 xDelta = (NextXPos - LastXPos);
                 zDelta = (NextYPos - LastYPos);
                 yDelta = (NextZPos - LastZPos);

                 UpdateSelSetWorldPos(xDelta, yDelta, zDelta);
             }
             // unintuitive processing: this line is typically processed first
             // when movement is activated to get the mouse position
             // to start moving from and then processing continues
             // in the logic above until movement is deactivated by
             // m_bMoveSelSet being false
             bMouseIsMoving = true;
             LastXPos = NextXPos;
             LastYPos = NextYPos;
             LastZPos = NextZPos;
        }
        else
        {
            bMouseIsMoving = false;
            LastXPos = 0;
            LastYPos = 0;
            LastZPos = 0;
        }

    }


    void UpdateSelSetWorldPos(float xDelta, float yDelta, float zDelta)
     {
         glm::vec3 deltaV = glm::vec3(xDelta, yDelta, zDelta);

         for(int i = 0; i < selectionSet.size(); i++)
         {
            Model model = (Model)selectionSet[i];

            model.worldpos += deltaV;

         }
     }

    /// Removes all Drawable objects

    void ClearModels()
    {
        if (drawableObjects.size()>0)
        {
            int cnt = drawableObjects.size();

            for(int i = 0; i < drawableObjects.size(); i++)
            {
                ((Model^)(drawableObjects[i]))->ReleaseRetainedResources();
            }

            drawableObjects->RemoveRange(0, cnt);
            RemoveMeshes();
        }
        selectionSet.clear();
    }

    void DrawSceneMeshes(DWORD curRenderMode)
    {
        if(curRenderMode & (DWORD)SceneRenderMode::PickGLModel)
            DrawObjectsInPickMode();
        else
        {
            glPushMatrix();
            DrawMeshesOrdered(curRenderMode);
            glPopMatrix();
        }
        DrawPickedObjectGadget();
    }

    void DrawObjectsInPickMode()
    {
        for(int i = 0; i < drawableObjects.size(); i++)
        {
            Model m = (Mode)drawableObjects[i];

            m->DrawPickModeModel();
        }
    }

    void SetEditModeRotateOn(bool on)
    {
        m_bRotateSelSet = on;
    }

    void SetEditModeMoveOn(bool on)
    {
        m_bMoveSelSet = on;
    }

    void SetEditModeSelectOn(bool on)
    {
        m_bSelect = on;
    }

    void AddToSelectionSet(Model model)
    {
        // Add to selectionSet iff not already in it
        for(int i = 0; i < selectionSet.size(); i++)
        {
            if(model == selectionSet[i])
            {
                return;
            }
        }
        model->Selected = true;
        this->selectionSet->Add(model);
    }

    void DrawPickedObjectGadget()
    {
        if(m_PickedModel == nullptr)return;

        m_PickedModel->DrawTranformGadget();
    }

    void SelectPickedModelByColor(std::vector<unsigned char> color, AxisTripod^ axisTripod)
    {
        PickedModel = nullptr;
        //bool bFoundSelected = false;
        for(int i = 0; i < drawableObjects->Count; i++)
        {
            Model m = (Model)(drawableObjects[i]);

            std::vector<unsigned char>c = m->PickColor;

            if(c[0] == color[0] && c[1] == color[1] && c[2] == color[2])
            {
                PickedModel = m;
                //picked model is already selected
                if(PickedModel->Selected)
                {
                    if(m_bSelect == true)
                    {
                        if (selectionSet->Count > 1 )
                        {
                            //a number of models are selected; unselect all others except Picked one
                            //this->UnselectAll(PickedModel);
                            this->UnselectAllModels(nullptr);
                            AddToSelectionSet(PickedModel);
                            PickedModel->AttachGadget(axisTripod);
                        }
                    }
                    return;
                }
                else// Picked model is not already selected
                {
                    this->UnselectAllModels(nullptr);
                    AddToSelectionSet(PickedModel);
                    PickedModel->AttachGadget(axisTripod);
                }
                break;
            }
        }

        // nothing selected
        if(PickedModel == nullptr)
        {
            this->UnselectAllModels(nullptr);
            return;
        }

    }

    void UnselectAllModels(Model exceptThisModel)
    {
        if(exceptThisModel == nullptr)
        {
            for(int i = 0; i < selectionSet->Count; i++)
                ((Model^)(selectionSet[i]))->Selected = false;
            selectionSet->Clear();
            return;
        }
        for(int i = 0; i < selectionSet->Count; i++)
        {
            Model m = (Model)(selectionSet[i]);
            if(exceptThisModel == nullptr)
                m->Selected = false;
            else
            {
                if(m != exceptThisModel)
                    m->Selected = false;
            }
        }
        if(exceptThisModel == nullptr)
            selectionSet->Clear();
    }



    property Model^ PickedModel
    {
        Model^ get(){ return m_PickedModel;}
        void set(Model^ model){m_PickedModel = model;}
    }

    property int getSelectionSetSize
    {
        int get(){ return selectionSet->Count;}
        //void set(Model^ model){m_PickedModel = model;}
    }

    */


};



#endif // SCENE_H
