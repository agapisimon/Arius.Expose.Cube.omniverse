#ifndef CURVE_H
#define CURVE_H
#include<QtWidgets>
#include<QtOpenGL>
#include<QObject>
#include<GL/glu.h>

class InterpolationFunctions
{
    //Interpolation Functions – Smoothstep, Gamma, Bias, Gain
    qreal Smoothstep(qreal a, qreal b, qreal factor)
    {
        /*
        if factor < 0
            return 0.0;

        if factor > b
            return 1.0;
        */
        factor = (factor - a) / (b - a);

        qreal c = factor * factor * (3 - 2 * factor);

        return c;
    }


    qreal gammacorrect(qreal gamma, qreal factor)
    {
        return pow(factor, 1.0 / gamma);
    }


    qreal bias(qreal b, qreal factor)
    {
        return pow(factor, log(b) / log(0.5));
    }

    qreal gain(qreal g=0.8, qreal factor=0)
    {
        if (factor < 0.5)
        {

            return bias(1 - g, 2 * factor) / 2;
        }
        else
            return 1 - bias(1 - g, 2 - 2 * factor) / 2;
    }
};

class CurvePoint2D
{
public:
    QVector2D C0;
    QVector2D left;
    QVector2D P;
    QVector2D right;
    QVector2D C1;


    CurvePoint2D(QVector2D _P)
    {
       P = _P;

       right = QVector2D(1,0);
       left = QVector2D(-1,0);

       C0 = P + left;
       C1 = P + right;
    }

    CurvePoint2D()
    {
       P = QVector2D(0,0);

       right = QVector2D(1,0);
       left = QVector2D(-1,0);

       C0 = P + left;
       C1 = P + right;
    }

    void offsetPoint(QVector2D delta)
    {
        P  += delta;

        C0 += delta;
        C1 += delta;

        left = C0 -P;
        right = C1 -P;
    }

    void rotateHandle()
    {
        QVector2D dir  = C1-C0;

    }

    void setPoint(QVector2D _P)
    {
        P = _P;

        right = QVector2D(1,0);
        left = QVector2D(-1,0);

        C0 = P + left;
        C1 = P + right;
    }

};

class Curve2D
{
    QList<QVector2D> allpoints;
    QList<CurvePoint2D> points;

    int count =0;
    QSize bounds;
    bool iscurve = true;

public:

    Curve2D()
    {
        //bounds = QSize()
        CurvePoint2D p;
        p.setPoint(QVector2D(0,0));
        points.append(p);
        //qDebug()<<"curvePoints:"<<p.P;

        CurvePoint2D p1;
        p1.setPoint(QVector2D(3,-2));
        points.append(p1);
        //qDebug()<<"curvePoints:"<<p1.P;

        CurvePoint2D p3;
        p3.setPoint(QVector2D(5,3));
        points.append(p3);
        //qDebug()<<"curvePoints:"<<p3.P;

        CurvePoint2D p4;
        p4.setPoint(QVector2D(38,-4));
        points.append(p4);
        //qDebug()<<"curvePoints:"<<p4.P;

        CurvePoint2D p5;
        p5.setPoint(QVector2D(100,5));
        points.append(p5);
        //qDebug()<<"curvePoints:"<<p5.P;


        CurvePoint2D p6;
        p6.setPoint(QVector2D(150,0));
        points.append(p6);
        //qDebug()<<"curvePoints:"<<p6.P;
    }

    void addPoint(QVector2D p)
    {
        points.append(p);
    }


    QVector2D bezierInterpolate2D(qreal t, QVector2D P0, QVector2D P1, QVector2D P2, QVector2D P3)
    {
        //cubic bezier curves
        //P(t) = (1-t)^3 p0 + 3t(1-t)^2p1+   3t^2(1-t)p2 + t^3p3 where t range {0,1}

        //qDebug()<<"bezier Interpolate2D";

        qreal c0 = pow((1 - t), 3);

        qreal c1 = 3 * t * (1 - t) * (1 - t);
        qreal c2 = 3 * t * t * (1 - t);
        qreal c3 = pow(t, 3);

        qreal x = P0.x() * c0 + P1.x() * c1 + P2.x() * c2 + P3.x() * c3;
        qreal y = P0.y() * c0 + P1.y() * c1 + P2.y() * c2 + P3.y() * c3;
        //qreal z = P0.z() * c0 + P1.z() * c1 + P2.z() * c2 + P3.z() * c3;

        QVector2D P(x,y);

        //qDebug()<<"x:"<<P.x();
        //qDebug()<<"y:"<<P.y();

        return P;
    }

    void getAllInterpolatedPoints(const int &resolution)
    {
        //qDebug()<<"get All Interpolated Points";
        //qDebug()<<"npoints:"<<points.length();

        for(int i=0; i<points.length()-1; i++)
        {
            CurvePoint2D v = points[i];
            CurvePoint2D u = points[i+1];

            QVector2D P0 = v.P;
            QVector2D P1 = v.C1;
            QVector2D P2 = u.C0;
            QVector2D P3 = u.P;

            //qDebug()<<"index:"<<i;
            //qDebug()<<"C1:"<<v.C1;
            //qDebug()<<"C0:"<<u.C0;

            //cubic bezier curves
            //P(t) = (1-t)^3 p0 + 3t(1-t)^2p1+   3t^2(1-t)p2 + t^3p3 where t range {0,1}

            qreal step = (qreal)1 / resolution;

            for(int i=0;i<(resolution + 1);i++)
            {
               qreal t = i * step;

               QVector2D p = bezierInterpolate2D(t, P0, P1, P2, P3);

               allpoints.append(p);

               //qDebug()<<"interpolated p:"<<p<<"index:"<<i;
            }
        }

        //qDebug()<<"total points:"<<allpoints.length();
    }


    void  selectControlPoints()
    {
      for(int i=0;i<points.length();i++)
      {
          glColor3f(0,255,0);

          QVector2D v = points[i].P;

          glLoadName(i);
          glBegin(GL_POINTS);
          glVertex2f(v.x(),v.y());
          glEnd();
      }
    }

    void drawControlPoints()
    {
        glEnable(GL_POINT_SMOOTH);
        glPointSize(10);
        glBegin(GL_POINTS);
        float ligthorange[3] = {225,177,109};

        for(int i=0;i<points.length();i++)
        {
            glColor3f((qreal)ligthorange[0]/255,(qreal)ligthorange[1]/255,(qreal)ligthorange[2]/255);

            QVector2D v = points[i].P;
            glVertex2f(v.x(),v.y());
            //qDebug()<<"vertex"<<v;
        }

        glEnd();
        glDisable(GL_POINT_SMOOTH);
    }

    void drawHandles()
    {
        glPointSize(5);
        glBegin(GL_POINTS);

        for(int i=0;i<points.length();i++)
        {
           QVector2D v = points[i].C0;
           QVector2D u = points[i].C1;

           glColor3f((qreal)200/255,(qreal)200/255,(qreal)200/255);

           glVertex2f(v.x(),v.y());
           glVertex2f(u.x(),u.y());
        }

        glEnd();

        glBegin(GL_LINES);

        for(int i=0;i<points.length();i++)
        {
           QVector2D v = points[i].C0;
           QVector2D u = points[i].C1;

           glColor3f((qreal)100/255,(qreal)232/255,(qreal)214/255);

           glVertex2f(v.x(),v.y());
           glVertex2f(u.x(),u.y());
        }

        glEnd();

    }

    void drawCurveStrip()
    {
        glBegin(GL_LINE_STRIP);

        for(int i=0;i<allpoints.length();i++)
        {
            QVector2D v = allpoints[i];

            glColor3f((qreal)9/255,(qreal)232/255,(qreal)214/255);

            glVertex2f(v.x(),v.y());
        }

        glEnd();

        //qDebug()<<"finished Drawing Curve";
    }

    void drawAnimatedCurveStrip()
    {
        glBegin(GL_LINE_STRIP);

        //for(int i=0;i<allpoints.length();i++)
        for(int i=0;i<count;i++)
        {
            QVector2D v = allpoints[i];

            glColor3f((qreal)9/255,(qreal)232/255,(qreal)214/255);

            glVertex2f(v.x(),v.y());
        }

        glEnd();

        if(count<allpoints.length())
            count += 1;
        else
            count =0;

        //qDebug()<<"finished Drawing Curve";
    }

    void drawCurve2D()
    {
        int resolution =50;

        //qDebug()<<"Drawing Curve";
        //qDebug()<<"resolution"<<resolution;

        if(allpoints.length()==0)
            getAllInterpolatedPoints(resolution);


        drawCurveStrip();

        drawHandles();

        drawControlPoints();

        //selectControlPoints();
    }

    void drawCurve2D(bool ifcurve = false)//QPainter *painter)
    {
        QPainterPath path;

        QGraphicsPolygonItem * polygonItem  = new QGraphicsPolygonItem;

        for (int i=0;points.length()-1;i++)
        {

            QVector2D P0 = points[i].P;//line is inherited from QGraphicsLineItem
            QVector2D P3 = points[i+1].P;//line is inherited from QGraphicsLineItem


            QPoint p0 =QPoint(P0.x(),P0.y());
            QPoint p3 =QPoint(P3.x(),P3.y());

            if(iscurve)
            {
                QVector2D dp  = P3-P0;
                qreal bias  = 0.4*abs(dp.x());

                QVector2D P1 = P0 + QVector2D(-bias, 0);
                QVector2D P2 = P3 + QVector2D(bias, 0);

                QPoint p1 =QPoint(P1.x(),P1.y());
                QPoint p2 =QPoint(P2.x(),P2.y());


                path.moveTo(p0);
                path.cubicTo(p1, p2, p3);
            }
            else//line
            {
                path.moveTo(p0);
                path.lineTo(p3);
            }
        }

        //painter->drawPath(path);//draw a filled shape

        polygonItem->setPolygon(path.toFillPolygon());

        /*
        QPainterPathStroker stroker;
        stroker.setWidth(0.3);
        stroker.createStroke(path);
        painter->drawPath(stroker.createStroke(path));// a stroke
        */


    }



};

class CurvePoint3D
{
public:
    QVector3D C0;
    QVector3D left;
    QVector3D P;
    QVector3D right;
    QVector3D C1;


    CurvePoint3D(QVector3D _P)
    {
       P = _P;

       right = QVector3D(0,0,1);
       left = QVector3D(0,0,-1);

       C0 = P + left;
       C1 = P + right;
    }

    CurvePoint3D()
    {
       P = QVector3D(0,0,0);

       right = QVector3D(0,0,1);
       left = QVector3D(0,0,-1);

       C0 = P + left;
       C1 = P + right;
    }

    void offsetPoint(QVector3D delta)
    {
        P  += delta;

        C0 += delta;
        C1 += delta;

        left = C0 -P;
        right = C1 -P;
    }

    void rotateHandle()
    {
        QVector3D dir  = C1-C0;
        /*

        QVector3D dir = target-pos;

        QQuaternion u = QQuaternion::fromAxisAndAngle(QVector3D(0,1,0),-1*delta.x());
        QQuaternion v = QQuaternion::fromAxisAndAngle(QVector3D(1,0,0),-1*delta.y());

        QVector3D newDir   = u.rotatedVector(dir);
        QVector3D finalDir = v.rotatedVector(newDir);

        pos = target- finalDir;
        */

    }

    void setPoint(QVector3D _P)
    {
        P = _P;

        right = QVector3D(0,0,1);
        left = QVector3D(0,0,-1);

        C0 = P + left;
        C1 = P + right;
    }

};

class Curve3D
{
    float lightcyan[3] = {9,232,214};

    QList<QVector3D> allpoints;
    QList<CurvePoint3D> points;
    QTimer timer;
    int count =0;
    //QLinkedList<CurvePoint3D> linkedPoints;
public:

    Curve3D()
    {
        CurvePoint3D p;
        p.setPoint(QVector3D(0,0,0));
        points.append(p);
        //qDebug()<<"curvePoints:"<<p.P;

        CurvePoint3D p1;
        p1.setPoint(QVector3D(0,2,1));
        points.append(p1);
        //qDebug()<<"curvePoints:"<<p1.P;

        CurvePoint3D p3;
        p3.setPoint(QVector3D(0,0,3));
        points.append(p3);
        //qDebug()<<"curvePoints:"<<p3.P;

        CurvePoint3D p4;
        p4.setPoint(QVector3D(0,3,4));
        points.append(p4);
        //qDebug()<<"curvePoints:"<<p4.P;

        CurvePoint3D p5;
        p5.setPoint(QVector3D(2,0,2));
        points.append(p5);
        //qDebug()<<"curvePoints:"<<p5.P;


        CurvePoint3D p6;
        p6.setPoint(QVector3D(.5,0,.1));
        points.append(p6);
        //qDebug()<<"curvePoints:"<<p6.P;
    }

    QVector3D bezierInterpolate3D(qreal t, const QVector3D &P0, const QVector3D &P1, const QVector3D &P2, const QVector3D &P3)
    {
        //qDebug()<<"bezier Interpolate3D";
        //cubic bezier curves
        //P(t) = (1-t)^3 p0 + 3t(1-t)^2p1+   3t^2(1-t)p2 + t^3p3 where t range {0,1}

        qreal c0 = pow((1 - t), 3);

        qreal c1 = 3 * t * (1 - t) * (1 - t);
        qreal c2 = 3 * t * t * (1 - t);
        qreal c3 = pow(t, 3);

        qreal x = P0.x() * c0 + P1.x() * c1 + P2.x() * c2 + P3.x() * c3;
        qreal y = P0.y() * c0 + P1.y() * c1 + P2.y() * c2 + P3.y() * c3;
        qreal z = P0.z() * c0 + P1.z() * c1 + P2.z() * c2 + P3.z() * c3;

        QVector3D P(x,y,z);

        //qDebug()<<"x:"<<P.x();
        //qDebug()<<"y:"<<P.y();

        return P;
    }

    void clearAllPoints()
    {
        //allpoints.clear();
    }

    void getAllInterpolatedPoints(const int &resolution)
    {
        //qDebug()<<"get All Interpolated Points";
        //qDebug()<<"npoints:"<<points.length();

        for(int i=0;i<points.length()-1;i++)
        {
            CurvePoint3D v = points[i];
            CurvePoint3D u = points[i+1];

            QVector3D P0 = v.P;
            QVector3D P1 = v.C1;
            QVector3D P2 = u.C0;
            QVector3D P3 = u.P;

            //qDebug()<<"index:"<<i;
            //qDebug()<<"C1:"<<v.C1;
            //qDebug()<<"C0:"<<u.C0;

            //cubic bezier curves
            //P(t) = (1-t)^3 p0 + 3t(1-t)^2p1+   3t^2(1-t)p2 + t^3p3 where t range {0,1}

            qreal step = (qreal)1 / resolution;

            for(int i=0;i<(resolution + 1);i++)
            {
               qreal t = i * step;

               QVector3D p = bezierInterpolate3D(t, P0, P1, P2, P3);

               //qDebug()<<"interpolated p:"<<p<<"index:"<<i;

               allpoints.append(p);
            }
        }

        //qDebug()<<"total points:"<<allpoints.length();
    }

    void  selectControlPoints()
    {
      for(int i=0;i<points.length();i++)
      {
          glColor3f(0,255,0);

          QVector3D v = points[i].P;

          glLoadName(i);
          glBegin(GL_POINTS);
          glVertex3f(v.x(),v.y(),v.z());
          glEnd();
      }
    }

    void drawControlPoints()
    {
        glEnable(GL_POINT_SMOOTH);
        glPointSize(10);
        glBegin(GL_POINTS);
        float ligthorange[3] = {225,177,109};

        for(int i=0;i<points.length();i++)
        {
            glColor3f((qreal)ligthorange[0]/255,(qreal)ligthorange[1]/255,(qreal)ligthorange[2]/255);

            QVector3D v = points[i].P;
            glVertex3f(v.x(),v.y(),v.z());
            //qDebug()<<"vertex"<<v;
        }

        glEnd();
        glDisable(GL_POINT_SMOOTH);
    }

    void drawHandles()
    {
        glPointSize(5);
        glBegin(GL_POINTS);

        for(int i=0;i<points.length();i++)
        {
           QVector3D v = points[i].C0;
           QVector3D u = points[i].C1;

           glColor3f((qreal)200/255,(qreal)200/255,(qreal)200/255);

           glVertex3f(v.x(),v.y(),v.z());
           glVertex3f(u.x(),u.y(),u.z());
        }

        glEnd();

        glBegin(GL_LINES);

        for(int i=0;i<points.length();i++)
        {
           QVector3D v = points[i].C0;
           QVector3D u = points[i].C1;

           glColor3f((qreal)100/255,(qreal)232/255,(qreal)214/255);

           glVertex3f(v.x(),v.y(),v.z());
           glVertex3f(u.x(),u.y(),u.z());
        }

        glEnd();

    }

    void drawCurveStrip()
    {
        glBegin(GL_LINE_STRIP);

        //for(int i=0;i<allpoints.length();i++)
        for(int i=0;i<count;i++)
        {
            QVector3D v = allpoints[i];

            glColor3f((qreal)9/255,(qreal)232/255,(qreal)214/255);

            glVertex3f(v.x(),v.y(),v.z());
        }

        glEnd();

        if(count<allpoints.length())
            count += 1;
        else
            count =0;

        //qDebug()<<"finished Drawing Curve";
    }

    void drawCurve3D()
    {
        int resolution =50;

        //qDebug()<<"Drawing Curve";
        //qDebug()<<"resolution"<<resolution;

        if(allpoints.length()==0)
            getAllInterpolatedPoints(resolution);


        drawCurveStrip();

        drawHandles();

        drawControlPoints();

        //selectControlPoints();
    }




    /*

    void addPoints(QList<QVector3D> _points)
    {

        points.clear();

        foreach (QVector3D v, _points)
        {
            CurvePoint3D p;

            p.setPoint(v);

            points.append(p);
        }
    }

    void addPoints(QList<CurvePoint3D> _curvepoints)
    {
        points.clear();

        foreach (CurvePoint3D v, _curvepoints)
        {
            points.append(v);
        }
    }

    void clearPoints()
    {
        points.clear();
    }

    void addPoint(QVector3D p)
    {
        CurvePoint3D c;
        c.setPoint(p);
        points.append(c);
    }

    void getPointAT(qreal t)
    {

    }



    */







    /*

    QList<QVector3D> BezierSpecial(QVector3D A, QVector3D B,int resolution=25)
    {


        QVector3D P0 = A;
        QVector3D P1 = QVector3D(0, 0,0);
        QVector3D P2 = QVector3D(0, 0,0);
        QVector3D P3 = B;

        QVector3D vec = B-A;

        qreal offset = 35;

        qreal dx = qMax(offset, vec.x());
        qreal dy = qMax(offset, vec.y());
        qreal dz = qMax(offset, vec.z());

        //cubic bezier curves
        //P(t) = (1-t)^3 p0 + 3t(1-t)^2p1+   3t^2(1-t)p2 + t^3p3 where t range {0,1}

        //d/dx of(P(t))


        qreal step = (qreal)1 / resolution;



        for(int i=0;i<(resolution + 1);i++)
        {
           qreal t = i * step;

           QVector3D p = bezierInterpolate3D(t, P0, P1, P2, P3);

            points.append(p);
        }

        return points;
    }



    void drawCurve3D(Curve3D _curve)
    {
        glBegin(GL_LINES);

        glColor3f(lightcyan[0]/255,lightcyan[1]/255,lightcyan[2]/255);

        foreach(QVector3D v, _curve.getAllInterpolatedPoints())
        {
            glVertex3f(v.x(),v.y(),v.z());
        }

        glEnd();

    }
    */


};

#endif // CURVE_H
