#ifndef SOUND_H
#define SOUND_H

#include<QtWidgets>

#include<AL/al.h>
#include<glm/glm.hpp>

class Sound
{
    QList<glm::vec3> listnerPostions;
    QList<glm::vec3> sourcePostions;

public:
    Sound();
};

#endif // SOUND_H
