#ifndef CUBECAMERA_H
#define CUBECAMERA_H

#include<QtWidgets>
#include<QtOpenGL>
#include<GL/glu.h>
#include<core/mesh.h>
#include<core/constants.h>
#include<glm/glm.hpp>
#include<glm/gtc/matrix_transform.hpp>
#include<core/math.h>

class CameraOrtho
{
public:

    enum CameraMode
    {
        TOP = 0,
        BOTTOM,
        FRONT,
        BACK,
        LEFT,
        RIGHT,
        PERSPECTIVE,
        ORTHO
    };

    int currentView = 6;

    glm::vec3 pos;
    glm::vec3 target;

    glm::vec3 forward;
    glm::vec3 up;
    glm::vec3 right;//normal = forward cross up

    glm::vec3 rotation;

    Ray ray;

    //clipping
    float clipfar;
    float clipnear;
    float cliptop;
    float clipbottom;
    float clipleft;

    //lens
    float fov;//field of view
    float aspectRatio;
    float zoomvalue;
    float boundingSphereRadius;

    qreal sensitivity;

    int width;
    int height;


    CameraOrtho()
    {
        zoomvalue = 3;
        rotation = glm::vec3(0,0,0);
        up       = glm::vec3(0,1,0);
        pos      = glm::vec3(0.0, 0, -10.0);
        target   = glm::vec3(0.0f, 0.0f, 0.0f);
        rotation = glm::vec3(32,-37,0);

        clipnear = 0.001f;
        clipfar = 500.0f;


        fov = 45.0f;
        aspectRatio = 1.0f;
        sensitivity = 1;
        boundingSphereRadius = 1;
    }
    void reset()
    {
        /*
        rotation = glm::vec3(0,0,0);
        pos      = glm::vec3(0.0, 0, -10.0);
        target   = glm::vec3(0.0f, 0.0f, 0.0f);
        rotation = glm::vec3(0,0,0);
        */
        rotation = glm::vec3(0,0,0);
        up       = glm::vec3(0,1,0);
        pos      = glm::vec3(0.0, 0, -10.0);
        target   = glm::vec3(0.0f, 0.0f, 0.0f);
        rotation = glm::vec3(32,-37,0);
    }

    void setupView(int w,int h)
    {
        width = w;
        height = h;

        glViewport (0, 0, (GLsizei) w, (GLsizei) h);				// Set the viewport
        glMatrixMode (GL_PROJECTION);								// Set the Matrix mode
        glLoadIdentity ();
        aspectRatio = (GLfloat) w /(GLfloat) h ;
        gluPerspective(fov, aspectRatio, clipnear, clipfar);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

    }
    void setupPerspectiveMatrix()
    {

        gluPerspective(fov, aspectRatio, clipnear, clipfar);

        glScalef(1.0f, 1.0f, -1.0f);
    }

    void grabKeyBoard(QKeyEvent * event)
    {
        qDebug()<<"Key Pressed:"<<event->key()<<","<<event->text();

        switch(event->key())
        {
        case Qt::Key_1:
            qDebug()<<"Top";
            currentView =FRONT;
            setCameraView(FRONT);
            break;

        case Qt::Key_2:
            qDebug()<<"Bottom";
            currentView =BOTTOM;
            setCameraView(BOTTOM);
            break;


        case Qt::Key_3:
            qDebug()<<"Front";
            currentView =FRONT;
            setCameraView(FRONT);
            break;

        case Qt::Key_4:
            qDebug()<<"Back";
            currentView =BACK;
            setCameraView(BACK);
            break;

        case Qt::Key_5:
            qDebug()<<"Left";
            currentView =LEFT;
            setCameraView(LEFT);
            break;

        case Qt::Key_6:
            qDebug()<<"Right";
            currentView =RIGHT;
            setCameraView(RIGHT);
            break;

        case Qt::Key_7:
            qDebug()<<"Ortho";
            currentView =ORTHO;
            setCameraView(ORTHO);
            reset();
            break;
        case Qt::Key_8:
            qDebug()<<"Perspective";
            currentView =PERSPECTIVE;
            setCameraView(PERSPECTIVE);
            break;

        }
    }

    void setCameraView(int view)
    {
        switch(view)
        {
        case FRONT://0
            pos    = glm::vec3(0,0,1);
            target = glm::vec3(0,0,0);
            up     = glm::vec3(0,1,0);
            break;

        case BACK://1
            pos    = glm::vec3(0,0,-1);
            target = glm::vec3(0,0,0);
            up     = glm::vec3(0,1,0);
            break;

        case TOP://2

            pos      = glm::vec3(0,1,0);
            target   = glm::vec3(0,0,0);
            up       = glm::vec3(0,0,-1);
            break;

        case BOTTOM://3
            pos    = glm::vec3(0,-1,0);
            target = glm::vec3(0,0,0);
            up     = glm::vec3(0,0,1);
            break;

        case LEFT://4
            pos      = glm::vec3(-1,0,0);
            target   = glm::vec3(0,0,0);
            up       = glm::vec3(0,1,0);
            break;

        case RIGHT://5
            pos    = glm::vec3(1,0,0);
            target = glm::vec3(0,0,0);
            up     = glm::vec3(0,1,0);
            break;

        case PERSPECTIVE://6
            reset();
            break;
        case ORTHO://7
            reset();
            break;

       default:

            break;
        }
    }


    void rotate(QPoint delta)
    {
        if(currentView == PERSPECTIVE)
        {
            glm::vec3 deltaVec(0,0,0);

            deltaVec.x = (delta.y()*sensitivity);
            deltaVec.y = (delta.x()*sensitivity);

            this->rotation += deltaVec;
        }
        else
        {

        }
    }

    void translate(QPoint delta)
    {
        if(currentView == PERSPECTIVE)
        {
            glm::vec3 deltaVec(0,0,0);

            deltaVec.x= (delta.x()*0.025);
            deltaVec.y= (delta.y()*-0.025);

            this->pos += deltaVec;
        }
        else
        {

        }
    }

    void zoom(qreal delta)
    {
        if(currentView == PERSPECTIVE)
        {
            glm::vec3 dir = target-pos;

            glm::normalize(dir);

            dir *= (0.0005 * delta);

            pos += dir;

            target += dir;
        }
        else
        {
            zoomvalue += (delta*0.005);
        }
    }

    void pan(QPoint delta)
    {
        if(currentView == PERSPECTIVE)
        {
            glm::vec3 dir = target-pos;
            glm::normalize(dir);
            glm::vec3 normal = glm::cross(dir,up);
            glm::vec3 updelta = up;

            updelta *= (delta.y()*-0.015);
            normal  *= (delta.x()*-0.0015);
            glm::vec3 finalOffset = updelta+ normal;

            target += finalOffset;
            pos    += finalOffset;
        }
        else
        {

        }
    }

    void raycastscene(QMouseEvent *event)
    {
        if (event->buttons() & Qt::LeftButton && event->modifiers() & Qt::ControlModifier)
        {
            projectScreenToWorld(event->pos().x(),event->pos().y());
        }
    }


    void grabMouseEvents(QMouseEvent *event,QPoint delta)
    {
        if(event->buttons() & Qt::MiddleButton)
        {
            pan(delta);
            qDebug()<<"Panning:"<<delta;
        }

        if (event->buttons() & Qt::LeftButton)
        {

           rotate(delta);
           qDebug()<<"Orbit:deltaVec"<<delta;
        }

        else if(event->buttons() & Qt::RightButton)
        {
           qDebug()<<"Panning:"<<delta;
        }
    }

    void projectScreenToWorld(int x,int y)
    {
        double modelview[16], projection[16];
        int viewport[4];


        //Read the projection, modelview and viewport matrices
        //using the glGet functions.
        glGetDoublev(GL_PROJECTION_MATRIX, projection );
        glGetDoublev(GL_MODELVIEW_MATRIX, modelview );
        glGetIntegerv(GL_VIEWPORT, viewport );

        double x_start= 0, y_start=0, z_start=0;
        gluUnProject( x, viewport[3]-y, 0, modelview, projection, viewport, &x_start, &y_start, &z_start );
        glm::vec3 start(x_start,y_start,z_start);
        printf("start x:%f,y:%f,z:%f\n\n",start.x,start.y,start.z);

        double x_end= 0, y_end=0, z_end=0;
        gluUnProject( x, viewport[3]-y, 1, modelview, projection, viewport, &x_end, &y_end, &z_end );
        glm::vec3 end(x_end,y_end,z_end);
        printf("end x:%f,y:%f,z:%f\n\n",end.x,end.y,end.z);


        glReadBuffer( GL_FRONT );
        //Read the window z-depth value from the z-buffer
        float z=0;
        glReadPixels( x, viewport[3]-y, 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &z );

        double x_hit= 0, y_hit=0, z_hit=0;
        gluUnProject( x, viewport[3]-y, z, modelview, projection, viewport, &x_hit, &y_hit, &z_hit );
        glm::vec3 hitpoint(x_hit,y_hit,z_hit);
        printf("hitpoint x:%f,y:%f,z:%f\n\n",hitpoint.x,hitpoint.y,hitpoint.z);

    }

    glm::vec3 intersectLineWithPlane(glm::vec3 P0, glm::vec3 P1)
    {
        //Px = P0   +   [ N dot {P2-P0} /  N dot {P1-P0}]  *   (P1 - P0)
        glm::vec3 P2 =  glm::vec3(0,0,0);
        glm::vec3 N  =  glm::vec3(0,1,0);

        float t = glm::dot(N,(P2-P0))/ glm::dot(N,(P1-P0));;

        if(t > 0 && t < 1)
        {
            // The intersection occurs between the two end points
        }
        else if(t == 0)
        {
            //The intersection falls on the first end point
        }
        else if(t = 1)
        {
           //Intersection falls on the second end point
        }
        else if(t > 1)
        {
            //Intersection occurs beyond second end Point
        }
        else if(t < 0 )
        {
            //Intersection happens before 1st end point.
        }

        glm::vec3  P =  P0 +t*(P1-P0);

        //P += (P1 - P0);
        //P *= t;

        return P;
    }

    void planeObject()
    {
        glm::vec3 co = intersectLineWithPlane(ray.p0,ray.p1);

        qDebug()<<"Intersection Point:"<<co.x<<","<<co.y<<","<<co.z;
    }

    void orbit_setupViewMatrix()
    {
        if(currentView == PERSPECTIVE)
        {
            glMatrixMode( GL_PROJECTION );
            glLoadIdentity();
            gluPerspective( fov,aspectRatio,clipnear,clipfar );
            glMatrixMode( GL_MODELVIEW);
            glLoadIdentity();//important
            glTranslatef(pos.x, pos.y, pos.z);
            glRotatef(rotation.x, 1, 0, 0);
            glRotatef(rotation.y, 0, 1, 0);
            glRotatef(rotation.z, 0, 0, 1);
            //printViewMatrix();
        }
        else
        {
            glMatrixMode( GL_PROJECTION );
            glLoadIdentity();
            glOrtho( -zoomvalue*aspectRatio, zoomvalue*aspectRatio, -zoomvalue, zoomvalue, clipnear, clipfar );

            //glViewport( 0, 0, width(), height()) );

            glMatrixMode( GL_MODELVIEW );
            glLoadIdentity();
            gluLookAt(pos.x, pos.y, pos.z,   // Eye-position (above)
                      target.x, target.z,target.z,     // View-point
                      up.x, up.y, up.z );   // Up-vector
        }

    }

    void printViewMatrix()
    {
        qDebug()<<"Pos:"<<pos.x<<","<<pos.y<<","<<pos.z;
        qDebug()<<"rotation:"<<rotation.x<<","<<rotation.y<<","<<rotation.z;
        qDebug()<<"target:"<<target.x<<","<<target.y<<","<<target.z;

        float viewmatrix[16];

        glGetFloatv(GL_MODELVIEW_MATRIX,viewmatrix);

        for(int i=0;i<16;i+=4)
        {
            qDebug()<<"View matrix:"<<viewmatrix[0+i]<<viewmatrix[1+i]<<viewmatrix[2+i]<<viewmatrix[3+i];
        }
    }

    void drawtext2D(QGLWidget *w,Text text)
    {
        text.setText(text.getText());
        text.drawtext2D(w,QColor(0,0,0));
    }
};

class Camera
{
public:

    Ray ray;
    // position
    glm::vec3 pos;
    // pivot center
    glm::vec3 pivot;

    // heading angle
    float head;
    // pitching angle
    float pitch;
    //banking angle
    float bank;
    // near clipping plane
    float clipNear;
    //far clipping plane
    float clipFar;
    // vertical field of view, in degree
    float fovy;
    // ascpect ration of witdh over height
    float aspectRatio;
    float boundingSphereRadius=1;

private:
    static inline glm::vec3 rotateAroundAxis( const glm::vec3& vector, const glm::vec3& axisPosition, const glm::vec3& axis, const float& angle )
    {

        //determining the sinus and cosinus of the rotation angle
        float cosTheta = cos( angle );
        float sinTheta = sin( angle );

        //Vector3 from the given axis point to the initial point
        glm::vec3 direction = vector - axisPosition;

        //new vector which will hold the direction from the given axis point to the new rotated point
        glm::vec3 newDirection;

        //x-component of the direction from the given axis point to the rotated point
        newDirection.x = ( cosTheta + ( 1 - cosTheta ) * axis.x * axis.x ) * direction.x +
                         ( ( 1 - cosTheta ) * axis.x * axis.y - axis.z * sinTheta ) * direction.y +
                         ( ( 1 - cosTheta ) * axis.x * axis.z + axis.y * sinTheta ) * direction.z;

        //y-component of the direction from the given axis point to the rotated point
        newDirection.y = ( ( 1 - cosTheta ) * axis.x * axis.y + axis.z * sinTheta ) * direction.x +
                         ( cosTheta + ( 1 - cosTheta ) * axis.y * axis.y ) * direction.y +
                         ( ( 1 - cosTheta ) * axis.y * axis.z - axis.x * sinTheta ) * direction.z;

        //z-component of the direction from the given axis point to the rotated point
        newDirection.z = ( ( 1 - cosTheta ) * axis.x * axis.z - axis.y * sinTheta ) * direction.x +
                         ( ( 1 - cosTheta ) * axis.y * axis.z + axis.x * sinTheta ) * direction.y +
                         ( cosTheta + ( 1 - cosTheta ) * axis.z * axis.z) * direction.z;

        //returning the result by addind the new direction vector to the given axis point
        return axisPosition + newDirection;
    }

public:

    Camera()
    {
        pos = glm::vec3(0.0f, 0.0f, 0.0f);

        head = 0.0f;

        pitch = 0.0f;

        bank = 0.0f;

        pivot = glm::vec3(0.0f, 0.0f, 0.0f);

        clipNear = 0.001f;

        clipFar = 10.0f;

        fovy = 45.0f;

        aspectRatio = 1.0f;
        boundingSphereRadius =25;

    }

    ~Camera(){




    }

    //computes a vector basis (dir, right, up) of the current alignment (head, pitch, bank)
    void computeVectorBasis(glm::vec3 &dir, glm::vec3 &right, glm::vec3 &up)
    {
        dir = glm::vec3(0.0f, 0.0f, 1.0f);

        up = glm::vec3(0.0f, 1.0f, 0.0f);

        //head
        dir = rotateAroundAxis( dir, glm::vec3(0.0f, 0.0f, 0.0f), up, head );
        //pitch
        right = glm::cross(up, dir);
        glm::normalize(right);

        dir = rotateAroundAxis( dir, glm::vec3(0.0f, 0.0f, 0.0f), right, pitch );
    }

    // initializes the perspective matrix
    void setupPerspectiveMatrix()
    {
        gluPerspective(fovy, aspectRatio, clipNear, clipFar);

        glScalef(1.0f, 1.0f, -1.0f);
    }

    //initializes the view matrix
    void setupViewMatrix()
    {
        glm::vec3 dir, right, up;

        computeVectorBasis(dir, right, up);

        glRotatef(-head * 180.0f / PI, up.x, up.y, up.z);

        glRotatef(-pitch * 180.0f / PI, right.x, right.y, right.z);

        glRotatef(-bank * 180.0f / PI, dir.x, dir.y, dir.z);

        glTranslatef(-pos.x, -pos.y, -pos.z);



    }

    void setboundingSphereRadius(float r)
    {
        boundingSphereRadius = r;
    }

    void setupCamera(int width,int height)
    {
        //setup view and projection matrix
        glMatrixMode(GL_PROJECTION);

        glLoadIdentity();

        clipNear = 0.01 * boundingSphereRadius;

        clipFar = 10.0f * boundingSphereRadius;

        aspectRatio = (float)width / (float)height;

        setupPerspectiveMatrix();

        setupViewMatrix();
    }


    void projectScreenToWorld(QMouseEvent *event,int width,int height)
    {

        //get projection, model and view matrix
        //setup view and projection matrix
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();

        clipNear = 0.01 * boundingSphereRadius;//mesh boundingSphereRadius
        clipFar = 10.0f * boundingSphereRadius; //mesh boundingSphereRadius

        aspectRatio = (float)width/ (float)height;
        setupPerspectiveMatrix();
        setupViewMatrix();


        //get the projMatrix,modelMatrix and the viewPort
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        double projMatrix[16];
        double modelMatrix[16];
        int viewPort[4];

        glGetDoublev(GL_PROJECTION_MATRIX, projMatrix);
        glGetDoublev(GL_MODELVIEW_MATRIX, modelMatrix);
        glGetIntegerv(GL_VIEWPORT, viewPort);


        //compute a "click ray"
        double x0, y0, z0, x1, y1, z1;

        /*
         * #include<glm/gtc/matrix_transform.hpp>
            detail::tvec3<T> //return the 3dpoints in world space
            glm::gtc::matrix_transform::unProject(
            detail::tvec3< T > const & 	win,
            detail::tmat4x4< T > const & 	model,
            detail::tmat4x4< T > const & 	proj,
            detail::tvec4< U > const & 	viewport
            )
        */

        gluUnProject(event->pos().x(), height - event->pos().y(), 0.0, modelMatrix, projMatrix, viewPort, &x0, &y0, &z0);
        gluUnProject(event->pos().x(), height - event->pos().y(), 1.0, modelMatrix, projMatrix, viewPort, &x1, &y1, &z1);

        glm::vec3 p0(x0, y0, z0);
        glm::vec3 p1(x1, y1, z1);

        ray.p0 = p0;
        ray.p1 = p1;

       //projectPointOnMesh(p0,p1);

       //updateGL();
    }

    void grabMouseKeys(QMouseEvent *event,QPoint delta)
    {

        //dolly camera
        if (event->buttons() == Qt::RightButton)
        {
            glm::vec3 dir, right, up;

            computeVectorBasis(dir, right, up);

            dir *= ((delta.x() + delta.y()) * boundingSphereRadius * 0.002f);

            pos += dir;
        }

        //look camera (head and pitch)
        if ((event->buttons() == Qt::LeftButton) && (event->modifiers() == Qt::AltModifier))
        {
            head += delta.x() * 0.002f;

            pitch += delta.y() * 0.002f;
        }

        //Pan or track camera (right and up vector movements)
        if (event->buttons() & Qt::MiddleButton)
        {
            glm::vec3  dir, right, up;

            computeVectorBasis(dir, right, up);

            right *=(delta.x() *boundingSphereRadius* 0.002f);
            up    *=(delta.y() * boundingSphereRadius*0.002f);

            pos += right;
            pos -= up ;
        }

        //orbit camera (rotate camera around camera pivot)
        if (event->buttons()& Qt::LeftButton)
        {
            glm::vec3  dir, right, up;

            computeVectorBasis(dir, right, up);

            pos = rotateAroundAxis( pos, pivot, up, +delta.x() * 0.002f );

            head += delta.x() * 0.002f;

            computeVectorBasis(dir, right, up);

            pos = rotateAroundAxis( pos, pivot, right, +delta.y() * 0.002f );

           pitch += delta.y() * 0.002f;
        }

    }




};


/*

class CameraBase
{

public:
    virtual void reset()const = 0;
    virtual void setupView(int w,int h)const = 0;
    virtual void rotate(QPoint delta)const = 0;
    virtual void translate(QPoint delta)const = 0;
    virtual void zoom(qreal delta)const = 0;
    virtual void pan(QPoint delta)const = 0;
    virtual void orbit()const = 0;
    virtual void printViewMatrix()const = 0;

};


//view navigation camera
class Camera3D
{
public:
    qreal sensitivity;

    QVector3D pos;
    QVector3D target;
    QVector3D upVector;
    QVector3D rotation;

    float clipNear;
    float clipFar;
    float fov;
    float aspectRatio;

    Camera3D()
    {
        rotation = QVector3D(0,0,0);
        upVector = QVector3D(0,1,0);
        pos      = QVector3D(0.0, 0, -10.0);
        target   = QVector3D(0.0f, 0.0f, 0.0f);
        rotation = QVector3D(32,-37,0);

        clipNear = 0.001f;
        clipFar = 500.0f;
        fov = 45.0f;
        aspectRatio = 1.0f;
        sensitivity = 1;
    }
    void reset()
    {
        rotation = QVector3D(0,0,0);
        pos      = QVector3D(0.0, 0, -10.0);
        target   = QVector3D(0.0f, 0.0f, 0.0f);
        rotation = QVector3D(0,0,0);
    }

    void setupView(int w,int h)
    {
        glViewport (0, 0, (GLsizei) w, (GLsizei) h);				// Set the viewport
        glMatrixMode (GL_PROJECTION);								// Set the Matrix mode
        glLoadIdentity ();
        aspectRatio = (GLfloat) w /(GLfloat) h ;
        gluPerspective(fov, aspectRatio, clipNear, clipFar);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
    }

    void rotate(QPoint delta)
    {
        QVector3D deltaVec(0,0,0);
        deltaVec.setX(delta.y()*sensitivity);
        deltaVec.setY(delta.x()*sensitivity);
        this->rotation += deltaVec;
    }

    void translate(QPoint delta)
    {
        QVector3D deltaVec(0,0,0);
        deltaVec.setX(delta.x()*.025);
        deltaVec.setY(delta.y()*-0.025);
        this->pos += deltaVec;
    }

    void zoom(qreal delta)
    {
        QVector3D dir = target-pos;

        dir.normalize();

        delta *= 0.025;

        dir = dir * delta;

        pos += dir;

        target += dir;
    }

    void pan(QPoint delta)
    {
        QVector3D dir = target-pos;
        dir.normalize();

        QVector3D normal = QVector3D::crossProduct(dir,upVector);

        QVector3D updelta = upVector * delta.y()*- 0.025;
        normal *= delta.x()*-0.025;

        QVector3D finalOffset = updelta+ normal;

        target += finalOffset;
        pos    += finalOffset;
    }

    void orbit()
    {
        glLoadIdentity();//important
        glTranslatef(pos.x(), pos.y(), pos.z());
        glRotatef(rotation.x(), 1, 0, 0);
        glRotatef(rotation.y(), 0, 1, 0);
        glRotatef(rotation.z(), 0, 0, 1);
        //printViewMatrix();
    }

    void printViewMatrix()
    {
        qDebug()<<"Pos:"<<pos.x()<<","<<pos.y()<<","<<pos.z();
        qDebug()<<"rotation:"<<rotation.x()<<","<<rotation.y()<<","<<rotation.z();
        qDebug()<<"target:"<<target.x()<<","<<target.y()<<","<<target.z();


        float viewmatrix[16];

        glGetFloatv(GL_MODELVIEW_MATRIX,viewmatrix);

        for(int i=0;i<16;i+=4)
        {
            qDebug()<<"View matrix:"<<viewmatrix[0+i]<<viewmatrix[1+i]<<viewmatrix[2+i]<<viewmatrix[3+i];
        }
    }

    void getLookAT()
    {

    }
};

class CameraCube
{
public:


    glm::vec3 pos;
    glm::vec3 target;

    glm::vec3 forward;//camera direction
    glm::vec3 up;
    glm::vec3 worldUp;
    glm::vec3 right;//normal = forward cross up

    //glm::vec3 rotation;

    //clipping
    float clipfar;
    float clipnear;
    float cliptop;
    float clipbottom;
    float clipleft;

    //lens
    float fov;//field of view
    float aspectRatio;

    qreal sensitivity;
    float zoomvalue;

    glm::mat4 view;
    glm::mat4 projectionMatrix;
    glm::mat4 model;
    glm::mat4 mvp;

    CameraCube()
    {
        clipnear = 0.001f;
        clipfar = 500.0f;
        fov = 45.0f;
        aspectRatio = 1.0f;
        sensitivity = 1;

        pos = glm::vec3(0.0f, 0.0f, 3.0f);
        up = glm::vec3(0.0f, 1.0f, 0.0f);
        worldUp = glm::vec3(0.0f,1.0f,0.0f);

        forward = glm::normalize(pos - target);
        up = glm::vec3(0.0f, 1.0f, 0.0f);
        //worldUp = glm::vec3(0.0f,1.0f,0.0f);

        right = glm::normalize(glm::cross(up, forward));

        up = glm::cross(forward, right);

        view = glm::lookAt(pos,target,up);
    }

    void update()
    {
        forward = glm::normalize(pos - target);
        up      = glm::vec3(0.0f, 1.0f, 0.0f);
        worldUp = glm::vec3(0.0f, 1.0f, 0.0f);

        right = glm::normalize(glm::cross(up, forward));
        up = glm::cross(forward, right);

        view = glm::lookAt(pos,target,up);
    }

    void setProjectionMatrix()
    {
        // Generates a really hard-to-read matrix, but a normal, standard 4x4 matrix nonetheless
        projectionMatrix = glm::perspective(
            fov,         // The horizontal Field of View, in degrees : the amount of "zoom". Think "camera lens". Usually between 90° (extra wide) and 30° (quite zoomed in)
            aspectRatio, // Aspect Ratio. Depends on the size of your window. Notice that 4/3 == 800/600 == 1280/960, sounds familiar ?
            clipnear,        // Near clipping plane. Keep as big as possible, or you'll get precision issues.
            clipfar       // Far clipping plane. Keep as little as possible.
        );
    }

    void computeEntireMatrix()
    {
        // Projection matrix : 45° Field of View, 4:3 ratio, display range : 0.1 unit <-> 100 units
        projectionMatrix = glm::perspective(45.0f, 4.0f / 3.0f, 0.1f, 100.0f);
        // Camera matrix
        view       = glm::lookAt(
            glm::vec3(4,3,3), // Camera is at (4,3,3), in World Space
            glm::vec3(0,0,0), // and looks at the origin
            glm::vec3(0,1,0)  // Head is up (set to 0,-1,0 to look upside-down)
        );
        // Model matrix : an identity matrix (model will be at the origin)
        model      = glm::mat4(1.0f);  // Changes for each model !
        // Our ModelViewProjection : multiplication of our 3 matrices
        mvp        = projectionMatrix * view * model; // Remember, matrix multiplication is the other way around

    }

    void setTarget(glm::vec3 target)
    {
        this->target = target;
    }

    void setPosition(glm::vec3 pos)
    {
        this->pos = pos;
    }

    void move(glm::vec3 delta)
    {
        pos += delta;
    }
};

*/

/*

class cameraObject
{
    QList<QVector3D> vertices;
    QList< QPair<int,int> > edges;
    //float creamcyan[3]  = {130,177,168};

    QColor color;//(130,177,168);

public:
    enum CameraMode
    {
        TOP = 0,
        BOTTOM,
        FRONT,
        BACK,
        LEFT,
        RIGHT,
        PERSPECTIVE,
        ORTHO
    };

public:
    qreal sensitivity;

    QVector3D target;
    QVector3D pos;

    QVector3D forward;
    QVector3D right;
    QVector3D up;

    QVector3D upVector;

    QVector3D rotation;
    QVector3D pivot; // pivot center

    float clipNear;//near clipping plane
    float clipFar;// far clipping plane
    float clipLeft;//leftclipping plane
    float clipRight;// right clipping plane
    float clipBottom; //bottom clipping plane
    float clipTop;//top clipping plane

    float fov; //vertical field of view, in degree
    float aspectRatio;//ascpect ration of witdh over height

    cameraObject();


    ~cameraObject(){}


    void drawCameraObject()
    {
        glDisable(GL_LIGHTING);
        //more transformation required
       //color = QColor(130,177,168);
       glPushMatrix();

       glRotatef(90,1,0,0);
       glScalef(.3,.3,.3);
       glBegin(GL_LINES);

       //output each vertces array element's value
       for ( int i = 0; i < edges.length(); i++ )
       {
           int u = edges[i].first;
           int v = edges[i].second;

           glColor3f(130/255,177/255,168/255);

           glVertex3f(vertices[u].x(),vertices[u].y(),vertices[u].z());
           glVertex3f(vertices[v].x(),vertices[v].y(),vertices[v].z());
       }

       glEnd();
       glPopMatrix();

       //this ray from pos to target

       glPushMatrix();
       glBegin(GL_LINES);
       glVertex3f(pos.x(),pos.y(),pos.z());
       glVertex3f(target.x(),target.y(),target.z());
       glEnd();

       glEnable(GL_POINT_SMOOTH);
       glPointSize(5);
       glBegin(GL_POINTS);
       glColor3f(130/255,177/255,168/255);
       glVertex3f(pos.x(),pos.y(),pos.z());
       glVertex3f(target.x(),target.y(),target.z());
       glEnd();
       glDisable(GL_POINT_SMOOTH);
       glPopMatrix();
       glEnable(GL_LIGHTING);
    }



    void resetCameraProperties()
    {
        rotation = QVector3D(0,0,0);
        upVector = QVector3D(0,1,0);


        pos = QVector3D(5.0f,5.0f,5.0f);


        pivot = QVector3D(0.0f, 0.0f, 0.0f);
        target = QVector3D(0.0f, 0.0f, 0.0f);

        rotation = QVector3D(0,0,0);


        fov = 45.0f;
        aspectRatio = 1.0f;

        clipNear = 0.001f;
        clipFar = 500.0f;

        clipLeft   = -0.5;
        clipRight  = 0.5;

        clipBottom = -0.5;
        clipTop = 0.5;

    }




    void setCameraView(int cameraMode)
    {
        switch(cameraMode)
        {
        case FRONT://0
            pos = QVector3D(0,0,1);
            target = QVector3D(0,0,0);
            upVector = QVector3D(0,1,0);



            break;

        case BACK://1
            pos = QVector3D(0,0,-1);
            target = QVector3D(0,0,0);
            upVector = QVector3D(0,1,0);



            break;

        case TOP://2

            pos = QVector3D(0,1,0);
            target = QVector3D(0,0,0);
            upVector = QVector3D(0,0,-1);

            break;

        case BOTTOM://3
            pos = QVector3D(0,-1,0);
            target = QVector3D(0,0,0);
            upVector = QVector3D(0,0,1);


            break;

        case LEFT://4
            pos = QVector3D(-1,0,0);
            target = QVector3D(0,0,0);
            upVector = QVector3D(0,1,0);


            break;

        case RIGHT://5
            pos = QVector3D(1,0,0);
            target = QVector3D(0,0,0);
            upVector = QVector3D(0,1,0);


            break;

        case PERSPECTIVE://6
            pos = QVector3D(5,5,5);
            target = QVector3D(0,0,0);
            upVector = QVector3D(0,1,0);



            break;

        case ORTHO://7
            setOrtho();
            break;

        default://PERSPECTIVE
            pos = QVector3D(5,5,5);
            target = QVector3D(0,0,0);
            upVector = QVector3D(0,1,0);

            break;
        }
        //setPerspective();
        setOrtho();
    }



private:
    void setPerspective()
    {
        //  Set Perspective
        glMatrixMode (GL_PROJECTION);
        //glOrtho(-1, 1, -1, 1, -2, 2);
        glOrtho(clipLeft,clipRight, clipBottom, clipTop,clipNear, clipFar);

            //  Set camera position and view vector
        glMatrixMode (GL_MODELVIEW);

        gluLookAt (pos.x(), pos.y(), pos.z(),
                   target.x(), target.y(), target.z(),
                   upVector.x(), upVector.y(), upVector.z());
    }

    void setOrtho()
    {
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(clipLeft,clipRight,clipBottom,clipTop,clipNear,clipFar);
        gluLookAt(pos.x(),pos.y(),pos.z(),target.x(),target.y(),target.z(),upVector.x(),upVector.y(),upVector.z());

    }

public:
    void setCameraPos(QVector3D position)
    {
      this->pos = position;
    }

    void drawViewVolume(GLfloat x1, GLfloat x2, GLfloat y1, GLfloat y2, GLfloat z1, GLfloat z2)
    {
        glColor3f(1.0, 1.0, 1.0);
        glBegin(GL_LINE_LOOP);
            glVertex3f(x1, y1, -z1);
            glVertex3f(x2, y1, -z1);
            glVertex3f(x2, y2, -z1);
            glVertex3f(x1, y2, -z1);
        glEnd();

        glBegin(GL_LINE_LOOP);
            glVertex3f(x1, y1, -z2);
            glVertex3f(x2, y1, -z2);
            glVertex3f(x2, y2, -z2);
            glVertex3f(x1, y2, -z2);
        glEnd();
        glBegin(GL_LINES);
            glVertex3f(x1, y1, -z1);
            glVertex3f(x1, y1, -z2);
            glVertex3f(x1, y2, -z1);
            glVertex3f(x1, y2, -z2);
            glVertex3f(x2, y1, -z1);
            glVertex3f(x2, y1, -z2);
            glVertex3f(x2, y2, -z1);
            glVertex3f(x2, y2, -z2);
        glEnd();
    }

    void AddTranslationOffsetTargeted(QPoint delta)
    {
        QVector3D deltaVec(0,0,0);

        deltaVec.setX(delta.x()*.025);

        deltaVec.setY(delta.y()*-0.025);

        this->pos += deltaVec;
    }



    void addRotationOffest(QPoint delta)
    {
        QVector3D deltaVec(0,0,0);

        deltaVec.setX(delta.y()*sensitivity);

        deltaVec.setY(delta.x()*sensitivity);

        this->rotation += deltaVec;
    }


    void rotateAroundTarget1(QPoint delta)
    {

        QVector3D dir = target-pos;

        forward = dir.normalized();
        right = QVector3D::crossProduct(forward,upVector);
        upVector = QVector3D::crossProduct(right,forward);

        qreal angle = sqrt(delta.x()*delta.x()+delta.y()*delta.y());

        QVector3D axis(delta.x(),delta.y(),0);
        axis.normalize();

        QQuaternion u = QQuaternion::fromAxisAndAngle(axis,-1*angle);
        //QQuaternion v = QQuaternion::fromAxisAndAngle(QVector3D(1,0,0),-1*delta.y());

        forward   = u.rotatedVector(forward);
        upVector   = u.rotatedVector(upVector);
        //QVector3D finalDir = v.rotatedVector(newDir);

        pos = target- forward *angle;


    }

    void rotateAroundTarget(QPoint delta)
    {
        QVector3D dir = target-pos;

        QQuaternion u = QQuaternion::fromAxisAndAngle(QVector3D(0,1,0),-1*delta.x());
        QQuaternion v = QQuaternion::fromAxisAndAngle(QVector3D(1,0,0),-1*delta.y());

        QVector3D newDir   = u.rotatedVector(dir);
        QVector3D finalDir = v.rotatedVector(newDir);

        pos = target- finalDir;

    }

    void panView(QPoint delta)
    {
        QVector3D dir = target-pos;
        dir.normalize();

        QVector3D normal = QVector3D::crossProduct(dir,upVector);

        QVector3D updelta = upVector * delta.y()*0.025;
        normal *= delta.x()*-0.025;

        QVector3D finalOffset = updelta+ normal;

        target += finalOffset;
        pos    += finalOffset;
    }

    void zoomPos(qreal delta)
    {
        QVector3D dir = target-pos;

        dir.normalize();

        delta *= 0.025;

        dir = dir * delta;

        pos += dir;
        target += dir;

    }

    //working
    void reshapePerspective(int w,int h)
    {
        // Set the viewport
        glViewport (0, 0, (GLsizei) w, (GLsizei) h);

        glMatrixMode (GL_PROJECTION);								// Set the Matrix mode
        glLoadIdentity ();

        aspectRatio = (GLfloat) w /(GLfloat) h ;

        gluPerspective(fov, aspectRatio, clipNear, clipFar);

        glMatrixMode(GL_MODELVIEW);
        //set camera position using gluLookAt

        glLoadIdentity();
        gluLookAt(pos.x(),pos.y(),pos.z(), target.x(),target.y(),target.z(), upVector.x(),upVector.y(),upVector.z());
    }

    void transformCamera()
    {
        gluPerspective(fov, aspectRatio, clipNear, clipFar);
        //  Set camera position and view vector
        glMatrixMode(GL_MODELVIEW);
        //set camera position using gluLookAt
        glLoadIdentity();
        gluLookAt(pos.x(),pos.y(),pos.z(), target.x(),target.y(),target.z(), upVector.x(),upVector.y(),upVector.z());
    }

    void transformWorld()
    {
        //gluPerspective(fov, aspectRatio, clipNear, clipFar);
        //  Set camera position and view vector
        glMatrixMode(GL_MODELVIEW);

        glLoadIdentity();

        glTranslatef(pos.x(), pos.y(), pos.z());

        glRotatef(angleToRad(rotation.x()), 1, 0, 0);

        glRotatef(angleToRad(rotation.y()), 0, 1, 0);

        glRotatef(angleToRad(rotation.z()), 0, 0, 1);
    }

};


class Camera3DTarget
{

public:

    Camera3DTarget()
    {
        resetCamera();

        sensitivity = 25;
    }

    ~Camera3DTarget()
    {

    }
    qreal sensitivity;

    bool istrageted;
    bool isPanning;
    bool isOrbiting;

    QVector3D target;
    /// position
    QVector3D pos;

    QVector3D upVector;

    /// pivot center
    QVector3D pivot;

    QVector3D rotation;

    ///near clipping plane
    float clipNear;

    /// far clipping plane
    float clipFar;

    ///vertical field of view, in degree
    float fovy;

    ///ascpect ration of witdh over height
    float aspectRatio;

    ///initializes the perspective matrix
    void setupPerspectiveMatrix()
    {
        gluPerspective(fovy, aspectRatio, clipNear, clipFar);

        //glScalef(1.0f, 1.0f, 1.0f);
    }

    void addRotationOffest(QPoint delta)
    {
        QVector3D deltaVec(0,0,0);

        deltaVec.setX(delta.y()*sensitivity);

        deltaVec.setY(delta.x()*sensitivity);

        this->rotation += deltaVec;
    }

    void AddTranslationOffset(QPoint delta)
    {
        QVector3D deltaVec(0,0,0);

        deltaVec.setX(delta.x()*.025);

        deltaVec.setY(delta.y()*-0.025);


        this->pos += deltaVec;
    }
    void addPanOffset()
    {

    }

    void setPos(QVector3D position)
    {
      this->pos = position;
    }

    void resetCamera()
    {
        rotation = QVector3D(0,0,0);
        upVector = QVector3D(0,1,0);

        pos = QVector3D(5.0f,5.0f,5.0f);

        pivot = QVector3D(0.0f, 0.0f, 0.0f);
        target = QVector3D(0.0f, 0.0f, 0.0f);

        rotation = QVector3D(0,0,0);

        clipNear = 0.001f;
        clipFar = 500.0f;
        fovy = 45.0f;

        aspectRatio = 1.0f;
    }

    void reshapePerspective(int w,int h)
    {
        glViewport (0, 0, (GLsizei) w, (GLsizei) h);				// Set the viewport
        glMatrixMode (GL_PROJECTION);								// Set the Matrix mode
        glLoadIdentity ();

        //gluPerspective(75, (GLfloat) w /(GLfloat) h , 0.10, 100.0);

        aspectRatio = (GLfloat) w /(GLfloat) h ;

        gluPerspective(fovy, aspectRatio, clipNear, clipFar);

        glMatrixMode(GL_MODELVIEW);

        //set camera position using gluLookAt

        glLoadIdentity();
        gluLookAt(5.0f,5.0f,5.0f, 0.0f,0.0f,0.0f, 0.0f,1.0f,0.0f);
    }



    void transformCamera()
    {
        glLoadIdentity();

        glTranslatef(pos.x(), pos.y(), pos.z());

        glRotatef(angleToRad(rotation.x()), 1, 0, 0);

        glRotatef(angleToRad(rotation.y()), 0, 1, 0);

        glRotatef(angleToRad(rotation.z()), 0, 0, 1);

    }

    void setViewPort()
    {
        resetCamera();

        gluLookAt(pos.x(),pos.y(),pos.z(),target.x(),target.y(),target.z(),upVector.x(),upVector.y(),upVector.z());
    }

    void LookAT(QVector3D & _target)
    {
        this->target = _target;

        gluLookAt(pos.x(),pos.y(),pos.z(),target.x(),target.y(),target.z(),upVector.x(),upVector.y(),upVector.z());
    }
};


*/



#endif // CUBECAMERA_H
