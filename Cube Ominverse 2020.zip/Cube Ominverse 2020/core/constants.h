#ifndef CONSTANTS_H
#define CONSTANTS_H

#define PI 3.141592653589793
//#define e  2.718281828459

#define angleToRad(angle)  (angle * PI / 180 )
#define RadToangle(rad)  (rad*180.0f / PI)

/*
// Converts from degrees to radians.
float angleToRad(float degrees)
{
  return degrees * PI / 180;
}

// Converts from radians to degrees.
float RadToangle(float radians)
{
  return radians * 180 / PI;
}
*/

#endif // CONSTANTS_H

