#ifndef MATERIAL_H
#define MATERIAL_H
#include<QtWidgets>

class Material1
{
public:
    QFile file;
    QColor color;
    Material1();
};

#endif // MATERIAL_H
