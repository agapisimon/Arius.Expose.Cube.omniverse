#ifndef CURVEWIDGET_H
#define CURVEWIDGET_H
#include<QtWidgets>
#include <QWidget>
#include<math.h>
#include<ctime>

/*
 #include <QGlobal.h>
#include <QTime>

int randInt(int low, int high)
{
// Random number between low and high
return qrand() % ((high + 1) - low) + low;
}

// Create seed for the random
// That is needed only once on application startup
QTime time = QTime::currentTime();
qsrand((uint)time.msec());

// Get random value between 0-100
int randomValue = randInt(0,100);
*/


class CurveWidget : public QWidget
{
    Q_OBJECT
public:
    explicit CurveWidget(QWidget *parent = 0);

    QList<QPointF> keypoints;
    QList<QPointF> controlPoints;

    QRectF bounds;

    QGraphicsScene *scene;
    QGraphicsView  *view;

    struct KEYPoint
    {
        QPointF P;
        QPointF right;
        QPointF left;
        QGraphicsEllipseItem circe;
    };

    QList<KEYPoint> curvePoints;

    void initUI()
    {
        srand(time(0));

        QVBoxLayout *layout  = new QVBoxLayout(this);
        scene = new QGraphicsScene;
        view  = new QGraphicsView(scene);

        this->view->setCacheMode(QGraphicsView::CacheBackground);
        this->view->setViewportUpdateMode(QGraphicsView::BoundingRectViewportUpdate);
        this->view->setRenderHint(QPainter::Antialiasing);

        layout->addWidget(view);
        addItems();
    }

    int randInRange(int min, int max)
    {
      return min + (int) (rand() / (double) (RAND_MAX + 1) * (max - min + 1));
    }

    qreal randInRange(qreal min, qreal max)
    {
      return min + (qreal) (rand() / (qreal) (RAND_MAX + 1) * (max - min + 1));
    }

    qreal random()
    {
        return (double)rand() / ((double)RAND_MAX + 1);
    }

    void drawCurve(bool ifcurve = false)//QPainter *painter)
    {
        QPainterPath path;

        QGraphicsPolygonItem * polygonItem  = new QGraphicsPolygonItem;

        QList<QGraphicsItem*> these_items = this->scene->items();

        foreach(QGraphicsItem *item, these_items)
        {
           qDebug()<<item->pos()<<":Ellipse";
        }

        for (int i=0;i<this->keypoints.length()-1;i++)
        {
            QPointF P0 = keypoints[i];//line is inherited from QGraphicsLineItem
            QPointF P3 = keypoints[i+1];//line is inherited from QGraphicsLineItem

            if(ifcurve)
            {
                QPointF dp  = P3-P0;
                qreal bias  = 0.4*abs(dp.x());

                QPointF P1 = P0 + QPointF(-bias, 0);
                QPointF P2 = P3 + QPointF(bias, 0);

                path.moveTo(P0);
                path.cubicTo(P1, P2, P3);
            }
            else
            {
                path.moveTo(P0);
                path.lineTo(P3);
            }
        }

        //painter->drawPath(path);//draw a filled shape

        polygonItem->setPolygon(path.toFillPolygon());

        /*
        QPainterPathStroker stroker;
        stroker.setWidth(0.3);
        stroker.createStroke(path);
        painter->drawPath(stroker.createStroke(path));// a stroke
        */

        //painter->restore();

        this->scene->addItem(polygonItem);
    }

    void addItems()
    {
        for(int i=0;i<10;i++)
        {
            qDebug()<<"Random value"<<random();//qrand() ;
            QGraphicsEllipseItem * item = new QGraphicsEllipseItem(0,0,10,10);

            item->setFlag(QGraphicsEllipseItem::ItemIsMovable);
            item->transform().translate(-5,-5);
            //item->setPen(QPen(QColor(Qt::cyan)));
            item->setBrush(QBrush(QColor(Qt::cyan)));

            qreal rdx = random();
            qreal rdy = random();

            QRectF frame = this->scene->sceneRect();

            QPointF offset(frame.width() *rdx , frame.height() *rdy);

            keypoints.append(offset);

            item->setPos(offset);

            this->scene->addItem(item);
        }

        drawCurve();
        /*
        QPainterPath paint;

        paint.moveTo();
        paint.cubicTo();
        */
    }

    void mousePressEvent(QMouseEvent *event)
    {
        //qDebug()<<this->scene->selectedItems()[0]->pos()<<":pos";
        qDebug()<<event->pos()<<":Pos";
        update();
        QWidget::mousePressEvent(event);
    }

    void mouseMoveEvent(QMouseEvent *event)
    {
        update();
        QWidget::mouseMoveEvent(event);
    }

    void mouseReleaseEvent(QMouseEvent *event)
    {
        update();
        QWidget::mouseReleaseEvent(event);
        qDebug()<<event->pos()<<":Pos";
    }

    /*

    QList<QPointF*> getInterpolatedPoints()
    {
        return;
    }

    QList<QPointF*> getValueAt(qreal dx)
    {
        return;
    }
    */

signals:

public slots:
};

#endif // CURVEWIDGET_H
