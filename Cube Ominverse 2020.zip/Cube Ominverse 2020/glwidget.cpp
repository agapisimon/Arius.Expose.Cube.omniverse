

#include<core/camera.h>
#include<core/text.h>
#include<core/text3d.h>
#include"glwidget.h"

Cube3DViewPort::Cube3DViewPort(QGLWidget  *parent) : QGLWidget(parent)
{
    this->grabKeyboard();

    setWindowTitle(QString("Cube Omniverse OpenglView"));

    setFormat(QGLFormat(QGL::SampleBuffers));

    //THIS IS USEFUL DONT DELETE

    /*
    QLabel *controlsLabel = new QLabel(QString("   Camera:"));
    QPushButton *button  = new QPushButton(QString("Move"));
    QPushButton *button1 = new QPushButton(QString("Scale"));
    QPushButton *button2 = new QPushButton(QString("Rotate"));
    //QPushButton *button3 = new QPushButton(QString("Zoom"));

    QLabel *viewLabel = new QLabel(QString("  View Mode:"));

    QComboBox * combobox = new QComboBox;
    QStringList comboboxlist;
    comboboxlist.append(QString("Top"));
    comboboxlist.append(QString("Bottom"));
    comboboxlist.append(QString("Front"));
    comboboxlist.append(QString("Back"));
    comboboxlist.append(QString("Right"));
    comboboxlist.append(QString("Left"));
    comboboxlist.append(QString("Perspective"));
    comboboxlist.append(QString("Ortho"));
    comboboxlist.append(QString("Camera"));
    combobox->addItems(comboboxlist);


    QLabel *shadeLabel = new QLabel(QString("  Shade Mode"));
    QComboBox * shadeCombobox = new QComboBox;
    QStringList scomboboxlist;
    scomboboxlist.append(QString("Wireframe"));
    scomboboxlist.append(QString("Flat"));
    scomboboxlist.append(QString("Smooth"));
    scomboboxlist.append(QString("Edged"));
    scomboboxlist.append(QString("Xray"));
    scomboboxlist.append(QString("Points"));

    shadeCombobox->addItems(scomboboxlist);

    QLabel *objectLabel = new QLabel(QString("   Object:"));
    QPushButton *Obutton  = new QPushButton(QString("Select"));
    QPushButton *Obutton1  = new QPushButton(QString("Move"));
    QPushButton *Obutton2 = new QPushButton(QString("Scale"));
    QPushButton *Obutton3 = new QPushButton(QString("Rotate"));

    toolbar.addWidget(objectLabel);
    toolbar.addWidget(Obutton);
    toolbar.addWidget(Obutton1);
    toolbar.addWidget(Obutton2);
    toolbar.addWidget(Obutton3);

    QLabel *PlaneTransformLabel = new QLabel(QString("   Plane Transforms:"));
    QComboBox * planexCombobox = new QComboBox;
    QStringList planexcomboboxlist;
    planexcomboboxlist.append(QString("plane XY  "));
    planexcomboboxlist.append(QString("plane ZX  "));
    planexcomboboxlist.append(QString("plane YZ  "));
    planexCombobox->addItems(planexcomboboxlist);
    toolbar.addWidget(PlaneTransformLabel);
    toolbar.addWidget(planexCombobox);



    toolbar.addWidget(viewLabel);
    toolbar.addWidget(combobox);

    toolbar.addWidget(shadeLabel);
    toolbar.addWidget(shadeCombobox);
    toolbar.move(rect().topLeft().x()+200,rect().topLeft().y());

    toolbar.setParent(this);
    toolbar.show();
    */

    /*
    QVBoxLayout *boxLayout = new QVBoxLayout(this);
    QMenuBar* menuBar = new QMenuBar();
    QMenu *fileMenu = new QMenu("File");
    menuBar->addMenu(fileMenu);
    fileMenu->addAction("Save");
    fileMenu->addAction("Exit");
    boxLayout->addWidget(menuBar);
    layout()->setMenuBar(this);
    */
}

Cube3DViewPort::~Cube3DViewPort()
{
}

QSize Cube3DViewPort::minimumSizeHint() const
{
    return QSize(50, 50);
}

QSize Cube3DViewPort::sizeHint() const
{
    return QSize(400, 400);
}

void Cube3DViewPort::initializeGL()
{
    //glClearColor(0.6f, 0.8f, 0.7f, 1.0f);
    glClearColor(c1,c1,c1,1.0f);
    txt3d.init();

}

void Cube3DViewPort::resizeGL(int width, int height)
{

    camera3d.setupView(width,height);
    update();    
}


void Cube3DViewPort::drawAllViews(int width,int height)
{
    const GLfloat light_position[4] = {0.0f, 8.0f, 8.0f, 1.0f};
    const GLfloat light_diffuse[4]  = {1.0f, 1.0f, 1.0f, 1.0f};
    const GLfloat light_specular[4] = {1.0f, 1.0f, 1.0f, 1.0f};
    const GLfloat light_ambient[4]  = {0.2f, 0.2f, 0.3f, 1.0f};
    double aspect;

    // Calculate aspect of window
    if( height > 0 )
    {
        aspect = (double)width / (double)height;
    }
    else
    {
        aspect = 1.0;
    }

    // Clear screen
    //glClearColor( 0.0f, 0.0f, 0.0f, 0.0f);
    glClearColor(c1,c1,c1,1.0f);
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

    // Enable scissor test
    glEnable( GL_SCISSOR_TEST );

    // Enable depth test
    glEnable( GL_DEPTH_TEST );
    glDepthFunc( GL_LEQUAL );


    // ** ORTHOGONAL VIEWS **

    // For orthogonal views, use wireframe rendering
    glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );

    // Enable line anti-aliasing
    glEnable( GL_LINE_SMOOTH );
    glEnable( GL_BLEND );
    glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

    // Setup orthogonal projection matrix
    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();
    glOrtho( -3.0*aspect, 3.0*aspect, -3.0, 3.0, 1.0, 50.0 );

    // Upper left view (TOP VIEW)
    glViewport( 0, height/2, width/2, height/2 );
    glScissor( 0, height/2, width/2, height/2 );
    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();
    gluLookAt( 0.0f, 10.0f, 1e-3f,   // Eye-position (above)
               0.0f, 0.0f, 0.0f,     // View-point
               0.0f, 1.0f, 0.0f );   // Up-vector
    meshogl.drawGrid2D( 1, 30 );
    meshogl.drawTorus(5,5);

    // Lower left view (FRONT VIEW)
    glViewport( 0, 0, width/2, height/2 );
    glScissor( 0, 0, width/2, height/2 );
    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();
    gluLookAt( 0.0f, 0.0f, 10.0f,    // Eye-position (in front of)
               0.0f, 0.0f, 0.0f,     // View-point
               0.0f, 1.0f, 0.0f );   // Up-vector
    meshogl.drawGrid2D( 1, 30 );
    meshogl.drawTorus(5,5);

    // Lower right view (SIDE VIEW)
    glViewport( width/2, 0, width/2, height/2 );
    glScissor( width/2, 0, width/2, height/2 );
    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();
    gluLookAt( 10.0f, 0.0f, 0.0f,    // Eye-position (to the right)
               0.0f, 0.0f, 0.0f,     // View-point
               0.0f, 1.0f, 0.0f );   // Up-vector
    meshogl.drawGrid2D( 1, 30 );
    meshogl.drawTorus(5,5);

    // Disable line anti-aliasing
    glDisable( GL_LINE_SMOOTH );
    glDisable( GL_BLEND );


    // ** PERSPECTIVE VIEW **

    // For perspective view, use solid rendering
    glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );

    // Enable face culling (faster rendering)
    glEnable( GL_CULL_FACE );
    glCullFace( GL_BACK );
    glFrontFace( GL_CW );

    // Setup perspective projection matrix
    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();
    gluPerspective( 65.0f, aspect, 1.0f, 50.0f );

    // Upper right view (PERSPECTIVE VIEW)
    glViewport( width/2, height/2, width/2, height/2 );
    glScissor( width/2, height/2, width/2, height/2 );
    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();
    gluLookAt( 3.0f, 1.5f, 3.0f,     // Eye-position
               0.0f, 0.0f, 0.0f,     // View-point
               0.0f, 1.0f, 0.0f );   // Up-vector

    // Configure and enable light source 1
    glLightfv( GL_LIGHT1, GL_POSITION, light_position );
    glLightfv( GL_LIGHT1, GL_AMBIENT, light_ambient );
    glLightfv( GL_LIGHT1, GL_DIFFUSE, light_diffuse );
    glLightfv( GL_LIGHT1, GL_SPECULAR, light_specular );
    glEnable( GL_LIGHT1 );
    glEnable( GL_LIGHTING );

    // Draw scene
    meshogl.drawTorus(5,5);

    // Disable lighting
    glDisable( GL_LIGHTING );
    // Disable face culling
    glDisable( GL_CULL_FACE );
    // Disable depth test
    glDisable( GL_DEPTH_TEST );
    // Disable scissor test
    glDisable( GL_SCISSOR_TEST );

    int active_view = 1;
    // Draw a border around the active view
    if( active_view > 0 && active_view != 2 )
    {
        glViewport( 0, 0, width, height );
        glMatrixMode( GL_PROJECTION );
        glLoadIdentity();
        glOrtho( 0.0, 2.0, 0.0, 2.0, 0.0, 1.0 );
        glMatrixMode( GL_MODELVIEW );
        glLoadIdentity();
        glColor3f( 1.0f, 1.0f, 0.6f );
        glTranslatef( (GLfloat) ((active_view - 1) & 1), (GLfloat) (1 - (active_view - 1) / 2), 0.0f );
        glBegin( GL_LINE_STRIP );
          glVertex2i( 0, 0 );
          glVertex2i( 1, 0 );
          glVertex2i( 1, 1 );
          glVertex2i( 0, 1 );
          glVertex2i( 0, 0 );
        glEnd();
    }
}

void Cube3DViewPort::drawLoop()
{

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    light.CreateFullLighting();
    camera3d.orbit_setupViewMatrix();
    glDisable(GL_LIGHTING);    
    meshogl.drawWorldAxis(this);
    meshogl.drawGrid();
    glShadeModel(GL_SMOOTH);
    glEnable(GL_LIGHTING);
    meshogl.drawObj();


    update();

}

void Cube3DViewPort::importFiles()
{

    QString fileName = QFileDialog::getOpenFileName(this, tr("load file"), "/Object", "Files(*.stl *.obj *.3ds)");


    if(!fileName.isNull())
    {
        if(fileName.endsWith(".3ds"))
        {
        }

        if(fileName.endsWith(".Obj"))
        {
            qDebug()<<"Importing Obj";

            //meshogl.obj.loadOBJ((const char*)fileName.unicode());
            meshogl.obj.loadOBJ("D:\QT docs\Cube Omiverse C++ version 1 - QT 4.8.6\Cube\ameaba.obj");

            qDebug()<<"Importing Obj completed";
        }

        if(fileName.endsWith(".stl"))
        {

        }

        if(fileName.endsWith(".md5"))
        {

        }

        if(fileName.endsWith(".cube"))
        {

        }
    }
}


void Cube3DViewPort::paintGL()
{
    int rendermode =0;

    switch(rendermode)
    {
        case FILL:
           drawLoop();
          break;
        case WIRE: /* basic wireframe mode */
          glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
           drawLoop();
          glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
          break;
        case BACKFACE: /* use backface culling to clean things up */
          glEnable(GL_CULL_FACE);
          glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
          drawLoop();
          glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
          glDisable(GL_CULL_FACE);
          break;
    }
}


void Cube3DViewPort::wheelEvent(QWheelEvent *event)
{
    float zoomfactor = event->delta();

    camera3d.zoom(zoomfactor);

    qDebug()<<"zoom:"<<zoomfactor;

    updateGL();

}



void Cube3DViewPort::mousePressEvent(QMouseEvent *event)
{
    qDebug()<<"Mouse Press Event:";

    lastPos = event->pos();

    camera3d.raycastscene(event);

    //camera3d.projectScreenToWorld(event,width(),height());

    updateGL();

}

void Cube3DViewPort::mouseReleaseEvent(QMouseEvent * event)
{
    zooming = false;
}

void Cube3DViewPort::mouseMoveEvent(QMouseEvent *event)
{

    QPoint delta =  event->pos()- lastPos;

    camera3d.grabMouseEvents(event,delta);
    lastPos = event->pos();
    updateGL();
}

void Cube3DViewPort::mouseDoubleClickEvent(QMouseEvent *event)
{

}

void Cube3DViewPort::keyPressEvent(QKeyEvent * event)
{
    camera3d.grabKeyBoard(event);

    if(event->key()==Qt::Key_I)
    {
        importFiles();
    }
}





