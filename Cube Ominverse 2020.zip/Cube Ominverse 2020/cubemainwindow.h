#ifndef CUBEMAINWINDOW_H
#define CUBEMAINWINDOW_H
#include<QtWidgets>
#include<QMainWindow>
#include<toolswidget.h>
#include<propertieswidget.h>
#include<timelinewidget.h>
#include<about.h>
//#include <QMainWindow>

class CubeMainWindow : public QMainWindow
{
    About about;
    Q_OBJECT
public:
    explicit CubeMainWindow(QWidget *parent = 0);


    void iniUI()
    {
        setTheme();
        setTitleDetails();
        CreateMenue();
        CreateToolBar();
        CreateDockWindows();
        CreateStatusBar();

        about.hide();
        //about.move(this->width()/2,this->height()/2);

        //about.showNormal();


        this->showMaximized();

    }
    void setTheme()
    {
        //using menu to switch styles
        //qDebug()<<"Loading Styles";

        QFile file(":/glowBlue.stylesheet");

       // QString s ="darkorange.stylesheet"

       // QString s = "levelfour.stylesheet"
       // QString s = "pagefold.stylesheet"
       // QString s = "glowsilver.stylesheet"

        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
               this->setStyleSheet(file.readAll());
               file.close();
        }


        qDebug()<<"Styles Loaded";
    }

    void setTitleDetails()
    {
       setWindowTitle(QString("CUBES Omniverse"));
       setWindowIcon(QIcon(":/mainicon.svg"));

       qDebug()<<"Title Details Loaded";
    }
    void CreateMenue()
    {

        QKeySequence shortcut;
        QIcon icon(":/mainicon.svg");

        exitAction = new QAction(icon, QString("Exit"), this);
        //exitAction->setShortcut('Ctrl+Q');
        exitAction->setShortcut(shortcut.New);
        exitAction->setStatusTip(QString("Exit application"));
        //self.exitAction.triggered.connect(self.close);

        QMenuBar *menubar = this->menuBar();
        //this->menuBar()->addMenu(QString("&File"));

         QMenu  * fileMenu = menubar->addMenu(QString("&File"));         
         QAction *openaction = fileMenu->addAction(icon, QString("Open"));
         fileMenu->addAction(icon, QString("Save"));
         fileMenu->addAction(icon, QString("Save As"));
         QAction *importaction= fileMenu->addAction(icon, QString("Import"));


         fileMenu->addAction(icon, QString("Export"));
         QAction *quitaction= fileMenu->addAction(icon, QString("Quit"));

         QMenu  * EditMenu = menubar->addMenu(QString("&"));//chinese format use QString('&Edit')
         EditMenu->addAction(exitAction);

         QMenu  * CreateMenu = menubar->addMenu(QString("&Create"));
         CreateMenu->addAction(exitAction);

         QMenu  * AnimationMenu = menubar->addMenu(QString("&Animation"));
         AnimationMenu->addAction(exitAction);

         QMenu  *CurvesMenu = menubar->addMenu(QString("&Curves"));
         CurvesMenu->addAction(exitAction);

         QMenu  *SurfacesMenu = menubar->addMenu(QString("&Surfaces"));
         SurfacesMenu->addAction(exitAction);

         QMenu  *RenderingMenu = menubar->addMenu(QString("&Rendering"));
         RenderingMenu->addAction(exitAction);

         QMenu  *WindowsMenu = menubar->addMenu(QString("&Windows"));
         WindowsMenu->addAction(exitAction);

         QMenu  *HelpMenu = menubar->addMenu(QString("&Help"));

         QAction *aboutaction = HelpMenu->addAction(icon,QString("&About"));
         //QAction *quitaction  = HelpMenu->addAction(icon,QString("&Quit"));
         HelpMenu->addAction(quitaction);

         connect(aboutaction,SIGNAL(triggered(bool)),this,SLOT(closeAbout()));
         connect(quitaction,SIGNAL(triggered(bool)),this,SLOT(close()));
         connect(importaction,SIGNAL(triggered(bool)),this,SLOT(importDialog()));
         connect(openaction,SIGNAL(triggered(bool)),this,SLOT(importDialog()));

         qDebug()<<"main menues created";
    }
public slots:
    void closeAbout()
    {
        about.showNormal();
    }

    void importDialog()
    {
        QStringList stringlist;
        stringlist.append(QString("Mesh File (*.cube *.obj *.md5 *.md2)"));
        stringlist.append(QString("Images (*.png *.xpm *.jpg)"));
        stringlist.append(QString("Vectors Images (*.svg *.pdf *.eps)"));
        stringlist.append(QString("Text files (*.txt)"));
        stringlist.append(QString("XML files (*.xml)"));


        QFileDialog dialog;





        //dialog.setFilters(stringlist);
        dialog.show();

        QStringList fileNames;

        if (dialog.exec())
        {
            fileNames = dialog.selectedFiles();
            qDebug()<<fileNames;





            statusBar()->showMessage(fileNames[0]);
        }

    }
public:
    void CreateToolBar()
    {
        QToolBar * toolbar = new QToolBar(QString("Save"));

        this->addToolBar(toolbar);

        toolbar->addAction(QString("one"));
        toolbar->addAction(QString("two"));
        toolbar->addAction(QString("three"));

        toolbar = addToolBar(QString("Open"));
        toolbar->addAction(exitAction);
        toolbar->addAction(exitAction);
        toolbar->addAction(exitAction);

        toolbar = addToolBar(QString("Undo"));
        toolbar->addAction(exitAction);

        toolbar = addToolBar(QString("Redo"));
        toolbar->addAction(exitAction);
        qDebug()<<"main toolbar created";

        ///////


        QLabel *viewLabel = new QLabel(QString("  View Mode:"));

        QComboBox * combobox = new QComboBox;
        QStringList comboboxlist;
        comboboxlist.append(QString("Top"));
        comboboxlist.append(QString("Bottom"));
        comboboxlist.append(QString("Front"));
        comboboxlist.append(QString("Back"));
        comboboxlist.append(QString("Right"));
        comboboxlist.append(QString("Left"));
        comboboxlist.append(QString("Perspective"));
        comboboxlist.append(QString("Ortho"));
        comboboxlist.append(QString("Camera"));
        combobox->addItems(comboboxlist);

        toolbar->addSeparator();
        toolbar->addWidget(viewLabel);
        toolbar->addWidget(combobox);


        QLabel *controlsLabel = new QLabel(QString("   Camera:"));
        QPushButton *button  = new QPushButton(QString("Move"));
        QPushButton *button1 = new QPushButton(QString("Scale"));
        QPushButton *button2 = new QPushButton(QString("Rotate"));
        //QPushButton *button3 = new QPushButton(QString("Zoom"));

        toolbar->addSeparator();
        toolbar->addWidget(button);
        toolbar->addWidget(button1);
        toolbar->addWidget(button2);

        QLabel *rcontrolsLabel2 = new QLabel(QString("Shade:"));
        QRadioButton *rbutton  = new QRadioButton(QString("Edges"));
        QRadioButton *rbutton1 = new QRadioButton(QString("Flat"));
        QRadioButton *rbutton2 = new QRadioButton(QString("Smooth"));
        QRadioButton *rbutton3 = new QRadioButton(QString("Edge+Faces"));
        QRadioButton *rbutton4 = new QRadioButton(QString("Vertices"));
        //QPushButton *button3 = new QPushButton(QString("Zoom"));

        toolbar->addSeparator();
        toolbar->addWidget(rcontrolsLabel2);
        toolbar->addWidget(rbutton);
        toolbar->addWidget(rbutton1);
        toolbar->addWidget(rbutton2);
        toolbar->addWidget(rbutton3);
        toolbar->addWidget(rbutton4);

        /*

        QLabel *viewLabel = new QLabel(QString("  View Mode:"));

        QComboBox * combobox = new QComboBox;
        QStringList comboboxlist;
        comboboxlist.append(QString("Top"));
        comboboxlist.append(QString("Bottom"));
        comboboxlist.append(QString("Front"));
        comboboxlist.append(QString("Back"));
        comboboxlist.append(QString("Right"));
        comboboxlist.append(QString("Left"));
        comboboxlist.append(QString("Perspective"));
        comboboxlist.append(QString("Ortho"));
        comboboxlist.append(QString("Camera"));
        combobox->addItems(comboboxlist);
        */


        QLabel *shadeLabel = new QLabel(QString("  Shade Mode"));
        QComboBox * shadeCombobox = new QComboBox;
        QStringList scomboboxlist;
        scomboboxlist.append(QString("Wireframe"));
        scomboboxlist.append(QString("Flat"));
        scomboboxlist.append(QString("Smooth"));
        scomboboxlist.append(QString("Edged"));
        scomboboxlist.append(QString("Xray"));
        scomboboxlist.append(QString("Points"));

        shadeCombobox->addItems(scomboboxlist);



        toolbar->addSeparator();
        toolbar->addWidget(shadeLabel);
        toolbar->addWidget(shadeCombobox);


        QLabel *objectLabel = new QLabel(QString("   Object:"));
        QPushButton *Obutton  = new QPushButton(QString("Select"));
        QPushButton *Obutton1  = new QPushButton(QString("Move"));
        QPushButton *Obutton2 = new QPushButton(QString("Scale"));
        QPushButton *Obutton3 = new QPushButton(QString("Rotate"));


        toolbar->addSeparator();
        toolbar->addWidget(objectLabel);
        toolbar->addWidget(Obutton);
        toolbar->addWidget(Obutton1);
        toolbar->addWidget(Obutton2);
        toolbar->addWidget(Obutton3);


        QLabel *PlaneTransformLabel = new QLabel(QString("   Plane Transforms:"));
        QComboBox * planexCombobox = new QComboBox;
        QStringList planexcomboboxlist;

        planexcomboboxlist.append(QString("plane XY  "));
        planexcomboboxlist.append(QString("plane ZX  "));
        planexcomboboxlist.append(QString("plane YZ  "));
        planexCombobox->addItems(planexcomboboxlist);


        toolbar->addSeparator();
        toolbar->addWidget(PlaneTransformLabel);
        toolbar->addWidget(planexCombobox);

        //toolbar.setParent(this);
        //toolbar.show();

    }

    void keyPressEvent(QKeyEvent * event)
    {
        if(event->key() == Qt::Key_Control|event->key() == Qt::Key_H)
        {
            hide_show_dock();
        }
    }

    void hide_show_dock()
    {
        if(hidedocks)
        {
            this->hidedocks = false;
        }
        else
        {
            this->hidedocks = true;
        }

        this->ToolBoxEditorDock->setVisible(this->hidedocks);
        this->propertiesEditorDoc->setVisible(this->hidedocks);
        this->nodeEditorDoc->setVisible(this->hidedocks);

    }

    void CreateStatusBar()
    {
       this->statusBar()->showMessage("Ready");
    }

    void CreateDockWindows()
    {
        propertiesEditorDoc  = new QDockWidget(QString("Properties Editor"));
        ToolBoxEditorDock    = new QDockWidget(QString("Tool Box"));
        nodeEditorDoc        = new QDockWidget(QString("Node Editor"));
        TimeLineEditorDoc    = new QDockWidget(QString("Time Line"));
        scenegraphDock       = new QDockWidget(QString("Scene Graph"));
        materialEditorDock   = new QDockWidget(QString("Material Editor"));
        curveEditorDock      = new QDockWidget(QString("Curve Editor"));

        curveEditorDock->hide();
        materialEditorDock->hide();
        scenegraphDock->hide();
        ToolBoxEditorDock->hide();
        propertiesEditorDoc->hide();
        nodeEditorDoc->hide();

        propertiesEditorDoc->setWindowFlags(Qt::WindowTitleHint );
        ToolBoxEditorDock->setWindowFlags(Qt::WindowTitleHint );
        nodeEditorDoc->setWindowFlags(Qt::WindowTitleHint );
        TimeLineEditorDoc->setWindowFlags(Qt::WindowTitleHint );
        scenegraphDock->setWindowFlags(Qt::WindowTitleHint );
        materialEditorDock->setWindowFlags(Qt::WindowTitleHint );
        curveEditorDock->setWindowFlags(Qt::WindowTitleHint );


        ToolsWidget * toolbox  = new ToolsWidget;
        toolbox->showMaximized();

        PropertiesWidget * props = new PropertiesWidget;
        props->showMaximized();

        QWidget * nodeEditor = new QWidget;
        nodeEditor->showMaximized();

        TimeLineWidget * timelinewidget = new TimeLineWidget;
        timelinewidget->showMaximized();

        PropertiesWidget * scenegraphWidget = new PropertiesWidget;
        scenegraphWidget->showMaximized();


        propertiesEditorDoc->setWidget(props);
        ToolBoxEditorDock->setWidget(toolbox);
        nodeEditorDoc->setWidget(nodeEditor);
        TimeLineEditorDoc->setWidget(timelinewidget);
        scenegraphDock->setWidget(scenegraphWidget);

        TimeLineEditorDoc->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea );
        this->addDockWidget(Qt::BottomDockWidgetArea, TimeLineEditorDoc);


        propertiesEditorDoc->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        this->addDockWidget(Qt::RightDockWidgetArea, propertiesEditorDoc);

        ToolBoxEditorDock->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        this->addDockWidget(Qt::RightDockWidgetArea, ToolBoxEditorDock);

        nodeEditorDoc->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        this->addDockWidget(Qt::RightDockWidgetArea, nodeEditorDoc);

        scenegraphDock->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        this->addDockWidget(Qt::RightDockWidgetArea, scenegraphDock);

        materialEditorDock->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        this->addDockWidget(Qt::RightDockWidgetArea, materialEditorDock);

        curveEditorDock->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        this->addDockWidget(Qt::RightDockWidgetArea, curveEditorDock);


        this->tabifyDockWidget(ToolBoxEditorDock,propertiesEditorDoc);
        this->tabifyDockWidget(propertiesEditorDoc,nodeEditorDoc);
        this->tabifyDockWidget(nodeEditorDoc,scenegraphDock);
        this->tabifyDockWidget(scenegraphDock,materialEditorDock);
        this->tabifyDockWidget(materialEditorDock,curveEditorDock);
        //nodeEditorDock->raise();
        //ToolBoxEditorDock->raise();
        this->setDockOptions(QMainWindow::VerticalTabs);



    }
private:

    QDockWidget *TimeLineEditorDoc;
    QDockWidget *nodeEditorDoc;
    QDockWidget *propertiesEditorDoc;
    QDockWidget *ToolBoxEditorDock;
    QDockWidget *scenegraphDock;
    QDockWidget *materialEditorDock;
    QDockWidget *curveEditorDock;

    QAction *exitAction;
    bool hidedocks = false;


signals:

public slots:


};

#endif // CUBEMAINWINDOW_H
