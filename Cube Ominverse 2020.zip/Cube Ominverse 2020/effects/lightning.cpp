#include "lightning.h"

Lightning::Lightning()
{

}

