#ifndef PARTICLES_H
#define PARTICLES_H

#include<stdlib.h>
#include<cmath>
#include<cstdlib>
#include<limits>

#include<vector>
#include<glm/glm.hpp>
#include<glm/gtx/intersect.hpp>

#include<core/importobj.h>
#include<core/constants.h>
#include<core/math.h>


class Particle
{
public:
    Particle()
    {
        climb = false;
        length = 0.0f;
        floatingLength = 0.0f;
    }

    //node position
    glm::vec3 pos;
    glm::vec3 scale;
    glm::vec3 rotation;

    glm::vec3 forward;
    glm::vec3 up;
    glm::vec3 left;

    glm::vec3 velocity;

    //primary grow direction, a weighted sum of the previous directions
    glm::vec3 primaryDir;
    //adhesion vector as a result from other scene objects */
    glm::vec3 adhesionVector;
    //a smoothed adhesion vector computed and used during the birth phase,
    //since the ivy leaves are align by the adhesion vector, this smoothed vector
    //allows for smooth transitions of leaf alignment
    glm::vec3 smoothAdhesionVector;
    //length of the associated ivy branch at this node
    float length;
    //length at the last node that was climbing
    float floatingLength;
    //climbing state
    bool climb;

};

// an ivy root point
class IvyRoot
{
public:

    // a number of nodes
    std::vector<Particle> nodes;

    //alive state
    bool alive;

    //number of parents, represents the level in the root hierarchy
    int parents;
};

class ivy
{
    ObjMeshExtended object;
    //the ivy roots
    std::vector<IvyRoot> roots;

    static inline glm::vec3 getRandomized()
    {
        glm::vec3 v = glm::vec3( rand()/(float)RAND_MAX-0.5f, rand()/(float)RAND_MAX-0.5f, rand()/(float)RAND_MAX-0.5f );

        glm::normalize(v);

        return  v;
    }

    static inline glm::vec3 getEpsilon()
    {
        return glm::vec3(std::numeric_limits<float>::epsilon(), std::numeric_limits<float>::epsilon(), std::numeric_limits<float>::epsilon());
    }

    static inline glm::vec3 getNormalized(glm::vec3 v)
    {
        glm::normalize(v);

        return  v;
    }

    static inline float getLength(glm::vec3 v)
    {
        return v.length();
    }

    static inline bool getBarycentricCoordinates( const glm::vec3& vector1, const glm::vec3& vector2, const glm::vec3& vector3, const glm::vec3& position, float& alpha, float& beta, float& gamma )
    {
        float area = 0.5f * getLength( glm::cross( vector2 - vector1, vector3 - vector1 ) );

        alpha = 0.5f * getLength( glm::cross( vector2 - position, vector3 - position ) ) / area;

        beta = 0.5f * getLength( glm::cross( vector1 - position, vector3 - position ) ) / area;

        gamma = 0.5f * getLength( glm::cross( vector1 - position, vector2 - position ) ) / area;

        //if (abs( 1.0f - alpha - beta - gamma ) > std::numeric_limits<float>::epsilon()) return false;
        if (abs( 1.0f - alpha - beta - gamma ) > 0.00001f) return false;

        return true;
    }



public:
    //the ivy size factor, influences the grow behaviour [0..0,1]
    float ivySize;

    // leaf size factor [0..0,1]
    float ivyLeafSize;

    // branch size factor [0..0,1]
    float ivyBranchSize;

    // maximum length of an ivy branch segment that is freely floating [0..1]
    float maxFloatLength;

    // maximum distance for adhesion of scene object [0..1]
    float maxAdhesionDistance;

    // weight for the primary grow vector [0..1]
    float primaryWeight;

    // weight for the random influence vector [0..1]
    float randomWeight;

    // weight for the gravity vector [0..1]
    float gravityWeight;

    // weight for the adhesion vector [0..1]
    float adhesionWeight;

    // the probability of producing a new ivy root per iteration [0..1]
    float branchingProbability;

    // the probability of creating a new ivy leaf [0..1]
    float leafProbability;

public:
    ivy()
    {
        resetSettings();
    }


    void resetSettings()
    {
        primaryWeight = 0.5f;
        randomWeight = 0.2f;
        gravityWeight = 1.0f;
        adhesionWeight = 0.1f;
        branchingProbability = 0.95f;
        leafProbability = 0.7;
        ivySize = 0.005f;
        ivyLeafSize = 1.5f;
        ivyBranchSize = 0.15;
        maxFloatLength = 0.1f;
        maxAdhesionDistance = 0.1f;
    }

    void setObjMesh(ObjMeshExtended mesh)
    {
        object = mesh;
    }

    //initialize a new ivy root
    void seed(const glm::vec3 &seedPos)
    {
        roots.clear();

        Particle particle;

        particle.pos = seedPos;

        particle.primaryDir = glm::vec3(0.0f, 1.0f, 0.0f);

        particle.adhesionVector = glm::vec3(0.0f, 0.0f, 0.0f);

        particle.length = 0.0f;

        particle.floatingLength = 0.0f;

        particle.climb = true;


        IvyRoot tmpRoot;

        tmpRoot.nodes.push_back( particle );

        tmpRoot.alive = true;

        tmpRoot.parents = 0;


        roots.push_back( tmpRoot );
    }



    //one single grow iteration
    void grow()
    {
        //parameters that depend on the scene object bounding sphere
        float local_ivySize = object.boundingSphereRadius * ivySize;

        float local_maxFloatLength = object.boundingSphereRadius * maxFloatLength;


        //normalize weights of influence
        float sum = primaryWeight + randomWeight + adhesionWeight;

        primaryWeight /= sum;

        randomWeight /= sum;

        adhesionWeight /= sum;


        //lets grow
        for (std::vector<IvyRoot>::iterator root = roots.begin(); root != roots.end(); ++root)
        {
            //process only roots that are alive
            if (!root->alive) continue;

            //let the ivy die, if the maximum float length is reached
            if (root->nodes.back().floatingLength > local_maxFloatLength) root->alive = false;


            //grow vectors: primary direction, random influence, and adhesion of scene objectss

                //primary vector = weighted sum of previous grow vectors
                glm::vec3 primaryVector = root->nodes.back().primaryDir;

                //random influence plus a little upright vector
                glm::vec3 randomVector = getRandomized() + glm::vec3(0.0f, 0.2f, 0.0f);
                randomVector = getNormalized(randomVector);

                //adhesion influence to the nearest triangle = weighted sum of previous adhesion vectors
                glm::vec3 adhesionVector = computeAdhesion(root->nodes.back().pos);

                //compute grow vector
                glm::vec3 growVector = local_ivySize * (primaryVector * primaryWeight + randomVector * randomWeight + adhesionVector * adhesionWeight);


            //gravity influence

                //compute gravity vector
                glm::vec3 gravityVector = local_ivySize * glm::vec3(0.0f, -1.0f, 0.0f) * gravityWeight;

                //gravity depends on the floating length
                gravityVector *= pow(root->nodes.back().floatingLength / local_maxFloatLength, 0.7f);


            //next possible ivy node

                //climbing state of that ivy node, will be set during collision detection
                bool climbing;

                //compute position of next ivy node
                glm::vec3 newPos = root->nodes.back().pos + growVector + gravityVector;

                //combine alive state with result of the collision detection, e.g. let the ivy die in case of a collision detection problem
                root->alive = root->alive & computeCollision(root->nodes.back().pos, newPos, climbing);

                //update grow vector due to a changed newPos
                growVector = newPos - root->nodes.back().pos - gravityVector;


            //create next ivy node
                Particle particle;

                particle.pos = newPos;

                particle.primaryDir = getNormalized( 0.5f * root->nodes.back().primaryDir + 0.5f * getNormalized( growVector ) );

                particle.adhesionVector = adhesionVector;

                particle.length = root->nodes.back().length + getLength(newPos - root->nodes.back().pos);

                particle.floatingLength = climbing ? 0.0f : root->nodes.back().floatingLength + getLength(newPos - root->nodes.back().pos);

                particle.climb = climbing;

            root->nodes.push_back( particle );
        }



        //lets produce child ivys
        for (std::vector<IvyRoot>::iterator root = roots.begin(); root != roots.end(); ++root)
        {
            //process only roots that are alive
            if (!root->alive) continue;

            //process only roots up to hierarchy level 3, results in a maximum hierarchy level of 4
            if (root->parents > 3) continue;


            //add child ivys on existing ivy nodes
            for (std::vector<Particle>::iterator node = root->nodes.begin(); node != root->nodes.end(); ++node)
            {
                //weight depending on ratio of node length to total length
                float weight = 1.0f - ( cos( node->length / root->nodes.back().length * 2.0f * PI) * 0.5f + 0.5f );

                //random influence
                float probability = rand()/(float)RAND_MAX;

                if (probability * weight > branchingProbability)
                {
                    //new ivy node
                    Particle tmpNode;

                    tmpNode.pos = node->pos;

                    tmpNode.primaryDir = glm::vec3(0.0f, 1.0f, 0.0f);

                    tmpNode.adhesionVector = glm::vec3(0.0f, 0.0f, 0.0f);

                    tmpNode.length = 0.0f;

                    tmpNode.floatingLength = node->floatingLength;

                    tmpNode.climb = true;


                    //new ivy root
                    IvyRoot tmpRoot;

                    tmpRoot.nodes.push_back( tmpNode );

                    tmpRoot.alive = true;

                    tmpRoot.parents = root->parents + 1;


                    roots.push_back( tmpRoot );


                    //limit the branching to only one new root per iteration, so return
                    return;
                }
            }
        }
    }
    // creates the ivy triangle mesh
    void birth()
    {

    }


private:
    //compute the adhesion of scene objects at a point pos
    glm::vec3 computeAdhesion(const glm::vec3 &pos)
    {
        //the resulting adhesion vector
        glm::vec3 adhesionVector;


        //define a maximum distance
        float local_maxAdhesionDistance = object.boundingSphereRadius * maxAdhesionDistance;

        float minDistance = local_maxAdhesionDistance;


        //find nearest triangle
        //for (std::vector<ObjPolygon>::iterator t = object.polygons.begin(); t != object.polygons.end(); ++t)
        for (int i =0;i< object.polygons.size(); i++)
        {
            //scalar product projection
            ObjPolygon poly = object.polygons[i];


            float nq = glm::dot(poly.normal, pos - object.vertices[poly.v[0]]);

            //continue if backside of triangle
            if ( nq < 0.0f ) continue;

            //project last node onto triangle plane, e.g. scalar product projection
            glm::vec3 p0 = pos - poly.normal * nq;

            //compute barycentric coordinates of p0
            float alpha, beta, gamma;

            if (getBarycentricCoordinates(object.vertices[poly.v[0]], object.vertices[poly.v[1]], object.vertices[poly.v[2]], p0, alpha, beta, gamma))
            {
                //compute distance
                float distance = getLength(p0 - pos);

                //find shortest distance
                if (distance < minDistance)
                {
                    minDistance = distance;

                    adhesionVector = getNormalized(p0 - pos);

                    //distance dependent adhesion vector
                    adhesionVector *= 1.0f - distance / local_maxAdhesionDistance;
                }
            }
        }

        return adhesionVector;
    }

    //computes the collision detection for an ivy segment oldPos->newPos, newPos will be modified if necessary
    bool computeCollision(const glm::vec3 &oldPos, glm::vec3 &newPos, bool &climbing)
    {
        //reset climbing state
        climbing = false;

        bool intersection;

        int deadlockCounter = 0;

        do
        {
            intersection = false;

            //for (std::vector<BasicTriangle>::iterator t = Common::mesh.triangles.begin(); t != Common::mesh.triangles.end(); ++t)
            //{
            for (int i=0;i<object.polygons.size();i++)
            {
                ObjPolygon poly = object.polygons[i];
                //compute intersection with triangle plane parametrically: intersectionPoint = oldPos + (newPos - oldPos) * t0;
                float t0 = -glm::dot( poly.normal, oldPos - object.vertices[poly.v[0]] ) / glm::dot( poly.normal, newPos - oldPos );

                //plane intersection
                if ((t0 >= 0.0f) && ( t0 <= 1.0f))
                {
                    //intersection point
                    glm::vec3 intersectionPoint = oldPos + (newPos - oldPos) * t0;

                    float alpha, beta, gamma;

                    //triangle intersection
                    if (getBarycentricCoordinates(object.vertices[poly.v[0]], object.vertices[poly.v[1]],object.vertices[poly.v[2]], intersectionPoint, alpha, beta, gamma))
                    {
                        //test on entry or exit of the triangle mesh
                        bool entry =glm::dot( poly.normal, newPos - oldPos) < 0.0f ? true : false;

                        if (entry)
                        {
                            //project newPos to triangle plane
                            glm::vec3 p0 = newPos - poly.normal * glm::dot(poly.normal, newPos - object.vertices[poly.v[0]]);

                            //mirror newPos at triangle plane
                            newPos += 2.0f * (p0 - newPos);

                            intersection = true;

                            climbing = true;
                        }
                    }
                }
            }

            //abort climbing and growing if there was a collistion detection problem
            if (deadlockCounter++ > 5)
            {
                return false;
            }
        }
        while (intersection);

        return true;
    }

    /*

    void projectScreenToWorld(QMouseEvent *event,int width,int height)
    {
        //get projection, model and view matrix
        //setupCamera();

        /////////////
        //setup view and projection matrix
        glMatrixMode(GL_PROJECTION);

        glLoadIdentity();

        clipNear = 0.01 * object.boundingSphereRadius;//mesh boundingSphereRadius

        clipFar = 10.0f * object.boundingSphereRadius; //mesh boundingSphereRadius

        aspectRatio = (float)width/ (float)height;

        setupPerspectiveMatrix();

        setupViewMatrix();
        ///////////////////////////////

        glMatrixMode(GL_MODELVIEW);

        glLoadIdentity();

        double projMatrix[16];

        glGetDoublev(GL_PROJECTION_MATRIX, projMatrix);

        double modelMatrix[16];

        glGetDoublev(GL_MODELVIEW_MATRIX, modelMatrix);

        int viewPort[4];

        glGetIntegerv(GL_VIEWPORT, viewPort);


        //compute a "click ray"
        double x0, y0, z0, x1, y1, z1;

        gluUnProject(event->pos().x(), height - event->pos().y(), 0.0, modelMatrix, projMatrix, viewPort, &x0, &y0, &z0);

        gluUnProject(event->pos().x(), height - event->pos().y(), 1.0, modelMatrix, projMatrix, viewPort, &x1, &y1, &z1);

        glm::vec3 p0(x0, y0, z0);

        glm::vec3 p1(x1, y1, z1);

        projectPointOnMesh(p0,p1);


        //updateGL();
    }
    */

    //projection for getting sead point aka source for the particles
    void projectPointOnMesh(glm::vec3 p0,glm::vec3 p1)
    {
        //find intersecting triangle with minimum distance
        float minDistance = (std::numeric_limits<float>::max)();

        glm::vec3 seedPoint;

        //for (std::vector<BasicTriangle>::iterator t = Common::mesh.triangles.begin(); t != Common::mesh.triangles.end(); ++t)
        //{
        for (int i=0;i<object.polygons.size();i++)
        {
            ObjPolygon poly = object.polygons[i];

            //compute intersection with triangle plane parametrically: intersectionPoint = p0 + (p1 - p0) * t0;
            float t0 = -glm::dot( poly.normal, p0 - object.vertices[poly.v[0]] ) / glm::dot( poly.normal, p1 - p0 );

            //plane intersection
            if ((t0 >= 0.0f) && ( t0 <= 1.0f))
            {
                //intersection point
                glm::vec3 intersectionPoint = p0 + (p1 - p0) * t0;

                float alpha, beta, gamma;

                //triangle intersection
                if (getBarycentricCoordinates(object.vertices[poly.v[0]],object.vertices[poly.v[1]], object.vertices[poly.v[2]], intersectionPoint, alpha, beta, gamma))
                {
                    //test on entry or exit of the triangle mesh
                    bool entry = glm::dot( poly.normal, p1 - p0) < 0.0f ? true : false;

                    if (entry)
                    {
                        //commpute distance
                        float distance = getLength(intersectionPoint - p0);

                        if (distance < minDistance)
                        {
                            minDistance = distance;

                            seedPoint = intersectionPoint;
                        }
                    }
                }
            }
        }

        //no triangle found
        if (minDistance == (std::numeric_limits<float>::max)())
        {
            //compute intersection with grid plane
            float t = -p0.y / (p1.y - p0.y);

            seedPoint = p0 + t * (p1 - p0);
        }

        seed(seedPoint);
    }

    //projection for getting sead point aka source for the particles
    void projectPointOnMesh(Ray ray)
    {

        glm::vec3 p0 = ray.p0;
        glm::vec3 p1 = ray.p1;


        //find intersecting triangle with minimum distance
        float minDistance = (std::numeric_limits<float>::max)();

        glm::vec3 seedPoint;

        //for (std::vector<BasicTriangle>::iterator t = Common::mesh.triangles.begin(); t != Common::mesh.triangles.end(); ++t)
        //{
        for (int i=0;i<object.polygons.size();i++)
        {
            ObjPolygon poly = object.polygons[i];

            //compute intersection with triangle plane parametrically: intersectionPoint = p0 + (p1 - p0) * t0;
            float t0 = -glm::dot( poly.normal, p0 - object.vertices[poly.v[0]] ) / glm::dot( poly.normal, p1 - p0 );

            //plane intersection
            if ((t0 >= 0.0f) && ( t0 <= 1.0f))
            {
                //intersection point
                glm::vec3 intersectionPoint = p0 + (p1 - p0) * t0;

                float alpha, beta, gamma;

                //triangle intersection
                if (getBarycentricCoordinates(object.vertices[poly.v[0]],object.vertices[poly.v[1]], object.vertices[poly.v[2]], intersectionPoint, alpha, beta, gamma))
                {
                    //test on entry or exit of the triangle mesh
                    bool entry = glm::dot( poly.normal, p1 - p0) < 0.0f ? true : false;

                    if (entry)
                    {
                        //commpute distance
                        float distance = getLength(intersectionPoint - p0);

                        if (distance < minDistance)
                        {
                            minDistance = distance;

                            seedPoint = intersectionPoint;
                        }
                    }
                }
            }
        }

        //no triangle found
        if (minDistance == (std::numeric_limits<float>::max)())
        {
            //compute intersection with grid plane
            float t = -p0.y / (p1.y - p0.y);

            seedPoint = p0 + t * (p1 - p0);
        }

        seed(seedPoint);
    }
};




#endif
