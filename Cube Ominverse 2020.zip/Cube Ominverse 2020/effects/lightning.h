#ifndef LIGHTNING_H
#define LIGHTNING_H
#include<QtGui>
#include<glm/glm.hpp>
#include<stdlib.h>
#include<vector>
#include<core/curve.h>
#include<random>

double randInt(double a, double b)
{
    return M + (rand() / ( RAND_MAX / (a-b) ) ) ;
}

int randInt(int a, int b)
{
    return M + (rand() / ( RAND_MAX / (a-b) ) ) ;
}

float randFloat(float a, float b)
{
    return ((b-a)*((float)rand()/RAND_MAX))+a;
}

class Lightning
{
public:
        Lightning *parentInstance = NULL;

        QList<Lightning> childrenArray;


        enum ALPHATYPE
        {
            NONE,
            TIP_TO_END,
            GENERATION,
        };

        QTimer lifeTimer;

        glm::vec3 t;
        glm::vec3 delta;
        glm::vec3 start;
        glm::vec3 end;

        int seed1;
        int seed2;

        float tx;
        float ty;
        float tz;

        float dx;
        float dy;
        float dz;

        float  endY;
        float  endX;
        float  endZ;

        float  soffx;
        float  soffy;
        float  soffz;

        float  boff;
        float  angle;

        float  absolutePosition = 1;
        float  calculatedSpeed;
        float  stepEvery;
        float  position = 0;
        float  multi;
        float  speed = 1;
        int    steps;

        int childrenSmoothPercentage;
        int generation;
        float childrenLengthDecay = 0.0;
        float childrenProbabilityDecay = 0;


        //ALPHATYPE alphaFadeType ;
        //ALPHATYPE thicknessFadeType;

        float multi2;
        float len;
        float soff;

        float startX;
        float startY;
        float startZ;

        float boffx;
        float boffy;
        float boffZ;

        int smoothPercentage= 50;
        int childrenMaxCount = 4;

        bool childrenDetachedEnd = false;
        bool mouseEnabled = false;
        bool initialized  = false;
        bool alphaFade    = true;
        bool isVisible = true;

        float  calculatedWavelength;
        float  childrenAngleVariation = 60;
        float  childrenMaxGenerations= 3;
        float  maxLengthVary = 0;
        float  wavelength = 0.3;
        float  amplitude = 0.5;
        float  childAngle =0;
        float  lifeSpan;

        float  thicknessDecay;
        float  childrenLifeSpanMax = 0;
        float  maxLength = 0;
        float  childrenMaxCountDecay = 0.5;
        float  childrenLifeSpanMin = 0;

        float  childrenProbability = 0.025;
        float  thickness;

        QList<glm::vec3> soffs;
        QList<glm::vec3> boffs;

        QGraphicsRectItem holder;
        QGraphicsEllipseItem itemchildren;
        QGraphicsEllipseItem item;

        QString thicknessFadeType;
        QString alphaFadeType;



       Lightning(float _thickness = 2, int _generation = 0)
       {
            //childrenArray = [];

            smoothPercentage = 50;
            childrenMaxGenerations = 3;
            childrenProbability = 0.025;
            childrenProbabilityDecay = 0;
             childrenMaxCount = 4;
             childrenMaxCountDecay = 0.5;
             //childrenLengthDecay = 0;
             childrenAngleVariation = 60;
             childrenLifeSpanMin = 0;
             childrenLifeSpanMax = 0;
             childrenDetachedEnd = false;
             maxLength = 0;
             maxLengthVary = 0;
             isVisible = true;
             alphaFade = true;
             initialized = false;
             wavelength = 0.3;
             amplitude = 0.5;
             speed = 1;

             position = 0;
             absolutePosition = 1;
             mouseEnabled = false;

             thickness = _thickness;
             alphaFadeType = GENERATION;
             thicknessFadeType = NONE;
             generation = _generation;

             if(generation == 0)
             {
                init();
             }
       }


       void init()
       {
          randomizeSeeds();

          if(lifeSpan > 0)
          {
              lifeTimer.setInterval(1000);
              lifeTimer.start();
             //startLifeTimer();
          }
          multi2 = 0.03;

          //holder = new Sprite();
          //holder.mouseEnabled = false;

          startX = 0;
          startY = 0;
          startZ = 0;

          endX = 600;
          endY = 600;
          endZ = 600;

          stepEvery = 4;
          steps = 50;

          /*

          sbd = new BitmapData(_steps,1,false);
          bbd = new BitmapData(_steps,1,false);
          */

          /*

          soffs.push_back(new QPoint(0,0));
          soffs.push_back(new QPoint(0,0));

          boffs.push_back(new QPoint(0,0));
          boffs.push_back(new QPoint(0,0));
          */

          //boffs = [new Point(0,0),new Point(0,0)];

          if(generation == 0)
          {
             //smooth = new Sprite();
             //childrenSmooth = new Sprite();

             smoothPercentage = 50;
             childrenSmoothPercentage = 50;
          }
          else
          {
             item = itemchildren = parentInstance->itemchildren;
          }
          steps = 100;
          childrenLengthDecay = 0.5;
          addChild(holder);
          initialized = true;
       }

      void getChildrenLengthDecay(float _childrenLengthDecay)
      {
         if(_childrenLengthDecay > 1)
         {
            _childrenLengthDecay = 1;
         }
         else if(_childrenLengthDecay < 0)
         {
            _childrenLengthDecay = 0;
         }

         childrenLengthDecay = _childrenLengthDecay;
      }



      void setChildrenSmoothPercentage(float _childrenSmoothPercentage)
      {
          /*
          glm::mat3x3 _loc2;
          int _loc3_ = 0;

         childrenSmoothPercentage = _childrenSmoothPercentage;

         loc2 = new Matrix();
         loc2.createGradientBox(steps,1);
         loc3 = _childrenSmoothPercentage / 100 * 128;


         childrenSmooth.graphics.clear();
         childrenSmooth.graphics.beginGradientFill("linear",[SMOOTH_COLOR,SMOOTH_COLOR,SMOOTH_COLOR,SMOOTH_COLOR],[1,0,0,1],[0,_loc3_,255 - _loc3_,255],_loc2_);
         childrenSmooth.graphics.drawRect(0,0,steps,1);
         childrenSmooth.graphics.endFill();
         */

      }



      void setWavelength(float _wavelength)
      {
         wavelength = _wavelength;

         for(int i=0;i<childrenArray.size();i++)
         {
             ((Lightning)childrenArray[i]).setWavelength(_wavelength);
         }
      }


      int getChildrenMaxGenerations()
      {
         return childrenMaxGenerations;
      }

      void setChildrenMaxCount(int _childrenMaxCount)
      {
         childrenMaxCount = _childrenMaxCount;
         //killSurplus();
      }

      void setSteps(int __steps)
      {
         if(steps < 2)
         {
             steps = 2;
         }
         if(steps > 2880)
         {
            steps = 2880;
         }
         steps = __steps;
         /*

         sbd = new BitmapData(_steps,1,false);
         bbd = new BitmapData(_steps,1,false);


         if(generation == 0)
         {
            _smoothPercentage = smoothPercentage;
         }
         */
      }
      /*

      float getChildrenAngleVariation()
      {
         return _childrenAngleVariation;
      }



      float getSpeed()
      {
         return _speed;
      }

      float getAmplitude()
      {
         return _amplitude;
      }

      float getChildrenLifeSpanMin()
      {
         return _childrenLifeSpanMin;
      }

      float getChildrenProbabilityDecay()
      {
         return _childrenProbabilityDecay;
      }


     bool getChildrenDetachedEnd()
      {
         return _childrenDetachedEnd;
      }
      float getThicknessDecay()
      {
         return _thicknessDecay;
      }

      float getChildrenMaxCountDecay()
      {
         return _childrenMaxCountDecay;
      }

      float getMaxLengthVary()
      {
         return _maxLengthVary;
      }
      float childrenProbability()
      {
         return _childrenProbability;
      }
      float wavelength()
      {
         return _wavelength;
      }

      int steps()
      {
         return _steps;
      }


      int childrenMaxCount()
      {
         return _childrenMaxCount;
      }

      float childrenSmoothPercentage()
      {
         return _childrenSmoothPercentage;
      }

      float childrenLengthDecay()
      {
         return _childrenLengthDecay;
      }


      float maxLength()
      {
         return _maxLength;
      }


      float smoothPercentage()
      {
         return _smoothPercentage;
      }
      float thickness()
      {
         return _thickness;
      }
      int color()
      {
         return _color;
      }
      float childrenLifeSpanMax()
      {
         return _childrenLifeSpanMax;
      }
      bool isVisible()
      {
         return _isVisible;
      }

      */

      void killAllChildren()
      {
         while(childrenArray.size() > 0)
         {

            //((Lightning)childrenArray[0]) = NULL;

         }
      }


/*


      void setChildrenMaxGenerations(int childrenMaxGenerations)
      {
         _childrenMaxGenerations = childrenMaxGenerations;
         killSurplus();
      }
      */




      void onTimer(QTimerEvent * event)
      {
         kill();
      }

      void generateChild(int param1 = 1, bool param2 = false)
      {
          /*
         int _loc3_ = 0;
         int _loc4_ = 0;
         int _loc5_ = 0;
         int _loc6_ = 0;

         var _loc7_:* = NaN;

         Lightning _loc8_;

         if(generation < _childrenMaxGenerations && childrenArray.size() < childrenMaxCount)
         {
            _loc3_ = steps * childrenLengthDecay;

            if(_loc3_ >= 2)
            {
               _loc4_ = 0;

               while(_loc4_ < param1)
               {
                  _loc5_ = Math.random() * steps;
                  _loc6_ = Math.random() * steps;

                  while(_loc6_ == _loc5_)
                  {
                     _loc6_ = Math.random() * steps;
                  }
                  _loc7_ = Math.random() * childrenAngleVariation - childrenAngleVariation / 2;

                  _loc8_ = new Lightning(color,thickness,generation + 1);

                  _loc8_.parentInstance = this;
                  _loc8_.lifeSpan = Math.random() * (childrenLifeSpanMax - childrenLifeSpanMin) + childrenLifeSpanMin;

                  _loc8_.position = 1 - _loc5_ / steps;
                  _loc8_.absolutePosition = absolutePosition * _loc8_.position;
                  _loc8_.alphaFadeType = alphaFadeType;
                  _loc8_.thicknessFadeType = thicknessFadeType;

                  if(alphaFadeType == LightningFadeType.GENERATION)
                  {
                     _loc8_.alpha = 1 - 1 / (childrenMaxGenerations + 1) * _loc8_.generation;
                  }
                  if(thicknessFadeType == LightningFadeType.GENERATION)
                  {
                     _loc8_.thickness = thickness - thickness / (childrenMaxGenerations + 1) * _loc8_.generation;
                  }
                  _loc8_.childrenMaxGenerations = childrenMaxGenerations;
                  _loc8_.childrenMaxCount = childrenMaxCount * (1 - childrenMaxCountDecay);
                  _loc8_.childrenProbability = childrenProbability * (1 - childrenProbabilityDecay);
                  _loc8_.childrenProbabilityDecay = childrenProbabilityDecay;
                  _loc8_.childrenLengthDecay = childrenLengthDecay;
                  _loc8_.childrenDetachedEnd = childrenDetachedEnd;
                  _loc8_.wavelength = wavelength;
                  _loc8_.amplitude = amplitude;
                  _loc8_.speed = speed;
                  _loc8_.init();
                  childrenArray.push({
                     "instance":_loc8_,
                     "startStep":_loc5_,
                     "endStep":_loc6_,
                     "detachedEnd":childrenDetachedEnd,
                     "childAngle":_loc7_
                  });
                  addChild(_loc8_);
                  _loc8_.steps = steps * (1 - childrenLengthDecay);
                  if(param2)
                  {
                     _loc8_.generateChild(param1,true);
                  }
                  _loc4_++;
               }
            }
         }
         */
      }


      /*

      void killSurplus()
      {
         Lightning _loc1_ = NULL;

         while(childrenArray.length > childrenMaxCount)
         {
            _loc1_ = childrenArray[childrenArray.length - 1].instance;
            _loc1_.kill();
         }
      }
*/


      void setSpeed(float _speed)
      {
         speed = _speed;

         for(int i=0;i<childrenArray.size();i++)
         {
           ((Lightning)childrenArray[i]).speed = _speed;
         }
      }

      QColor color;

      void setSetColor(QColor _color)
      {
         //holder.filters = [glow];

         for(int i=0;i<childrenArray.size();i++)
         {
           ((Lightning)childrenArray[i]).color = _speed;
         }
      }


      void update()
      {

         Lightning _loc2_;
         glm::mat4 _loc3_;



         float _loc1_;
         float _loc4_;

         if(initialized)
         {
            dx = endX - startX;
            dy = endY - startY;

            len = sqrt(dx * dx + dy * dy);

            soffs[0].x = soffs[0].x + steps / 100 * speed;
            soffs[0].y = soffs[0].y + steps / 100 * speed;
            soffs[0].z = soffs[0].z + steps / 100 * speed;

            sbd.perlinNoise(steps / 20,steps / 20,1,seed1,false,true,7,true,soffs);

            calculatedWavelength = steps * wavelength;
            calculatedSpeed = calculatedWavelength * 0.1 * speed;

            boffs[0].x = boffs[0].x - calculatedSpeed;
            boffs[0].y = boffs[0].y + calculatedSpeed;

            bbd.perlinNoise(calculatedWavelength,calculatedWavelength,1,seed2,false,true,7,true,boffs);

            if(smoothPercentage > 0)
            {

               _loc3_.scale(steps / item.width,1);

               bbd.draw(item,_loc3_);
            }
            if(parentInstance != NULL)
            {
               isVisible = parentInstance->isVisible;
            }
            else if(maxLength == 0)
            {
               isVisible = true;
            }
            else
            {
               if(len <= maxLength)
               {
                  _loc4_ = 1;
               }
               else if(len > maxLength + maxLengthVary)
               {
                  _loc4_ = 0;
               }
               else
               {
                  _loc4_ = 1 - (len - maxLength) / maxLengthVary;
               }



               isVisible = Math.random() < _loc4_?true:false;
            }

            _loc1_ = Math.random();



            if(_loc1_ < childrenProbability)
            {
               generateChild();
            }
            if(isVisible)
            {
               render();
            }
            for(int i =0;i<childrenArray.size();i++)
            {
               ((Lightning)childrenArray[i]).update();
            }
         }
      }

      void setChildrenAngleVariation(float _childrenAngleVariation)
      {
         childrenAngleVariation = _childrenAngleVariation;

         for(int i =0;i<childrenArray.size();i++)
         {
            ((Lightning)childrenArray[i]).update();
            ((Lightning)childrenArray[i]).childAngle = Math.random() * childrenAngleVariation - childrenAngleVariation / 2;
            ((Lightning)childrenArray[i]).childrenAngleVariation = childrenAngleVariation;
         }
      }

      void randomizeSeeds()
      {
         seed1 = Math.random() * 100;
         seed2 = Math.random() * 100;
      }

      void setThickness(float _thickness)
      {
         if(_thickness < 0)
         {
            _thickness = 0;
         }
         thickness = _thickness;
      }




      void setMaxLength(float _maxLength)
      {
         maxLength = _maxLength;
      }



      void setAmplitude(float _amplitude)
      {
         amplitude = _amplitude;

         for(int i =0;i<childrenArray.size();i++)
         {
             ((Lightning)childrenArray[i]).amplitude=_amplitude;
         }
      }

/*


      void setChildrenDetachedEnd(bool childrenDetachedEnd)
      {
         _childrenDetachedEnd = childrenDetachedEnd;
      }



      void setChildrenLifeSpanMin(float childrenLifeSpanMin)
      {
         _childrenLifeSpanMin = childrenLifeSpanMin;
      }


      void setChildrenLifeSpanMax(float childrenLifeSpanMax)
      {
         _childrenLifeSpanMax = childrenLifeSpanMax;
      }
      */



      void setThicknessDecay(float _thicknessDecay)
      {
         if(_thicknessDecay > 1)
         {
            _thicknessDecay = 1;
         }
         else if(_thicknessDecay < 0)
         {
            _thicknessDecay = 0;
         }

         thicknessDecay = _thicknessDecay;
      }

      void  setChildrenProbabilityDecay(float _childrenProbabilityDecay)
      {
         if(_childrenProbabilityDecay > 1)
         {
            _childrenProbabilityDecay = 1;
         }
         else if(_childrenProbabilityDecay < 0)
         {
            _childrenProbabilityDecay = 0;
         }

         childrenProbabilityDecay = _childrenProbabilityDecay;
      }



      void startLifeTimer()
      {
         lifeTimer = new Timer(lifeSpan * 1000,1);
         lifeTimer.start();
         lifeTimer.addEventListener(TimerEvent.TIMER,onTimer);
      }



      void kill()
      {
         int  _loc1_ = 0;
         var _loc2_:Lightning = null;
         var _loc3_:Object = null;
         killAllChildren();
         if(lifeTimer)
         {
            lifeTimer.removeEventListener(TimerEvent.TIMER,kill);
            lifeTimer.stop();
         }
         if(parentInstance != null)
         {
            _loc1_ = 0;
            _loc2_ = this.parent as Lightning;
            for each(_loc3_ in _loc2_.childrenArray)
            {
               if(_loc3_.instance == this)
               {
                  _loc2_.childrenArray.splice(_loc1_,1);
               }
               _loc1_++;
            }
         }
         this.parent.removeChild(this);
         delete this[this];
         true;
      }

      void setChildrenMaxCountDecay(float _childrenMaxCountDecay)
      {
         if(_childrenMaxCountDecay > 1)
         {
             _childrenMaxCountDecay = 1;
         }
         else if(_childrenMaxCountDecay < 0)
         {
            _childrenMaxCountDecay = 0;
         }

         childrenMaxCountDecay = _childrenMaxCountDecay;
      }


      void setChildrenProbability(float childrenProbability)
      {
         if(childrenProbability > 1)
         {
            childrenProbability = 1;
         }
         else if(childrenProbability < 0)
         {
            childrenProbability = 0;
         }

         childrenProbability = childrenProbability;
      }



      void setIsVisible(bool _isVisible )
      {
         isVisible = _isVisible ;
      }

      void setMaxLengthVary(float _maxLengthVary)
      {
         maxLengthVary = _maxLengthVary;
      }



      void render()
      {
         var _loc1_:Object = null;

         int  _loc2_ = 0;
         float _loc4_;
         float _loc3_;
         float _loc5_;
         float _loc6_;
         float _loc7_;

         holder.graphics.clear();
         holder.graphics.lineStyle(thickness,_color);
         angle = Math.atan2(endY - startY,endX - startX);
         _loc2_ = 0;

         while(_loc2_ < steps)
         {
            _loc3_ = 1 / steps * (steps - _loc2_);
            _loc4_ = 1;
            _loc5_ = thickness;

            if(alphaFadeType == LightningFadeType.TIP_TO_END)
            {
               _loc4_ = absolutePosition * _loc3_;
            }
            if(thicknessFadeType == LightningFadeType.TIP_TO_END)
            {
               _loc5_ = thickness * absolutePosition * _loc3_;
            }
            if(alphaFadeType == LightningFadeType.TIP_TO_END || thicknessFadeType == LightningFadeType.TIP_TO_END)
            {
               holder.graphics.lineStyle(int(_loc5_),_color,_loc4_);
            }
            soff = (sbd.getPixel(_loc2_,0) - 8421504) / 16777215 * len * multi2;
            soffx = Math.sin(angle) * soff;
            soffy = Math.cos(angle) * soff;
            boff = (bbd.getPixel(_loc2_,0) - 8421504) / 16777215 * len * amplitude;
            boffx = Math.sin(angle) * boff;
            boffy = Math.cos(angle) * boff;
            tx = startX + dx / (steps - 1) * _loc2_ + soffx + boffx;
            ty = startY + dy / (steps - 1) * _loc2_ - soffy - boffy;
            if(_loc2_ == 0)
            {
               holder.graphics.moveTo(tx,ty);
            }
            holder.graphics.lineTo(tx,ty);
            for each(_loc1_ in childrenArray)
            {
               if(_loc1_.startStep == _loc2_)
               {
                  _loc1_.instance.startX = tx;
                  _loc1_.instance.startY = ty;
               }
               if(_loc1_.detachedEnd)
               {
                  _loc6_ = angle + _loc1_.childAngle / 180 * Math.PI;
                  _loc7_ = len * childrenLengthDecay;
                  _loc1_.instance.endX = _loc1_.instance.startX + Math.cos(_loc6_) * _loc7_;
                  _loc1_.instance.endY = _loc1_.instance.startY + Math.sin(_loc6_) * _loc7_;
               }
               else if(_loc1_.endStep == _loc2_)
               {
                  _loc1_.instance.endX = tx;
                  _loc1_.instance.endY = ty;
               }

            }
            _loc2_++;
         }
      }




      void setSmoothPercentage(float _smoothPercentage)
      {
         QMatrix4x4 _loc2_;

         int _loc3_ = 0;

         if(item)
         {
            smoothPercentage = _smoothPercentage;

            //_loc2_ = new Matrix();

            _loc2_.createGradientBox(steps,1);

            _loc3_ = smoothPercentage / 100 * 128;

            /*

            smooth.graphics.clear();
            smooth.graphics.beginGradientFill("linear",[SMOOTH_COLOR,SMOOTH_COLOR,SMOOTH_COLOR,SMOOTH_COLOR],[1,0,0,1],[0,_loc3_,255 - _loc3_,255],_loc2_);
            smooth.graphics.drawRect(0,0,steps,1);
            smooth.graphics.endFill();
            */
         }
      }
   }
}

#endif // LIGHTNING_H
