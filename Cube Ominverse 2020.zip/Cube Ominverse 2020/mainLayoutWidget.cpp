

#include "mainLayoutWidget.h"
#include <curvewidget.h>
#include <curveobject.h>


CubeLayoutWidget::CubeLayoutWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *layout = new QVBoxLayout;//important to fill the contents

    //QSplitter * hsplitter = new QSplitter;
    QSplitter * vsplitter = new QSplitter;

    //QTextEdit * t1 = new QTextEdit;
    //CurveWidget * curveWidget = new CurveWidget;
    //QTextEdit * t2 = new QTextEdit;
    //FCurveWidget *curveWidget = new FCurveWidget(FCurveWidget::ARGBShade,this);
    //QTextEdit * t3 = new QTextEdit;
    //QTextEdit * t4 = new QTextEdit;

    cube3DViewPort = new Cube3DViewPort;


    QTabWidget * uppertabwidget = new QTabWidget;

    uppertabwidget->addTab(cube3DViewPort,QString("3D View"));
    uppertabwidget->addTab(new QTextEdit(),QString("2D View"));

    uppertabwidget->setTabEnabled(1,false);
    vsplitter->setOrientation(Qt::Vertical);
    //hsplitter->setOrientation(Qt::Horizontal);


    //QTabWidget * lowertabwidget = new QTabWidget;


    //hsplitter->addWidget(t1);
    //hsplitter->addWidget(curveWidget);
    //hsplitter->addWidget(t3);

    //lowertabwidget->addTab(t4,QString("Material Node Editor"));
    //lowertabwidget->addTab(hsplitter,QString("Curve Editor"));

    vsplitter->addWidget(uppertabwidget);
    //vsplitter->addWidget(lowertabwidget);
    layout->addWidget(vsplitter);

    setLayout(layout);

}
