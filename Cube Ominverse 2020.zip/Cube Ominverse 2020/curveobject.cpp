#include "curveobject.h"
#include <algorithm>

CurveObject::CurveObject(QWidget *_widget, PointShape shape) : QObject(_widget)
{
    m_widget = _widget;

    _widget->installEventFilter(this);
    _widget->setAttribute(Qt::WA_AcceptTouchEvents);

    m_connectionType = CurveConnection;
    m_sortType = NoSort;
    m_shape = shape;

    m_pointPen      = QPen(QColor(255, 255, 255, 191), 1);
    m_connectionPen = QPen(QColor(255, 255, 255, 127), 2);
    m_pointBrush    = QBrush(QColor(191, 191, 191, 127));
    m_pointSize     = QSize(11, 11);

    m_currentIndex  = -1;
    m_editable = true;
    m_enabled  = true;

    connect(this, SIGNAL(pointsChanged(QPolygonF)),m_widget, SLOT(update()));
}


void CurveObject::setEnabled(bool enabled)
{
    if (m_enabled != enabled)
    {
        m_enabled = enabled;

        m_widget->update();
    }
}


bool CurveObject::eventFilter(QObject *object, QEvent *event)
{
    if (object == m_widget && m_enabled)
    {
        switch (event->type())
        {

            case QEvent::MouseButtonPress:
            {
                if (!m_fingerPointMapping.isEmpty())
                    return true;

                QMouseEvent *me = (QMouseEvent *) event;

                QPointF clickPos = me->pos();

                int index = -1;

                for (int i=0; i<m_points.size(); ++i)
                {
                    QPainterPath path;

                    if (m_shape == CircleShape)
                        path.addEllipse(pointBoundingRect(i));
                    else
                        path.addRect(pointBoundingRect(i));

                    if (path.contains(clickPos))
                    {
                        index = i;
                        break;
                    }
                }

                if (me->button() == Qt::LeftButton)
                {
                    if (index == -1)
                    {
                        if (!m_editable)
                            return false;

                        int pos = 0;
                        // Insert sort for x or y
                        if (m_sortType == XSort)
                        {
                            for (int i=0; i<m_points.size(); ++i)
                            {
                                if (m_points.at(i).x() > clickPos.x())
                                {
                                    pos = i;
                                    break;
                                }
                            }
                        } else if (m_sortType == YSort)
                        {
                            for (int i=0; i<m_points.size(); ++i)
                            {
                                if (m_points.at(i).y() > clickPos.y())
                                {
                                    pos = i;
                                    break;
                                }
                            }
                        }

                        m_points.insert(pos, clickPos);
                        m_locks.insert(pos, 0);
                        m_currentIndex = pos;
                        emitPointChange();
                    }
                    else
                    {
                        m_currentIndex = index;
                    }
                    return true;

                }
                else if (me->button() == Qt::RightButton)
                {
                    if (index >= 0 && m_editable)
                    {
                        if (m_locks[index] == 0)
                        {
                            m_locks.remove(index);
                            m_points.remove(index);
                        }
                        emitPointChange();
                        return true;
                    }
                }

            }
            break;

            case QEvent::MouseButtonRelease:
                if (!m_fingerPointMapping.isEmpty())
                    return true;
                m_currentIndex = -1;
                break;

            case QEvent::MouseMove:
                if (!m_fingerPointMapping.isEmpty())
                    return true;
                if (m_currentIndex >= 0)
                    movePoint(m_currentIndex, ((QMouseEvent *)event)->pos());
                break;

            case QEvent::Resize:
            {

                QResizeEvent *e = (QResizeEvent *) event;


                if (e->oldSize().width() == 0 || e->oldSize().height() == 0)
                    break;

                qreal stretch_x = e->size().width() / qreal(e->oldSize().width());
                qreal stretch_y = e->size().height() / qreal(e->oldSize().height());

                for (int i=0; i<m_points.size(); ++i)
                {
                    QPointF p = m_points[i];
                    movePoint(i, QPointF(p.x() * stretch_x, p.y() * stretch_y), false);
                }

                emitPointChange();
                break;
            }

            case QEvent::Paint:
            {
                QWidget *that_widget = m_widget;

                m_widget = 0;

                QApplication::sendEvent(object, event);

                m_widget = that_widget;

                paintPoints();

                return true;
            }
            default:
                break;
            }
    }

    return false;
}


void CurveObject::paintPoints()
{
    QPainter p;

    p.begin(m_widget);

    p.setRenderHint(QPainter::Antialiasing);

    if (m_connectionPen.style() != Qt::NoPen && m_connectionType != NoConnection)
    {
        p.setPen(m_connectionPen);

        if (m_connectionType == CurveConnection)
        {
            QPainterPath path;

            path.moveTo(m_points.at(0));

            for (int i=1; i<m_points.size(); ++i)
            {
                QPointF p1 = m_points.at(i-1);
                QPointF p2 = m_points.at(i);

                qreal distance = p2.x() - p1.x();

                path.cubicTo(p1.x() + distance / 2, p1.y(),
                             p1.x() + distance / 2, p2.y(),
                             p2.x(), p2.y());
            }
            p.drawPath(path);
        }
        else
        {
            p.drawPolyline(m_points);
        }
    }

    p.setPen(m_pointPen);
    p.setBrush(m_pointBrush);

    for (int i=0; i<m_points.size(); ++i)
    {
        QRectF bounds = pointBoundingRect(i);

        if (m_shape == CircleShape)
            p.drawEllipse(bounds);
        else
            p.drawRect(bounds);
    }
}

static QPointF bound_point(const QPointF &point, const QRectF &bounds, int lock)
{
    QPointF p = point;

    qreal left = bounds.left();
    qreal right = bounds.right();
    qreal top = bounds.top();
    qreal bottom = bounds.bottom();

    if (p.x() < left || (lock & CurveObject::LockToLeft)) p.setX(left);
    else if (p.x() > right || (lock & CurveObject::LockToRight)) p.setX(right);

    if (p.y() < top || (lock & CurveObject::LockToTop)) p.setY(top);
    else if (p.y() > bottom || (lock & CurveObject::LockToBottom)) p.setY(bottom);

    return p;
}

void CurveObject::setPoints(const QPolygonF &points)
{
    if (points.size() != m_points.size())
        m_fingerPointMapping.clear();


    m_points.clear();

    for (int i=0; i<points.size(); ++i)
        m_points << bound_point(points.at(i), boundingRect(), 0);

    m_locks.clear();

    if (m_points.size() > 0)
    {
        m_locks.resize(m_points.size());

        m_locks.fill(0);
    }
}


void CurveObject::movePoint(int index, const QPointF &point, bool emitUpdate)
{
    m_points[index] = bound_point(point, boundingRect(), m_locks.at(index));

    if (emitUpdate)
        emitPointChange();
}


inline static bool x_less_than(const QPointF &p1, const QPointF &p2)
{
    return p1.x() < p2.x();
}


inline static bool y_less_than(const QPointF &p1, const QPointF &p2)
{
    return p1.y() < p2.y();
}

void CurveObject::emitPointChange()
{


    if (m_sortType != NoSort)
    {
        QPointF oldCurrent;

        if (m_currentIndex != -1)
        {
            oldCurrent = m_points[m_currentIndex];
        }

        if (m_sortType == XSort)
            std::sort(m_points.begin(), m_points.end(), x_less_than);
        else if (m_sortType == YSort)
            std::sort(m_points.begin(), m_points.end(), y_less_than);

        // Compensate for changed order...
        if (m_currentIndex != -1)
        {
            for (int i=0; i<m_points.size(); ++i)
            {
                if (m_points[i] == oldCurrent)
                {
                    m_currentIndex = i;
                    break;
                }
            }
        }


    }

    emit pointsChanged(m_points);
}






FCurveWidget::FCurveWidget(ShadeType type, QWidget *parent=0)
    : QWidget(parent), m_shade_type(type), m_alpha_gradient(QLinearGradient(0, 0, 0, 0))
{

    // Checkers background
    if (m_shade_type == ARGBShade)
    {
        QPixmap pm(20, 20);
        QPainter pmp(&pm);
        pmp.fillRect(0, 0, 10, 10, Qt::lightGray);
        pmp.fillRect(10, 10, 10, 10, Qt::lightGray);
        pmp.fillRect(0, 10, 10, 10, Qt::darkGray);
        pmp.fillRect(10, 0, 10, 10, Qt::darkGray);
        pmp.end();
        QPalette pal = palette();
        pal.setBrush(backgroundRole(), QBrush(pm));
        setAutoFillBackground(true);
        setPalette(pal);

    } else {
        setAttribute(Qt::WA_NoBackground);
    }

    QPolygonF points;
    points << QPointF(0, sizeHint().height())
           << QPointF(sizeHint().width(), 0);

    curveObject = new CurveObject(this, CurveObject::CircleShape);
//     m_hoverPoints->setConnectionType(HoverPoints::LineConnection);
    curveObject->setPoints(points);
    curveObject->setPointLock(0, CurveObject::LockToLeft);
    curveObject->setPointLock(1, CurveObject::LockToRight);
    curveObject->setSortType(CurveObject::XSort);

    setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);

    connect(curveObject, SIGNAL(pointsChanged(QPolygonF)), this, SIGNAL(colorsChanged()));
}

QPolygonF FCurveWidget::getPoints() const
{
    return curveObject->getPoints();
}

uint FCurveWidget::colorAt(int x)
{
    generateShade();

    QPolygonF pts = curveObject->getPoints();

    for (int i=1; i < pts.size(); ++i)
    {
        if (pts.at(i-1).x() <= x && pts.at(i).x() >= x)
        {
            QLineF l(pts.at(i-1), pts.at(i));
            l.setLength(l.length() * ((x - l.x1()) / l.dx()));
            return m_shade.pixel(qRound(qMin(l.x2(), (qreal(m_shade.width() - 1)))),
                                 qRound(qMin(l.y2(), qreal(m_shade.height() - 1))));
        }
    }
    return 0;
}

void FCurveWidget::setGradientStops(const QGradientStops &stops)
{
    if (m_shade_type == ARGBShade)
    {
        m_alpha_gradient = QLinearGradient(0, 0, width(), 0);

        for (int i=0; i<stops.size(); ++i)
        {
            QColor c = stops.at(i).second;
            m_alpha_gradient.setColorAt(stops.at(i).first, QColor(c.red(), c.green(), c.blue()));
        }

        m_shade = QImage();
        generateShade();
        update();
    }
}

void FCurveWidget::paintEvent(QPaintEvent *)
{

    ///generateShade();

    QPainter p(this);
    ///p.drawImage(0, 0, m_shade);

    p.setPen(QColor(146, 146, 146));
    p.drawRect(0, 0, width() - 1, height() - 1);
}

void FCurveWidget::generateShade()
{
    if (m_shade.isNull() || m_shade.size() != size())
    {

        if (m_shade_type == ARGBShade)
        {
            m_shade = QImage(size(), QImage::Format_ARGB32_Premultiplied);
            m_shade.fill(0);

            QPainter p(&m_shade);
            p.fillRect(rect(), m_alpha_gradient);

            p.setCompositionMode(QPainter::CompositionMode_DestinationIn);
            QLinearGradient fade(0, 0, 0, height());
            fade.setColorAt(0, QColor(0, 0, 0, 255));
            fade.setColorAt(1, QColor(0, 0, 0, 0));
            p.fillRect(rect(), fade);

        }
        else
        {
            m_shade = QImage(size(), QImage::Format_RGB32);
            QLinearGradient shade(0, 0, 0, height());
            shade.setColorAt(1, Qt::black);

            if (m_shade_type == RedShade)
                shade.setColorAt(0, Qt::red);
            else if (m_shade_type == GreenShade)
                shade.setColorAt(0, Qt::green);
            else
                shade.setColorAt(0, Qt::blue);

            QPainter p(&m_shade);
            p.fillRect(rect(), shade);
        }
    }
}



