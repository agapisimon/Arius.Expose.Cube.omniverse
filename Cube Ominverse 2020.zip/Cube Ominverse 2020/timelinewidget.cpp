
#include "timelinewidget.h"

TimeLineFrame::TimeLineFrame(QFrame *parent) : QFrame(parent)
{

    init();

}

