#include "cube.h"

CUBE::CUBE()
{

}

