#ifndef TOOLSWIDGET_H
#define TOOLSWIDGET_H
#include<QtWidgets>
#include<QWidget>


class ToolsWidget : public QWidget
{
    QStringList primitiveslist;
    QStringList cameralist;
    QStringList helperlist;
    QStringList lightlist;
    QStringList curveslist;
    QStringList surfacelist;


    Q_OBJECT
public:

    QList<QStandardItemModel*> models;

    explicit ToolsWidget(QWidget *parent = 0);

    void initStringList()
    {

        primitiveslist.append(QString("Cube"));
        primitiveslist.append(QString("Sphere"));
        primitiveslist.append(QString("Torus"));
        primitiveslist.append(QString("Capsule"));
        primitiveslist.append(QString("Plane"));
        primitiveslist.append(QString("Container"));
        primitiveslist.append(QString("Cone"));
        primitiveslist.append(QString("Pyramid"));
        primitiveslist.append(QString("Cylinder"));
        primitiveslist.append(QString("Tube"));
        primitiveslist.append(QString("Platonic"));
        primitiveslist.append(QString("Lego"));
        primitiveslist.append(QString("Dull"));

        cameralist.append(QString("Perspective Camera"));
        cameralist.append(QString("Ortho"));
        cameralist.append(QString("Camera"));

        helperlist.append(QString("Point"));
        helperlist.append(QString("Cross"));
        helperlist.append(QString("Cube"));
        helperlist.append(QString("Sphere"));
        helperlist.append(QString("Circle"));
        helperlist.append(QString("Mover"));
        helperlist.append(QString("Text"));
        helperlist.append(QString("Svg"));

        lightlist.append(QString("sun"));
        lightlist.append(QString("Rect"));
        lightlist.append(QString("Point"));
        lightlist.append(QString("Sphere"));
        lightlist.append(QString("Infinite"));
        lightlist.append(QString("Object"));
        lightlist.append(QString("Spot"));

        curveslist.append(QString("Bezier"));
        curveslist.append(QString("Rect"));
        curveslist.append(QString("Circle"));
        curveslist.append(QString("Text"));
        curveslist.append(QString("Pie"));
        curveslist.append(QString("Spiral"));
        curveslist.append(QString("Coil"));
        curveslist.append(QString("L-Junction"));

        surfacelist.append(QString("Bezier"));
        surfacelist.append(QString("Rect"));
        surfacelist.append(QString("Circle"));
        surfacelist.append(QString("Text"));



    }

    void initUI()
    {
        initStringList();

        /*
        QTreeWidget * widgetQToolBox =  new QTreeWidget;
        widgetQToolBox->addTopLevelItem(new QTreeWidgetItem());
        */


        QToolBox *widgetQToolBox     = new QToolBox;
        QTextEdit *textEditQTextEdit = new QTextEdit;

        QListView *listPrimitivesQListView = new QListView;
        QListView *listCamerasQListView = new QListView;
        QListView *listHelpersQListView = new QListView;
        QListView*listLightsQListView   = new QListView;
        QListView *listCurvesQListView  = new QListView;
        QListView *listSurfacesQListView = new QListView;

        populateQListView(listPrimitivesQListView,primitiveslist);
        populateQListView(listCamerasQListView, cameralist);
        populateQListView(listHelpersQListView, helperlist);
        populateQListView(listLightsQListView, lightlist);
        populateQListView(listCurvesQListView, curveslist);
        populateQListView(listSurfacesQListView, surfacelist);


        widgetQToolBox->addItem(listPrimitivesQListView, "Primitives");
        widgetQToolBox->addItem(listCamerasQListView, "Cameras");
        widgetQToolBox->addItem(listHelpersQListView, "Helpers");
        widgetQToolBox->addItem(listLightsQListView, "Lights");
        widgetQToolBox->addItem(listCurvesQListView, "Curves");
        widgetQToolBox->addItem(listSurfacesQListView, "Surfaces");
        widgetQToolBox->addItem(textEditQTextEdit, "ScriptCommand");

        QVBoxLayout * layout = new QVBoxLayout;

        layout->addWidget(widgetQToolBox);

        setLayout(layout);
    }


    void populateQListView(QListView *list, QStringList dataList)
    {
        QIcon icon(":/mainicon.svg");

        // Create an empty model for the list's data
        QStandardItemModel *model = new QStandardItemModel;

        models.append(model);

        //Add some textual items
        for(int i =0;i<dataList.length();i++)
        {
           //create an item with a caption
           QStandardItem *item = new QStandardItem(dataList[i]);

           item->setIcon(icon);

           //Add the item to the model
           model->appendRow(item);
        }

        list->setViewMode(QListView::IconMode);

        //Apply the model to the list view
        list->setModel(model);
    }



signals:

public slots:
};


#endif // TOOLSWIDGET_H
