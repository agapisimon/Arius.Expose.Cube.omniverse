

#ifndef MYGLWIDGET_H
#define MYGLWIDGET_H


#include<QtWidgets>
#include<QGLWidget>
#include<QtOpenGL>

#include<core/mesh.h>
#include<core/camera.h>
#include<core/light.h>
#include<core/importobj.h>
#include<core/selection.h>

class Cube3DViewPort : public QGLWidget
{
    Q_OBJECT
private:
    QPoint lastPos;
public:

    CameraOrtho camera3d;    
    MeshOGL meshogl;
    Light light;
    Text3D txt3d;
    QToolBar toolbar;

    enum DRAWMODE
    {
        FILL,
        WIRE,
        BACKFACE,
    };


public:
    Cube3DViewPort(QGLWidget  *parent = 0);
    ~Cube3DViewPort();

signals:
public slots:

protected:
    void initializeGL();
    void paintGL();
    //void paintEvent(QPaintEvent * event);
    void resizeGL(int width, int height);
    QSize minimumSizeHint() const;
    QSize sizeHint() const;
    void mouseReleaseEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mouseDoubleClickEvent(QMouseEvent *event);
    void keyPressEvent(QKeyEvent * event);
    void wheelEvent(QWheelEvent *event);

    void importFiles();
    void drawLoop();

    void drawAllViews(int width,int height  );

    bool zooming;
    bool iswireframe = false;

    qreal c  = (qreal)76/255;
    qreal c1 = (qreal)199/255;


public slots:
signals:   
private:    

};

#endif // MYGLWIDGET_H

