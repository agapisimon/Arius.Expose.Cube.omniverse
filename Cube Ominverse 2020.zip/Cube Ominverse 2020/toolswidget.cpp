#include "toolswidget.h"

ToolsWidget::ToolsWidget(QWidget *parent) : QWidget(parent)
{
    initUI();
}

