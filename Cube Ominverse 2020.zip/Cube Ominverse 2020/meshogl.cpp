#include "meshogl.h"
/*
MeshOGL::MeshOGL()
{

}

*/
