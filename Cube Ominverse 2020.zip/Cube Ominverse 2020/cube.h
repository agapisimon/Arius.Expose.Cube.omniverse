#ifndef CUBE_H
#define CUBE_H


class CUBE
{
public:
    CUBE();
};

#endif // CUBE_H
