#ifndef TIMELINEWIDGET_H
#define TIMELINEWIDGET_H
#include<QtWidgets>
#include<QWidget>
#include<QTimer>


class TimeLineFrame : public QFrame
{
    int startFrame;
    int currentFrame;
    int endFrame;

    int numberOFFrames;

    int fps;
    int step;

    bool isRealtime;
    bool isplaying;

    int ticks;


    QTimer timer;

    QPoint indexPos;


    Q_OBJECT
public:
    explicit TimeLineFrame(QFrame *parent = 0);

    enum FRAMERATES
    {
        FPS_25,
        FPS_30,
        FPS_60,
        FPS_REALTIME,
        FPS_CUSTOMN,
    };

    void init()
    {
        indexPos = QPoint(0,0);

        ticks = 1000;

        timer.start(ticks);

        startFrame = 0;
        currentFrame = 0;
        endFrame = 500;
        numberOFFrames = endFrame - startFrame;

        fps = 25;
        step = 1;

        isRealtime = false;
        isplaying = false;

        setMinimumSize(1, 30);
    }

    void setFrame( int Frame)
    {
        if(Frame<0)
            Frame = 0;
        else
            currentFrame = Frame;
    }

    void setTotalFrameRange( int total)
    {
        if(total<0)
            total =0;

        numberOFFrames = total;
        startFrame = 0;
        endFrame = numberOFFrames;
    }
    /*

    void setFrameRange( int range)
    {
        if(range<0)
            range =0;



        currentFrame = Frame;

    }
    */

    int getCurrentFrame()
    {
        return currentFrame;
    }

    void play()
    {
        currentFrame += 1;
    }

    void stop()
    {

    }

    void stepForward()
    {
        currentFrame += 1;
    }

    void stepBackward()
    {
        currentFrame -= 1;
    }

    void gotoEndFrame()
    {
        currentFrame = endFrame;
    }

    void goToStartFrame()
    {
        currentFrame = startFrame;
    }

    void paintEvent( QPaintEvent * event)
    {
        QPainter *painter = new QPainter;
        painter->begin(this);

        drawIndexMarker();
        drawWidget();
        painter->end();
    }

    void drawIndexMarker()
    {
        QPainter p(this);
        QFont f( "Courier", 10, QFont::Normal );

        p.setFont(f);
        p.setPen(Qt::cyan);
        p.setBrush(QBrush(QColor(Qt::cyan)));

        QRect indexRect(0,0,2,rect().height());
        indexRect.moveTo(QPoint(indexPos.x(),0));
        p.drawRect(indexRect);

        QString fstr = QString(" frame:")+QString::number(indexPos.x());
        p.drawText(indexPos.x(),rect().height()/2,fstr);

    }

    void drawWidget()
    {
        QPainter p(this);
        p.setPen(Qt::black);

        QFont f( "Courier", 8, QFont::Normal );
        p.setFont(f);
        int j=0,i;

        for(i=0;i<=numberOFFrames;i+=50)
        {
           float dx = width()* i/numberOFFrames+x();
           p.drawLine(dx,0,dx,6);

           for(;j<i;j+=5)
           {
              float ddx = width()* j/numberOFFrames+x();
              p.drawLine(ddx,height(),ddx,height()-4);
           }

           p.setPen(Qt::black);
           p.drawText(dx,height()-10,QString::number(i));
        }
    }

    void mousePressEvent(QMouseEvent *event)
    {
        if(event->buttons() & Qt::LeftButton)
        {
            indexPos =  event->pos();
        }
        update();

    }

    void wheelEvent(QWheelEvent * event)
    {
        qDebug()<<event->delta();
        update();

    }

    void mouseMoveEvent(QMouseEvent *event)
    {

        if(event->buttons() & Qt::LeftButton)
        {
            indexPos =  event->pos();
        }

        update();
    }

    void timerEvent(QTimerEvent *event)
    {
        update();

    }

signals:

public slots:
};


class TimeLineWidget : public QWidget
{
    TimeLineFrame *timelineframe;
    QTimeLine timeline;
public:
    TimeLineWidget (QWidget *parent=0) : QWidget(parent)
    {
        timelineframe=new TimeLineFrame;

        QVBoxLayout *vlayout = new QVBoxLayout;
        QHBoxLayout *layout = new QHBoxLayout;

        QComboBox * cbox = new  QComboBox;

        cbox->addItem(QString(" 25"));
        cbox->addItem(QString(" 30"));
        cbox->addItem(QString(" 60"));
        cbox->addItem(QString(" 5"));
        cbox->addItem(QString(" User"));
        cbox->setMinimumWidth(50);

        layout->addWidget(new QLabel(QString("   Play Back:")));


        layout->addWidget(new QPushButton(QString("|<")));
        layout->addWidget(new QPushButton(QString(" > ")));
        layout->addWidget(new QPushButton(QString("||")));
        layout->addWidget(new QPushButton(QString(">|")));
        layout->addWidget(new QPushButton(QString("|0|")));

        layout->addWidget(new QLabel(QString("   Start Frame:")));
        layout->addWidget(new QLineEdit());

        layout->addWidget(new QLabel(QString("   End Frame:")));
        layout->addWidget(new QLineEdit());

        layout->addWidget(new QLabel(QString("   Current Frame:")));
        layout->addWidget(new QLineEdit());

        layout->addWidget(new QLabel(QString("   Frames Per Second:")));
        layout->addWidget(cbox);
        layout->addWidget(new QLineEdit());

        layout->addWidget(new QLabel(QString("   Total Frames:")));
        layout->addWidget(new QLineEdit());

        layout->addWidget(new QLabel(QString("   Real Time:")));
        layout->addWidget(new QRadioButton());

        layout->addWidget(new QLabel(QString("   Hide Keys:")));
        layout->addWidget(new QRadioButton());


        vlayout->addWidget(timelineframe);
        vlayout->addLayout(layout);


        setLayout(vlayout);
    }

};




#endif // TIMELINEWIDGET_H


