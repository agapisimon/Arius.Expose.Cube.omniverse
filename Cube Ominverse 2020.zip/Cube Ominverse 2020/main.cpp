

#include<Qt>
#include<QtCore>
#include <cubemainwindow.h>


int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    app.setAttribute( Qt::AA_UseDesktopOpenGL );


    qDebug()<<"Cube Loading";

    QFile file(":/glowBlue.stylesheet");
    //QFile file(":/cubeomniverse black.stylesheet");

    if(file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
       app.setStyleSheet(file.readAll());
       file.close();
    }

    QIcon icon(":/mainicon.png");

    CubeMainWindow * main = new CubeMainWindow;

    app.setActiveWindow(main);

    return app.exec();   
}
