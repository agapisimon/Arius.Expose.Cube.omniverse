#include "curvewidget.h"

CurveWidget::CurveWidget(QWidget *parent) : QWidget(parent)
{
    initUI();
}

