#ifndef SAVELAYOUTWIDGET_H
#define SAVELAYOUTWIDGET_H
#include<QtWidgets>
#include <QWidget>

class SaveLayoutWidget : public QWidget
{
    Q_OBJECT
public:
    explicit SaveLayoutWidget(QWidget *parent = 0);

signals:

public slots:
};

#endif // SAVELAYOUTWIDGET_H
