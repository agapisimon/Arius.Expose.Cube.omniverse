#include "cubemainwindow.h"
#include<mainLayoutWidget.h>

CubeMainWindow::CubeMainWindow(QWidget *parent) : QMainWindow(parent)
{
    this->resize(768,458);

    CubeLayoutWidget *CubeWidget = new CubeLayoutWidget;

    this->setCentralWidget(CubeWidget);
    this->iniUI();
    //add some dock widgets;

    this->centralWidget()->releaseKeyboard();

}

