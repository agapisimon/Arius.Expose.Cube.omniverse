
#include "propertieswidget.h"

PropertiesWidget::PropertiesWidget(QWidget *parent) : QWidget(parent)
{
    treewidget = new QTreeWidget(this);
    treewidget->grabKeyboard();

    QStringList panes;

    panes.append(QString("Vector Combine"));
    panes.append(QString("Vector Normalize"));
    panes.append(QString("Vector Cross"));
    panes.append(QString("Vector Dot"));

    QStringList combinevector;

    combinevector.append(QString("x"));
    combinevector.append(QString("y"));
    combinevector.append(QString("z"));
    combinevector.append(QString("w"));

    treewidget->setColumnCount(1);
    treewidget->setHeaderLabel("Properties Editor");
    treewidget->grabKeyboard();

    QVBoxLayout * mainlayout = new QVBoxLayout;

    for(int i=0;i<panes.length();i++)
    {
       QTreeWidgetItem * item = new QTreeWidgetItem(treewidget);
       item->setText(0, panes[i]);

       QTreeWidgetItem *child = new QTreeWidgetItem(item);
       child->setText(0, combinevector[0]);

       QSplitter *split = new QSplitter;

       split->setOrientation(Qt::Horizontal);
       QFrame *frame = new QFrame;

       QFormLayout *layout = new QFormLayout;

       layout->addRow(new QLabel("     x:"),new QSlider(Qt::Horizontal));
       layout->addRow(new QLabel("     y:"), new QSlider(Qt::Horizontal));
       //layout->addRow(QLabel("     z:"), SpinBoxSlider());

       QLineEdit *e = new  QLineEdit;
       e->setValidator( new QDoubleValidator(0, 20, 2, this) );
       e->setDisabled(false);
       e->setAttribute(Qt::WA_MacShowFocusRect,1);
       e->setText("Example");
       //e->grabKeyboard();


       layout->addRow(new QLabel("Line 1:"),e);
       layout->addRow(new QLabel("Line 2:"),new QComboBox());
       layout->addRow(new QLabel("Line 3:"),new QSpinBox());
       layout->addRow(new QLabel("Comments:"),new QTextEdit());


       frame->setLayout(layout);
       split->addWidget(frame);

       treewidget->setItemWidget(child, 0, split);
    }

    mainlayout->addWidget(treewidget);

    this->setLayout(mainlayout);

}

