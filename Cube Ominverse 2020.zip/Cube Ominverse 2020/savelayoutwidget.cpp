#include "savelayoutwidget.h"

SaveLayoutWidget::SaveLayoutWidget(QWidget *parent) : QWidget(parent)
{

}

