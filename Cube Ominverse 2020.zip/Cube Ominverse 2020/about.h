
#ifndef ABOUT_H
#define ABOUT_H
#include<QtWidgets>
#include <QWidget>

class About : public QWidget
{
    Q_OBJECT
public:
    About(QWidget *parent = 0);

    void paintEvent(QPaintEvent *event)
    {
        QPainter *painter = new QPainter;
        painter->begin(this);
        drawSplash();
        painter->end();
    }

    void mousePressEvent(QMouseEvent * event)
    {
        if(event->buttons()&Qt::RightButton)
        {
            this->hide();
        }
    }

    void drawSplash()
    {
        QPainter p(this);
        QFont f( "Courier", 10, QFont::Normal );
        p.setFont(f);

       //p.setBrush(QBrush(QColor(Qt::black)));
        p.drawRect(rect());

        QPoint co(50,50);

        //p.setPen(Qt::cyan);
        p.setPen(QColor(128,128,128));

        QString fstr = QString("Developer: Agapi Simon");
        p.drawText(co,fstr);
        co += QPoint(0,20);

        QString appstr = QString("Application: Cube Omniverse");
        p.drawText(co,appstr);
        co += QPoint(0,20);

        QString strVersion = QString("Version: 0.5");
        p.drawText(co,strVersion);
        co += QPoint(0,20);

        QString copystr = QString("Copyright © Agapi Simon:")+QString::number(2015);
        p.drawText(co,copystr);
        co += QPoint(0,20);

        QString emailstr = QString("Email: mittisimone@gmail.com");
        p.drawText(co,emailstr);
        co += QPoint(0,20);

        //QPixmap map(":/cubeomniverse.svg");
        QPixmap map(":/cubeomniverse.png");
        p.drawPixmap(co,map);

        /*

        QString disclaimer = " COPYRIGHT NOTICE \n\

         "Copyright © 2015  AGAPI SIMON COMPANY INC\n\")

         "Email: mittisimone@gmail.com"

          co += QPoint(0,50);
          p.drawText(co,disclaimer);

        */


    }


public slots:
    void closeAbout()
    {
        this->showNormal();
    }
};

#endif // ABOUT_H
