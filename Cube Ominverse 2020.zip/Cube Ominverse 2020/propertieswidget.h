#ifndef PROPERTIESWIDGET_H
#define PROPERTIESWIDGET_H

#include<QtWidgets>
#include<QWidget>
#include<QTreeWidget>


class PropertiesWidget : public QWidget
{
    Q_OBJECT
public:
    explicit PropertiesWidget(QWidget *parent = 0);

    QTreeWidget *treewidget;



signals:

public slots:
};







#endif // PROPERTIESWIDGET_H
