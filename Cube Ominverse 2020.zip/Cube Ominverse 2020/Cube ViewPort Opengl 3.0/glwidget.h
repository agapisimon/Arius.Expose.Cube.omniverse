

#ifndef MYGLWIDGET_H
#define MYGLWIDGET_H

#include <QtWidgets>


///////////required in this order//////////////
#include <QGLWidget>
#include <QtOpenGL>
//#include <QOpenGLFunctions_1_0>
#include <QOpenGLFunctions_3_0>


//#include <QOpenGLWidget>
////////////////////////
///brief The MyGLWidget class



class Cube3DViewPort : public QGLWidget,QOpenGLFunctions_3_0
{
    Q_OBJECT
public:
    Cube3DViewPort(QGLWidget *parent = 0);
    ~Cube3DViewPort();
signals:

public slots:

protected:
    void initializeGL();
    void paintGL();
    void resizeGL(int width, int height);

    QSize minimumSizeHint() const;
    QSize sizeHint() const;
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);

public slots:
    // slots for xyz-rotation slider
    void setXRotation(int angle);
    void setYRotation(int angle);
    void setZRotation(int angle);

signals:
    // signaling rotation from mouse movement
    void xRotationChanged(int angle);
    void yRotationChanged(int angle);
    void zRotationChanged(int angle);

private:
    void draw();

    int xRot;
    int yRot;
    int zRot;

    QPoint lastPos;
};

#endif // MYGLWIDGET_H

