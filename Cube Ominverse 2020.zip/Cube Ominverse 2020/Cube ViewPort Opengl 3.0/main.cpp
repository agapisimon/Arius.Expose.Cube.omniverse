// main.cpp

//#include <QApplication>
//#include <QDesktopWidget>

//#include "window.h"

#include<QtWidgets>
#include <QApplication>
#include<glwidget.h>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    /*

    QSurfaceFormat format;
    format.setDepthBufferSize(24);
    format.setStencilBufferSize(8);
    //format.setVersion(3, 2);
    format.setVersion(3, 0);
    format.setProfile(QSurfaceFormat::CoreProfile);
    QSurfaceFormat::setDefaultFormat(format);//works for QOPenGLWidget

    */


    Cube3DViewPort w;

    w.setFormat(QGLFormat(QGL::DoubleBuffer));

    w.showMaximized();

    return app.exec();
}
