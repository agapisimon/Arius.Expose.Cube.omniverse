#include "about.h"

About::About(QWidget *parent) : QWidget(parent)
{
   setFixedSize(900,450);

   setWindowTitle(QString("About Cube OmniVerse"));
   setWindowIcon(QIcon(":/mainicon.svg"));

   QVBoxLayout * l = new QVBoxLayout;

   QLineEdit * w = new QLineEdit(this);
   //w->setFocus();
   w->setFocus(Qt::OtherFocusReason);
   l->addWidget(w);
   setLayout(l);

   //setContentsMargins(50,50,50,50);

}

