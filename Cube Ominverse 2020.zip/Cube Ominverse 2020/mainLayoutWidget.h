#ifndef CUBELAYOUTWIDGET_H
#define CUBELAYOUTWIDGET_H
#include<QtWidgets>
#include <glwidget.h>
#include <QWidget>

class CubeLayoutWidget : public QWidget
{

public:
    CubeLayoutWidget(QWidget *parent = 0);
    Cube3DViewPort *cube3DViewPort;
};

#endif // CUBELAYOUTWIDGET_H
