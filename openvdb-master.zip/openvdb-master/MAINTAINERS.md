<!-- SPDX-License-Identifier: CC-BY-4.0 -->
<!-- Copyright Contributors to the OpenVDB project. -->

# OpenVDB Committers

The current OpenVDB maintainers are:


| Name           | Email |
| -------------- | -----------------
| Jeff Lait | jlait@sidefx.com
| Dan Bailey | danbailey@ilm.com
| Nick Avramoussis | nna@dneg.com
| Ken Museth | ken.museth@gmail.com
| Peter Cucka | peter.cucka@dreamworks.com
