<!-- SPDX-License-Identifier: CC-BY-4.0 -->
<!-- Copyright Contributors to the OpenVDB Project. -->

Corporate Contributor License Agreement ("Agreement")

Thank you for your interest in the OpenVDB Project a Series of LF Projects, LLC (hereinafter "Project") which has selected the Mozilla Public License Version 2.0 (hereinafter "MPL-2.0") license for its inbound contributions. The terms You, Contributor and Contribution are used here as defined in the MPL-2.0 license.

The Project is required to have a Contributor License Agreement (CLA) on file that binds each Contributor.

You agree that all Contributions to the Project made by You or by Your designated employees shall be submitted pursuant to the Developer Certificate of Origin Version (DCO, current version available at https://developercertificate.org) accompanying the contribution and licensed to the project under the MPL-2.0.

You agree that You shall be bound by the terms of the MPL-2.0 for all contributions made by You and Your employees. Your designated employees are those listed by Your CLA Manager(s) on the system of record for the Project. You agree to identify Your initial CLA Manager below and thereafter maintain current CLA Manager records in the Project's system of record.

Initial CLA Manager (Name and Email): ______________________________________


Corporate Signature:


Company Name: ____________________________________________


Signature: _______________________________________________


Name: _______________________________________________


Title _______________________________________________


Date: _______________________________________________
