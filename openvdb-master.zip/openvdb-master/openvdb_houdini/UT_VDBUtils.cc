// Copyright Contributors to the OpenVDB Project
// SPDX-License-Identifier: MPL-2.0

/*
 * Copyright (c) Side Effects Software Inc.
 *
 * Produced by:
 *      Side Effects Software Inc
 *      477 Richmond Street West
 *      Toronto, Ontario
 *      Canada   M5V 3E7
 *      416-504-9876
 *
 * NAME:        UT_VDBUtils.h (UT Library, C++)
 *
 * COMMENTS:
 */

#include "UT_VDBUtils.h"

namespace openvdb_houdini {
// empty
}
