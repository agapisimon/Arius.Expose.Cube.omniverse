#!/usr/bin/env bash

set -ex

apt-get install -y libjemalloc-dev
