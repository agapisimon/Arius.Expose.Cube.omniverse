/*
__author__ = 'AGAPI SIMON'
copyright 2015
mittisimone@gmail.com

project: cube omniverse nodetree
*/


#ifndef NODEITEMS
#define NODEITEMS

#include<QtWidgets>
#include<math.h>
#include<customnWidgets.h>
//#define _debug   false
class Euler :public QVector3D
{
public:
    Euler(QVector3D v):QVector3D(v)
    {


    }
};

enum ENUMNODES
{
    NODE_BASE,
    NODE_VECTORCOMPOSE,
    NODE_VECTORDECOMPOSE,
    NODE_VECTORADD,
    NODE_VECTORSUB,
    NODE_VECTORSCALAR,
    NODE_VECTORPROJECT,
    NODE_VECTORCROSS,
    NODE_VECTORDOT,
    NODE_VECTORLENGTH,
    NODE_VECTORDISTANCE,
    NODE_VECTORREFLECT,
    NODE_VECTORREFRACT,
    NODE_VECTORNORMALIZED,
    NODE_DESCRIPTION_NOTE,
    NODE_GROUP,

    NODE_FLOAT_PIE,
    NODE_FLOAT_E,
    NODE_FLOAT_VALUE,
    NODE_FLOAT_RANDOM,
    NODE_FLOAT_ADD,
    NODE_FLOAT_MULTIPLY,
    NODE_FLOAT_SUBTRACT,
    NODE_FLOAT_DIVIDE,

    NODE_MATH_COSH,
    NODE_MATH_SINH,
    NODE_MATH_TANH,
    NODE_MATH_COS,
    NODE_MATH_SIN,
    NODE_MATH_TAN,
    NODE_MATH_ACOS,
    NODE_MATH_ASIN,
    NODE_MATH_ATAN,
    NODE_MATH_LOG,
    NODE_MATH_LOGE,
    NODE_MATH_EXP,
    NODE_MATH_POW,
    NODE_MATH_SQRT,
    NODE_MATH_ABS,
    NODE_MATH_FLOOR,
    NODE_MATH_CEIL,
    NODE_MATH_ROUND,
    NODE_MATH_MODULUS,

    NODE_STRING_STR,
    NODE_TIME,
    NODE_SOCKET_PREVIEW,

    NODE_VALUE_EQUAL,
    NODE_VALUE_LESSTHAN,
    NODE_VALUE_GREATERTHAN,
    NODE_VALUE_GREATER_OR_EQUAL,
    NODE_VALUE_LESS_OR_EQUAL,

    NODE_LOGIC_FLIPLOP,
    NODE_LOGIC_OR,
    NODE_LOGIC_NOR,
    NODE_LOGIC_XOR,
    NODE_LOGIC_XNOR,
    NODE_LOGIC_AND,
    NODE_LOGIC_NAND,

    NODE_LANG_IF,
    NODE_LANG_IFELSE,
    NODE_LANG_FOR,
    NODE_LANG_FOREACH,
    NODE_LANG_SWITCH,
    NODE_LANG_WHILE,
    NODE_LANG_DOWHILE,

    NODE_COLLECTION,

};
//while,for,foreach,switch,do while,



namespace  randomFunctions
{
    static float frandom(int max)
    {
        //qsrand((unsigned) qrand());

        int v = qrand()% max;

        return (float)v/max ;
    }

    static float f_random(int max)
    {
        //srand((unsigned) rand());

        int v = qrand()% max;

        return (float)v/max ;
    }

    static double f_round(double dval, int n)//ndecimal points
    {
        char l_fmtp[32], l_buf[64];

        char *p_str;

        sprintf (l_fmtp, "%%.%df", n);
        if (dval>=0)
                sprintf (l_buf, l_fmtp, dval);
        else
                sprintf (l_buf, l_fmtp, dval);
        return ((double)strtod(l_buf, &p_str));

    }
}

/*
namespace ItemsBackUP
{



#include <QGraphicsSvgItem>


class RoundedRectItem :   public QGraphicsRectItem
{
    QGraphicsTextItem * textItem;

public:
    RoundedRectItem(QGraphicsItem * parent =0):QGraphicsRectItem(parent),  textItem(NULL)
    {
        setRect(QRectF(-5,-5,10,10));
        //setFlag(ItemSendsScenePositionChanges, true);
        textItem = new QGraphicsTextItem;
        textItem->setPos(pos().x(),pos().y());
        textItem->setParentItem(this);

        setFlags(ItemIsSelectable | ItemIsMovable);
        setCursor(QCursor(Qt::OpenHandCursor));
    }

    QPainterPath  shape() //usefull for shape selection
    {
        QPainterPath p;
        p.addRoundRect(this->boundingRect(),10,10);
        return p;
    }

    QRectF boundingRect()
    {
         return QRectF(-5,-5,10,10);
    }


    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
    {
        painter->setPen(Qt::NoPen);
        painter->setBrush(Qt::darkGray);
        painter->drawRoundRect(boundingRect(),10,10);
        painter->setPen(QPen(Qt::black, 1));
        painter->drawRoundRect(boundingRect(),10,10);
        update();
    }

    void setItemText( QString  name)
    {
        textItem->setPlainText(name);
    }
};


class GroupNodeItem : public QGraphicsItemGroup
{
public:
    GroupNodeItem(QGraphicsItem * parent =0):QGraphicsItemGroup(parent)
    {

    }

};


class PixmapNodeItem : public QGraphicsPixmapItem
{

public:
    PixmapNodeItem(QGraphicsItem * parent =0):QGraphicsPixmapItem(parent)
    {

    }

};

class SvgNodeItem : public QGraphicsSvgItem
{

public:
    SvgNodeItem(QGraphicsItem * parent =0):QGraphicsSvgItem(parent)
    {

    }

};


}
*/

namespace Globals
{
    static qreal zdepth =-10.0f;

    static int connectionId = -1;

    static int socketIDCounter = -1;

    static int nodeIDCounter = -1;
}


enum SocketDataType
{
    NODE_ENUM,
    NODE_VECTOR,
    NODE_FLOAT,
    NODE_STRING,
    NODE_INT,
    NODE_BOOL,    
    NODE_QUATERNION,
    NODE_EULER,

    NODE_MATRIX,
    NODE_MATRIX3x3,
    NODE_MATRIX4x4,
    NODE_TRANSFORM,

    NODE_COLOR,    
    NODE_LIST,
    NODE_MULTI_DATA_TYPE,
};



class MultiDataType
{

public:
    int Type;

    virtual QString getString()
    {
        return QString("");
    }

};

namespace _NodeTypes
{

    class FloatData: public MultiDataType
    {        
    public:
        float data;

        FloatData()
        {

        }
        FloatData(float _data)
        {
            data = _data;
        }
        QString getString()
        {
            return QString::number(data);
        }

    };

    class IntData : public MultiDataType
    {
    public:
        int data;

        IntData(int _data)
        {
            data = _data;
        }
        QString getString()
        {
            return QString::number(data);
        }
    };

    class BoolData : public MultiDataType
    {
    public:
        bool data;

        BoolData(bool _data)
        {
            data = _data;
        }

        QString getString()
        {
            if(data)
                return QString("True");

             return QString("False");

        }
    };

    class Vector2Data: public MultiDataType
    {
    public:
        QVector2D data;

        Vector2Data(QVector2D _data)
        {
            data =  _data;
        }

        Vector2Data(float x,float y)
        {
            data.setX(x);
            data.setY(y);
        }

        QString getString()
        {
            QString str = QString("Vector2D: ")+QString::number(data.x())+QString(" , ")+QString::number(data.y());
            return str;
        }

    };

    class Vector3Data: public MultiDataType
    {
    public:
        QVector3D data;

        Vector3Data()
        {

        }
        Vector3Data(QVector3D _data)
        {
            data  = _data;

        }


        Vector3Data(float X,float Y, float Z)
        {
            data.setX(X);
            data.setY(Y);
            data.setZ(Z);
        }

        QString getString()
        {
            QString str = QString("Vector3D: ")+QString::number(data.x())+QString(" , ")+QString::number(data.y())+QString(" , ")+QString::number(data.z());
            return str;
        }

    };

    class StringData: public MultiDataType
    {
    public:
        QString data;

        std::string sdata;

        StringData()
        {

        }

        StringData(std::string _data)
        {
            sdata =  _data;
        }


        StringData(QString _data)
        {
            data =  _data;

        }


        QString getString()
        {
            return data;
        }
    };

    class ListData: public MultiDataType
    {
    public:
        QList<MultiDataType> data;

        ListData()
        {

        }
        ListData(QList<MultiDataType> _data)
        {
            data =  _data;

        }

        QString getString()
        {
            QString str = QString("List: ")+QString(" , ")+QString::number(data.size());
            return str;
        }

    };

    class MatrixData: public MultiDataType
    {
    public:
        QMatrix data;

        MatrixData()
        {

        }
        MatrixData(QMatrix _data)
        {
            data =  _data;

        }


        QString getString()
        {
            QString str = QString("Matrix: m11:")+QString::number(data.m11())+QString(" ,m12: ")+QString::number(data.m12()) + QString(" , m21:")+QString::number(data.m21()) +QString(" , m22:")+QString::number(data.m22());
            return str;
        }

    };

    class Matrix3x3Data: public MultiDataType
    {
    public:

        QMatrix3x3 data;

        Matrix3x3Data()
        {

        }

        Matrix3x3Data(QMatrix3x3 _data)
        {
            data =  _data;
        }


        QString getString()
        {
            float * f =  (float*)data.data();


            QString str = QString("Matrix4x4: m11:") +QString::number(f[0])
                         +QString(" ,m12:")+QString::number(f[1])
                         +QString(" ,m21:")+QString::number(f[2])
                         +QString(" ,m22:")+QString::number(f[3])

                         +QString(" ,m12:")+QString::number(f[4])
                         +QString(" ,m21:")+QString::number(f[5])
                         +QString(" ,m22:")+QString::number(f[6])
                         +QString(" ,m12:")+QString::number(f[7])

                         +QString(" ,m21:")+QString::number(f[8]);

            return str;
        }




    };

    class Matrix4x4Data: public MultiDataType
    {
    public:
        QMatrix4x4 data;

        Matrix4x4Data()
        {

        }
        Matrix4x4Data(QMatrix4x4 _data)
        {
            data =  _data;

        }


        QString getString()
        {
            float * f =  (float*)data.data();


            QString str = QString("Matrix4x4: m11:") +QString::number(f[0])
                         +QString(" ,m12:")+QString::number(f[1])
                         +QString(" ,m21:")+QString::number(f[2])
                         +QString(" ,m22:")+QString::number(f[3])

                         +QString(" ,m12:")+QString::number(f[4])
                         +QString(" ,m21:")+QString::number(f[5])
                         +QString(" ,m22:")+QString::number(f[6])
                         +QString(" ,m12:")+QString::number(f[7])

                         +QString(" ,m21:")+QString::number(f[8])
                         +QString(" ,m22:")+QString::number(f[9])
                         +QString(" ,m12:")+QString::number(f[10])
                         +QString(" ,m21:")+QString::number(f[11])

                         +QString(" ,m22:")+QString::number(f[12])
                         +QString(" ,m22:")+QString::number(f[13])
                         +QString(" ,m12:")+QString::number(f[14])
                         +QString(" ,m21:")+QString::number(f[15]);

            return str;
        }


    };

    class TransformData: public MultiDataType
    {
    public:
        QTransform data;

        TransformData()
        {

        }
        TransformData(QTransform _data)
        {
            data =  _data;

        }



        QString getString()
        {
            //float * f =  (float*)data.data();


            QString str = QString("Transform: m11:") +QString::number(data.m11())
                         +QString(" ,m12: ")+QString::number(data.m12())
                         +QString(" ,m13:")+QString::number(data.m13())

                         +QString(" ,m21:")+QString::number(data.m21())
                         +QString(" ,m22: ")+QString::number(data.m22())
                         +QString(" ,m23:")+QString::number(data.m23())

                         +QString(" ,m31:")+QString::number(data.m31())
                         +QString(" ,m32: ")+QString::number(data.m32())
                         +QString(" ,m33:")+QString::number(data.m33());

            return str;
        }



    };

    class QuaternionData: public MultiDataType
    {
    public:
        QQuaternion data;

        QuaternionData()
        {

        }
        QuaternionData(QQuaternion _data)
        {
            data =  _data;
        }

        QuaternionData(float X,float Y, float Z,float w)
        {
            data.setX(X);
            data.setY(Y);
            data.setZ(Z);
            data.setScalar(w);
        }

        QString getString()
        {
            QString str = QString("Quaternion: X:")+QString::number(data.x())+QString(" ,Y: ")+QString::number(data.y())+QString(" , Z:")+QString::number(data.z()) +QString(" , W:")+QString::number(data.scalar());
            return str;
        }
    };

    class ColorData: public MultiDataType
    {
    public:
        QColor data;

        ColorData()
        {

        }

        ColorData(QColor _data)
        {
            data  =  _data;
        }

        ColorData(float R,float G, float B)
        {
            data.setRedF(R);
            data.setBlueF(R);
            data.setGreenF(R);

        }
        Color(float R,float G, float B,float Alpha)
        {
            data.setRedF(R);
            data.setBlueF(R);
            data.setGreenF(R);
            data.setAlphaF(Alpha);
        }

        QString getString()
        {
            QString str = QString("Color: Red:")+QString::number(data.red())+QString(" ,Green: ")+QString::number(data.green())+QString(" , Blue:")+QString::number(data.blue()) +QString(" , Alpha:")+QString::number(data.alpha());
            return str;
        }
    };

    class MultiData: public MultiDataType
    {
    public:
        MultiDataType data;

        MultiData()
        {

        }

        MultiData(MultiDataType _data)
        {
            data  =  _data;
        }


        QString getString()
        {
            return data.getString();
        }
    };


}




/*

class Navigator : public QGraphicsRectItem
{
    float myscale = .1;
    float margin = 50;
    QRectF frameRect;

public:
    Navigator(QGraphicsItem * parent=0):QGraphicsRectItem(parent)
    {
        resizeAndPositionItem();
        setZValue(100);
    }

    QPainterPath  shape() //usefull for shape selection
    {
        QPainterPath p;
        p.addRoundRect(frameRect,1,1);
        return p;
    }

    QRectF boundingRect()
    {
         return frameRect;
    }

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
    {

        resizeAndPositionItem();

        painter->drawRoundedRect(boundingRect(), 1, 1, Qt::RelativeSize);

        //QPixmap piximage = QPixmap::grabWidget((QWidget*)this->parentWidget());
        //piximage.scaledToWidth( this->boundingRect().width()*myscale);
        //painter->drawPixmap(scenePos(),piximage,frameRect);
        //painter->setOpacity(0.9);

        setCursor(Qt::SizeAllCursor);
    }

    void resizeAndPositionItem()
    {
        if(scene())
        {
            QList<QGraphicsView *> views= scene()->views();

            foreach(QGraphicsView *view,views)
            {
                frameRect = QRectF(view->width()-margin,view->height()-margin,view->width()*myscale, view->height()*myscale);

                setRect(frameRect);

                setPos(view->pos());
            }
        }
    }



    void hoverEnterEvent(QGraphicsSceneHoverEvent *event)
    {
        printf("hover enter\n");
        QGraphicsRectItem::hoverEnterEvent(event);

    }

    void hoverMoveEvent(QGraphicsSceneHoverEvent *event)
    {
        printf("hover move\n");
        QGraphicsRectItem::hoverMoveEvent(event);

    }

    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
    {
        printf("hover leave\n");
        QGraphicsRectItem::hoverLeaveEvent(event);

    }
};
*/

class GridItem : public QGraphicsRectItem
{
    QVector<QLine> hlines;

    QVector<QLine> vlines;

    QPen   pen;

public:

    QPainterPath  shape()const //usefull for shape selection
    {
        QPainterPath p;

        p.addRect(boundingRect());

        return p;
    }

    QRectF boundingRect() const
    {
         return QRectF(0, 0, 4000, 4000);
    }

    GridItem(QGraphicsItem * parent=0):QGraphicsRectItem(parent)
    {
        setRect(QRectF(0, 0, 4000, 4000));
        setZValue(-100);
        pen = QPen(QColor(255, 255, 255,10), .1, Qt::SolidLine);

        pen.setWidth(1);

        float spacing = 90;


        for( float dx =0;dx<4000;dx += spacing)
        {
            QLine line;


            line.setPoints(QPoint(dx,0), QPoint(dx,4000) );

            hlines.append(line);
        }

        for( float dy =0;dy<4000;dy += spacing)
        {

            QLine line;
            line.setPoints(QPoint(0,dy), QPoint(4000,dy) );


            vlines.append(line);
        }


    }

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
    {
        rectangulerTile(painter);

    }

    void rectangulerTile(QPainter *painter)
    {
        //painter->drawRoundedRect(QRectF(0, 0, 4000, 4000), 1, 1);
        painter->setPen(pen);
        //painter->setBrush(Qt::NoBrush);

        painter->drawLines(hlines);
        painter->drawLines(vlines);
    }
};








class SocketItem;

class ConnectionItem  : public QObject,public QGraphicsPathItem
{
    Q_OBJECT

    QPolygonF polygon;
    QColor ccolor;

    QGraphicsEllipseItem * deletor;
    QGraphicsLineItem * interactiveLine;

    SocketItem * startSocketItem;
    SocketItem * endSocketItem;

    QGraphicsEllipseItem *deletorItem;

    QPainterPath pPath;

    QTimer* timer;

    bool _debug = false;
public:

    void setDebuging(bool print = false)
    {
       _debug = print;
    }


    QPointF p1 ;
    QPointF p2 ;

    enum ConnectionType
    {
        LINE,
        BEZIER,
        STEP,
        ZIGZAG,
        NONE,
    };

    int Connection_Type = BEZIER;

    int ID;   

    ConnectionItem(SocketItem *startItem, SocketItem *endItem, QGraphicsItem *parent = 0)
        : QGraphicsPathItem(parent),
          startSocketItem(startItem),
          endSocketItem(endItem)
    {
        //createMenu();



        deletorItem = new QGraphicsEllipseItem;

        deletorItem->setParentItem(this);
        deletorItem->setRect(QRect(-4,-4,8,8));
        deletorItem->setCursor(Qt::CrossCursor);

        QPen pen1;

        pen1.setWidthF(1.0f);
        pen1.setColor(Qt::black);

        QBrush brush;
        brush.setColor(Qt::cyan);
        brush.setStyle(Qt::SolidPattern);

        deletorItem->setBrush(brush);

        deletorItem->setPen(pen1);

        setCursor(QCursor(QPixmap(QString(":/cubeomniverse.svg"))));

        //setCursor(QCursor(Qt::CrossCursor);

        //setFlag(QGraphicsItem::ItemSendsGeometryChanges);
        //setFlag(QGraphicsItem::ItemIsFocusable);
        setFlag(QGraphicsItem::ItemIsSelectable);


        Globals::connectionId += 1;

        ID = Globals::connectionId;

        Globals::zdepth += 0.01f;

        setZValue(Globals::zdepth);

        //setZValue(1.0);

        ccolor = Qt::cyan;
        //setPen(QPen(ccolor, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));

        timer = new QTimer();

        connect(timer,SIGNAL(timeout()),this,SLOT(sendDataAcrossConnetion()));

        timer->start();
    }

    ~ ConnectionItem()
    {
        disableConnection();
    }

    void enableConnection()
    {
        timer->start();
    }
    void disableConnection()
    {
        timer->stop();
    }


    SocketItem * getStartItem() const { return startSocketItem; }
    SocketItem * getEndItem() const { return endSocketItem; }


    void setStartItem(SocketItem *startItem) { startSocketItem =  startItem; }
    void setEndItem(SocketItem * endItem) { endSocketItem = endItem; }

    void setColor(const QColor &color) { ccolor = color; }

    void setConnectionType( int _connection_type = BEZIER)
    {
        Connection_Type  = _connection_type;
    }

    QRectF boundingRect() const
    {
        return QRectF(p1,p2);
    }


    QPainterPath shape() const
    {
        QPainterPathStroker stroker;

        stroker.setWidth(10);//stroke width 10 is selectable

        QPainterPath hitshape = stroker.createStroke(pPath);

        return hitshape;
    }

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
    {
        Q_UNUSED(option);
        Q_UNUSED(widget);
        //prepareGeometryChange();

        QPainterPath path;

        if(isSelected())
        {
            QPen pen;

            pen.setWidthF(1.0f);
            pen.setColor(Qt::lightGray);
            pen.setStyle(Qt::DashLine);
            pen.setDashOffset(3.0f);
            pen.setCapStyle(Qt::RoundCap);
            pen.setJoinStyle(Qt::RoundJoin);


            painter->setPen(pen);
        }
        else
        {
            QPen pen;

            pen.setWidthF(1.0f);
            pen.setColor(Qt::cyan);
            pen.setStyle(Qt::SolidLine);
            //pen.setCapStyle(Qt::RoundCap);
            //pen.setJoinStyle(Qt::RoundJoin);


            painter->setPen(pen);

        }

        if(Connection_Type ==LINE)
        {
            path.moveTo(p1);

            float distance = p2.x() - p1.x();

            distance *= 0.5;

            path.lineTo(p2);


        }

        else if(Connection_Type ==BEZIER)
        {

            path.moveTo(p1);

            float distance = p2.x() - p1.x();

            distance *= 0.5;

            path.cubicTo(p1.x() + distance , p1.y(),p1.x() + distance, p2.y(),p2.x(), p2.y());
        }

        else if(Connection_Type ==STEP)
        {
            float distance = p2.x() - p1.x();

            distance *= 0.5;

            QPointF A(p1.x() + distance,p1.y());
            QPointF B(p1.x() + distance,p2.y());

            path.moveTo(p1);
            path.lineTo(A);
            path.moveTo(A);
            path.lineTo(B);
            path.moveTo(B);
            path.lineTo(p2);
        }

        else if(Connection_Type ==ZIGZAG)
        {
            QPointF A = p1;
            QPointF B = p2;

            QPointF delta  = p2 - p1;

            A += QPointF(delta.x()/2.0f,0.0f);
            B += QPointF(0.0f,delta.y()/2.0f);

            path.moveTo(p1);

            path.lineTo(A);
            path.moveTo(A);
            path.lineTo(B);
            path.moveTo(B);
            path.lineTo(p2);

        }

        else if(Connection_Type ==NONE)
        {

        }

        pPath = path;

        painter->drawPath(path);

        polygon.clear();
        polygon = path.toFillPolygon();

        QPointF midp =0.5*(p1+p2);
        deletorItem->setPos(midp);

        scene()->update();
    }

public:


    void drawBezier(QPainter *painter)
    {
        QPointF P0 = p1;//line is inherited from QGraphicsLineItem
        QPointF P3 = p2;//line is inherited from QGraphicsLineItem


        QPainterPath path;

        QPointF dp  = P3-P0;
        qreal bias  =   0.4*abs(dp.x());

        QPointF P1 = P0 + QPointF(-bias, 0);
        QPointF P2 = P3 + QPointF(bias, 0);

        path.moveTo(P0);
        path.cubicTo(P1, P2, P3);


        QPainterPathStroker stroker;
        stroker.setWidth(0.3);
        stroker.createStroke(path);
        painter->drawPath(stroker.createStroke(path));// a stroke
        painter->restore();

        //painter->drawPath(path);//draw a filled shape

    }

public slots:

    virtual void sendDataAcrossConnetion();

};

#include<vector>

class SocketItem :   public QGraphicsRectItem//QGraphicsEllipseItem // public QObject
{
    QList<ConnectionItem *> connections;

    QList< QSharedPointer<ConnectionItem> > pconnections;

    int SocketType = -1;

    SocketDataType socketDataType;

    MultiDataType * data;

    std::string socketName;

    QRectF bounds;
    QRectF circlerect;

    bool _debug = false;

public:

    void setDegging(bool print = false)
    {
        _debug = print;
    }

    enum //SocketType
    {
        OutPut,
        InPut,
    };

    int ID =0;

    QGraphicsTextItem * socketNameItem;

    QPainterPath  shape()
    {
        QPainterPath p;
        p.addRect(bounds);
        return p;
    }

    QRectF boundingRect()
    {
        return bounds;//frameRect;
    }

    void hoverEnterEvent(QGraphicsSceneHoverEvent *event)
    {
        if(this->parentItem())
        {
            QGraphicsItem *item =this->parentItem();
            item->setFlag(ItemIsMovable,false);
            if(_debug)
                qDebug()<<"Hover Enter"<<QString::fromStdString(socketName);

        }

    }

    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
    {
        if(this->parentItem())
        {
            QGraphicsItem *item =this->parentItem();
            item->setFlag(ItemIsMovable,true);

            if(_debug)
                qDebug()<<"Hover Leave"<<QString::fromStdString(socketName);

        }
    }


    SocketDataType getSocketDataType()
    {
        return socketDataType;
    }

    void setSocketDataType(SocketDataType socketDataType)
    {
        this->socketDataType = socketDataType;

    }

    virtual MultiDataType* getSocketData()
    {
        return data;
    }

    virtual void setSocketData(MultiDataType * socketData)
    {
        data = socketData;
    }

    virtual void setSocketName(std::string sockename)
    {
        socketName = sockename;
        socketNameItem->setPlainText(QString::fromStdString(sockename));
    }

    virtual std::string getSocketName()
    {
        return socketName;
    }


    SocketItem(const QString & name,QGraphicsItem * parent =0):QGraphicsRectItem(parent),socketNameItem(NULL)
    {
        setAcceptHoverEvents(true);

        Globals::socketIDCounter += 1;

        ID = Globals::socketIDCounter;

        bounds =  QRectF(-6.5, -6.5, 13, 13);
        circlerect = bounds;//= QRectF(-5, -5, 10, 10);

        setRect(bounds);

        setBrush(QBrush(Qt::green));

        socketNameItem = new QGraphicsTextItem;
        socketNameItem->setPlainText(name);

        socketName = name.toStdString();

        socketNameItem->setPos(pos().x()+12,pos().y()-12);
        socketNameItem->setParentItem(this);
        socketNameItem->setFlag(ItemIsFocusable,false);
        socketNameItem->setFlag(ItemIsSelectable,false);
        socketNameItem->setFlag(ItemIsMovable,false);


        //setFlags(ItemIsSelectable);
        //setCursor(QCursor(Qt::CrossCursor));
        //setCursor(QCursor(QPixmap(QString(":/cubeomniverse.svg"))));
        setCursor(QCursor(QPixmap(QString(":/icon.svg"))));
        //setFlags(ItemIsFocusable);
        setToolTip(QString("Socket:"+name));
    }

    QList<ConnectionItem *> getConnections()
    {
        return connections;
    }

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
    {
        Q_UNUSED(option);
        Q_UNUSED(widget);

        painter->setRenderHint(QPainter::Antialiasing);
        QPen pen;
        pen.setColor(QColor(Qt::black));
        pen.setWidthF(1.0f);
        painter->setPen(pen);

        if(connections.size()>0)
        {
           painter->setBrush(QBrush(Qt::red));
        }
        else
        {
            painter->setBrush(QBrush(Qt::green));
        }

        //setBrush(QBrush(QColor(frandom(100)*255,frandom(100)*255,frandom(100)*255,255)));//QtCore.Qt.cyan))

        //float roundingX = 3;
        //float roundingY = 3 * this->bounds.width()/this->bounds.height();

        painter->drawRoundRect(circlerect,50,50);

        if(SocketType==InPut)
        {

        }
        else if(SocketType ==OutPut)
        {
        }
    }


    void addConnection(ConnectionItem *connector)
    {
        if(SocketType==OutPut)
        {
            connections.append(connector);
        }
        else if(SocketType == InPut)
        {
            //scene()->removeItem(connections[0]);
            //connections.clear();
            connections.append(connector);

        }
    }

    void removeConnection(ConnectionItem *connector)
    {
        int index = connections.indexOf(connector);

        if (index != -1)
        {
            connections.removeAt(index); //hopefully delete connector;
        }
    }

    void removeConnections()
    {
        connections.clear();
    }

    void setItemText( QString  name)
    {
        socketNameItem->setPlainText(name);
    }    

    void setSocketType(int Socket_Type = InPut)
    {
        SocketType = Socket_Type;
    }

    int getSocketType()
    {
        return SocketType;
    }
};

class NodeBaseItem :  public QObject, public QGraphicsRectItem
{
    Q_OBJECT
protected:

    QList<QColor> colors;

    QBrush * brush;

    int margin = 25;

    QRectF minRect;
    QRectF maxRect;

    QRectF frameRect;
    QRectF boundRect;
    QRectF selectionRect;

    QIcon icon;

    QGraphicsTextItem * label;

    //NodeShapeIcon * handle;

    QTimer * timer;

    int frame;

    bool _debug = false;

    //QGraphicsProxyWidget * proxy;

    //QScopedPointer<QWidget> pWidget;

    QWidget * widget;

public:

    QWidget * getWidget()
    {
        return widget;
    }


    /*

    QWidget *getWidget()
    {
        return (QWidget*)proxy;
    }

    */
    int getMargin()
    {
        return margin;
    }

    QRectF getMinRect()
    {
        return minRect;
    }
    QRectF getFrameRect()
    {
        return frameRect;
    }
    QRectF getBoundRect()
    {
        return boundRect;
    }
    QRectF getSelectionRect()
    {
        return selectionRect;
    }

    void setFrameRect(QRectF _frameRect)
    {
        frameRect = _frameRect;
    }

    void setDegging(bool print = false)
    {
        _debug =    print;
    }

    QList<SocketItem*> inputs;
    QList<SocketItem*> outputs;

    //QList< QSharedPointer<SocketItem> > cinputs;

    //QList<SocketInputItem*> inputs;
    //QList<SocketOutPutItem*> outputs;

    /*
     * For testing purpose
     * usefull for shape selection but instead use setRect()
     */

    QPainterPath  shape()
    {
        QPainterPath p;
        p.addRoundRect(boundRect,0,0);
        return p;
    }


    enum { Type = NODE_BASE};

    int type() const  { return Type; }

    int typeOfNode() const{return Type;}


    QRectF boundingRect()
    {
         //resize();
         return boundRect;//frameRect;
    }

public:

   int ID;

   ~NodeBaseItem()
   {
       delete label;

       //delete handle;

       delete timer;

       delete widget;
   }

   NodeBaseItem(QGraphicsItem * parent =0) : QGraphicsRectItem(parent)
   {
       //proxy = new QGraphicsProxyWidget;//(0,Qt::Window);

       //proxy->setParentItem(this);

       //proxy->setFlag(ItemIsFocusable);



       Globals::nodeIDCounter += 1;

       ID = Globals::nodeIDCounter;

       colors.append(QColor(31,161,153));
       colors.append(QColor(115,138,149));
       colors.append(QColor(158,165,227));
       colors.append(QColor(171,166,201));

       colors.append(QColor(122,203,245));
       colors.append(QColor(214,207,181));
       colors.append(QColor(231,240,223));
       colors.append(QColor(27,153,217));


        //setFlag(ItemPositionHasChanged);
        setFlag(QGraphicsItem::ItemSendsGeometryChanges);

        frameRect = QRectF(0,0,150,100);

        minRect = frameRect;

        /*
        //setRect(QRectF(0,0,150,100));

        frameRect = QRectF(0,0,150,100);
        minRect   = frameRect;
        boundRect = frameRect;
        selectionRect =  frameRect;


        selectionRect = selectionRect.adjusted(-5,-5,5,5);
        boundRect = boundRect.adjusted(-10,-10,10,10);

        setRect(boundRect);

        */
        /*

        qsrand(qrand()%255);
        brush = new QBrush(QColor(qrand()%255,qrand()%255,qrand()%255,255));
        setPen(QPen(Qt::black,2));
        setBrush(*brush);
        */

        //brush = new QBrush(QColor(23,23,23));
        //brush = new QBrush(QColor(9,34,30));
        //brush = new QBrush(QColor(97,97,97));
        brush = new QBrush(QColor(colors[5]));
        setPen(QPen(Qt::white,2));
        setBrush(*brush);

        //QFont serifFont("Times", 10, QFont::Bold);

        QFont font;


        font.setPointSize(10);
        font.setBold(true);

        //QFont sansFont("Helvetica [Cronyx]", 12);

        // Label
        label = new QGraphicsTextItem;
        label->setPlainText(QString("Node Base Item"));
        label->setParentItem(this);
        label->setFont(font);


        //handle = new NodeShapeIcon;
        //handle->setParentItem(this);
        //handle->setPos(this->pos().x()+ frameRect.width() - margin, this->pos().y()+frameRect.height()-margin);

        //handle->setFlag(ItemIsSelectable,false);
        //handle->setFlag(ItemIsMovable,false);


        //addWidgets();

        addsockets();

        computeBounds();

        /*
        QGraphicsDropShadowEffect * effect = new QGraphicsDropShadowEffect();

        effect->setBlurRadius(10);
        effect->setColor(QColor(0, 0, 0, 150));//QColor(R,G,B, Alhpha)
        effect->setXOffset(.5);
        effect->setYOffset(.5);
        setGraphicsEffect(effect);
        */

        setFlags(ItemIsSelectable | ItemIsMovable );

        setCursor( QCursor( Qt::PointingHandCursor ) );
        /*

        timer->setInterval(50);

        timer->connect(timer,SIGNAL(timeout()),this,SLOT(compute()));

        timer->start();
        */

        //InitilizeNodeSockets();

         setFlag(ItemSendsGeometryChanges);

         timer = new QTimer();

         setTimer();
   }

   virtual void setTimer()
   {
       setFrameFrate(FPS_REALTIME);

       connect(timer, SIGNAL(timeout()), this, SLOT(compute()));
       //timer->start();
   }



   virtual void disableNode()
   {
       timer->stop();
   }

   virtual void enableNode()
   {
       timer->start();
   }
   /*

   static void setGlobalFrameFrate(int fps)
   {
       NodeBaseItem::setFrameFrate(fps);
   }
   */

   virtual void setFrameFrate(FRAME_RATES FrameRate)
   {
       float interval;
       //1000ms = 1s;

       if(FrameRate = FPS_24)
       {
           interval = (float)1/24 * 1000;
       }
       else if(FrameRate = FPS_25)
       {
           interval = (float)1/25 * 1000;
       }
       else if(FrameRate = FPS_30)
       {
           interval = (float)1/30 * 1000;
       }
       else if(FrameRate = FPS_60)
       {
           interval = (float)1/60 * 1000;
       }
       else if(FrameRate = FPS_90)
       {
           interval = (float)1/90 * 1000;
       }
       else if(FrameRate = FPS_REALTIME)
       {
           interval = 0;
       }
       else if(FrameRate = FPS_CUSTOMN)
       {
       }

       timer->setInterval(interval);
   }

   void setBottomRightCorner(QPointF p)
   {
       frameRect.setBottomRight(p);
   }


   void UpdateConnections()
   {
       foreach( SocketItem *socket ,inputs)
       {
           if(socket->getConnections().size()>0)
           {
               foreach( ConnectionItem *connector ,socket->getConnections())
               {
                   connector->p2 = socket->scenePos();
               }
           }
       }

       foreach( SocketItem *socket ,outputs)
       {
           if(socket->getConnections().size()>0)
           {
               foreach( ConnectionItem *connector ,socket->getConnections())
               {
                   connector->p1 = socket->scenePos();
               }
           }
       }
   }



   QVariant itemChange(GraphicsItemChange change, const QVariant &value)
   {
       //QPointF newPos = value.toPointF();

       UpdateConnections();

       if(_debug)
       {
           printf("Dragging \n");
          // qDebug()<<newPos;
       }

       return QGraphicsItem::itemChange(change, value);

   }




    virtual void  removeSockets()
    {
        foreach(SocketItem *socket, inputs)
        {
            int index = inputs.indexOf(socket);
            inputs.removeAt(index);
            //inputs.removeAll(socket);
            delete socket;
        }
        inputs.clear();

        foreach(SocketItem *socket, outputs)
        {
            int index = outputs.indexOf(socket);
            outputs.removeAt(index);
            delete socket;

            //outputs.removeAll(socket);
        }

        outputs.clear();
    }

    virtual void addWidgets()
    {
       /*

       QVBoxLayout * layout  = new QVBoxLayout;
       QWidget * itemWidget  = new QWidget;
       itemWidget->setMaximumWidth(frameRect.width());



       QFile file(":/glowBlue.stylesheet");


       if(file.open(QIODevice::ReadOnly | QIODevice::Text))
       {
           QByteArray  style =file.readAll();
           itemWidget->setStyleSheet(style);
           file.close();
       }


       //itemWidget->setWindowFlags(Qt::FramelessWindowHint);
       //itemWidget->setAttribute(Qt::WA_NoSystemBackground);
       //itemWidget->setAttribute(Qt::WA_TranslucentBackground);
       //itemWidget->setAttribute(Qt::WA_PaintOnScreen);
       //itemWidget->setAttribute(Qt::WA_TransparentForMouseEvents);

       QSlider     * slider  = new QSlider;
       QLineEdit * lineEdit  = new QLineEdit;
       QSpinBox * spinbox    = new QSpinBox;
       QLabel * label        = new QLabel(QString("Node Base Item"));

       slider->setOrientation(Qt::Horizontal);

       layout->addWidget(slider);
       layout->addWidget(lineEdit);
       layout->addWidget(spinbox);
       layout->addWidget(label);
       itemWidget->setLayout(layout);


       proxy->setWidget(itemWidget);

       */





    }

    virtual void addsockets()
    {
       /*
        removeSockets();


        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        SocketItem *a = new SocketItem(QString("X"),this);
        a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("X");

        SocketItem *b = new SocketItem(QString("Y"),this);
        b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Y");

        SocketItem *c = new SocketItem(QString("Z"),this);
        c->setCursor(icoCursor);
        c->setSocketType(SocketItem::InPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Z");

        inputs.append(a);
        inputs.append(b);
        inputs.append(c);


        SocketItem *d = new SocketItem(QString("Result"),this);
        d->setSocketType(SocketItem::OutPut);
        d->setSocketDataType(NODE_VECTOR);
        d->setSocketName("Result");



        outputs.append(d);


        positionSockets();
        InitilizeNodeSockets();

        */

    }

   /*

    virtual void positionSockets()
    {
        // center label:
        QRectF rect = frameRect;

        float w = rect.width();
        float h = rect.height();

        float dx = 0;
        float dy = 20;

        float y = 0;

        QPointF p2 = label->pos();

        //float offset = 0.25f*(this->boundingRect().width()- label->boundingRect().width());
        //p2 += QPointF(offset,0);
        p2+= QPointF(5,0);
        label->setPos(p2);

        //label->setPos(dx+offset,0);


        y += 25;

        for(int i =0;i<outputs.size();i++)
        {
            QPoint p = QPoint(w,y);

            outputs[i]->setPos(p);
            QRectF rec = outputs[i]->socketNameItem->boundingRect();
            QPointF p1 = outputs[i]->socketNameItem->pos();
            p1 += QPointF(-1*(rec.width()+20),0);
            outputs[i]->socketNameItem->setPos(p1);

            y += dy;

        }

        for(int i=0;i<inputs.size();i++)
        {
            inputs[i]->setPos(dx, y);
            y += dy;
        }
    }

    */

   virtual void computeBounds()
   {
       minRect   = frameRect;
       boundRect = frameRect;

       selectionRect =  frameRect;

       selectionRect = selectionRect.adjusted(-5,-5,5,5);
       boundRect = boundRect.adjusted(-10,-10,10,10);

       setRect(boundRect);
   }

   virtual void positionSockets()
   {
       // center label:
       QRectF rect = frameRect;

       float w = rect.width();
       float h = rect.height();

       float dx = 0;
       float dy = 20;

       float y = 0;

       QPointF p2 = label->pos();


       p2+= QPointF(5,0);

       label->setPos(p2);


       y += 30;

       for(int i =0;i<outputs.size();i++)
       {
           QPoint p = QPoint(w,y);

           outputs[i]->setPos(p);
           QRectF rec = outputs[i]->socketNameItem->boundingRect();
           QPointF p1 = outputs[i]->socketNameItem->pos();
           p1 += QPointF(-1*(rec.width()+20),0);
           outputs[i]->socketNameItem->setPos(p1);

           y += dy;

       }

       y += 5;

       for(int i=0;i<inputs.size();i++)
       {
           inputs[i]->setPos(dx, y);
           y += dy;
       }

       /*

       //widget section

       //y+= 5;


       proxy->setPos(dx,y);

       y+= proxy->size().height();

       //end of widget section
       */


       frameRect.setHeight(y);


       computeBounds();
   }

    virtual void setNodeName(QString nodename)
    {
        label->setPlainText(nodename);
    }

    virtual QString getNodeName()
    {
        return label->toPlainText();
    }

    virtual void InitilizeNodeSockets()
    {
        using namespace _NodeTypes;

        foreach(SocketItem * socket,inputs)
        {
            switch(socket->getSocketDataType())
            {
            case  NODE_FLOAT:
            {
                FloatData  * f  =  new FloatData(0);
                socket->setSocketData(f);
                break;
            }
            case  NODE_INT:
            {
                IntData * idata = new IntData(0);
                socket->setSocketData(idata);
                break;
            }
            case  NODE_STRING:
            {
                StringData * str = new StringData(QString("default"));
                socket->setSocketData(str);
                break;
            }
            case  NODE_BOOL:
            {
                BoolData * bl = new BoolData(false);
                socket->setSocketData(bl);
                break;
            }
            case  NODE_VECTOR:
            {
                QVector3D u;
                Vector3Data * v = new Vector3Data(u);
                socket->setSocketData(v);
                break;
            }            
            case  NODE_COLOR:
            {
                ColorData * cdata = new ColorData(QColor(Qt::cyan));
                socket->setSocketData(cdata);
                break;
            }
            case  NODE_LIST:
            {
                ListData *ldata = new ListData;
                socket->setSocketData(ldata);
                break;
            }

            case  NODE_QUATERNION:
            {
                QuaternionData * qdata = new QuaternionData(0,0,0,0);
                socket->setSocketData(qdata);
                break;
            }
            case  NODE_MATRIX4x4:
            {
                Matrix4x4Data * mdata = new Matrix4x4Data();
                socket->setSocketData(mdata);
                break;
            }
            case  NODE_MATRIX3x3:
            {
                Matrix3x3Data * mdata = new Matrix3x3Data();
                socket->setSocketData(mdata);
                break;
            }
            case  NODE_TRANSFORM:
            {
                TransformData * tdata = new TransformData();
                socket->setSocketData(tdata);
                break;
            }

            case NODE_MULTI_DATA_TYPE:
            {
                MultiData * ndata = new MultiData;
                socket->setSocketData(ndata);
                break;
            }

            }
        }
    }

    virtual void resizeNode()
    {
        /*
        QPointF p0 = this->scenePos();
        QPointF p2 = handle->scenePos();

        QPointF delta = p2 - p0;

        if(delta.x()<minRect.width())
        {
            delta.setX(minRect.width());
        }

        if(delta.y()<minRect.height())
        {
            delta.setY(minRect.height());
        }

        frameRect.setWidth(delta.x()+margin);
        frameRect.setHeight(delta.y()+margin);

        positionSockets();

        setRect(frameRect);

        handle->setPos(delta);
        */
    }

    virtual void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
    {
        Q_UNUSED(option);
        Q_UNUSED(widget);

        painter->setRenderHint(QPainter::Antialiasing);

        if(this->isSelected())
        {
            painter->save();
            QPen pen;
            pen.setWidth(1);
            pen.setStyle(Qt::DashLine);

            painter->setPen(pen);
            painter->setBrush(QBrush(Qt::NoBrush));
            painter->drawRect(selectionRect);//boundingRect());
            painter->restore();
        }

        painter->setPen(Qt::NoPen);
        //setBrush(QBrush(QColor(frandom(100)*255,frandom(100)*255,frandom(100)*255,255)));//QtCore.Qt.cyan))

        float roundingX = 6;

        float roundingY = 6 * this->frameRect.width()/this->frameRect.height();

        painter->setBrush(*brush);
        //painter->drawRoundRect(this->boundingRect(),roundingX,roundingY);
        painter->drawRoundRect(frameRect,roundingX,roundingY);


        painter->setPen(QPen(Qt::black, 1));
        //painter->setBrush(QBrush(color));
        //painter->drawRoundRect(this->boundingRect(),roundingX,roundingY);
        painter->drawRoundRect(frameRect,roundingX,roundingY);
    }

public slots:

    virtual void compute()
    {
        /*
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];
        SocketItem * socket3 =  inputs[2];

        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();
        FloatData *f2 = (FloatData *)socket2->getSocketData();
        FloatData *f3 = (FloatData *)socket3->getSocketData();

        MultiDataType * v =  new  Vector3Data(f1->data,f2->data,f3->data);

        socket->setSocketData(v);

        Vector3Data *u = (Vector3Data*)v;

        printf("==>Vector Combine: %f,%f,%f: \n",u->data.x(),u->data.y(),u->data.z());

        printf("Node executed\n");
        */

    }


};

class NodeVectorComposeItem :public NodeBaseItem
{
    Q_OBJECT

    QSlider * sliderX;
    QSpinBox* spinBoxX;

    QSlider * sliderY;
    QSpinBox* spinBoxY;

    QSlider * sliderZ;
    QSpinBox* spinBoxZ;

public:
    enum { Type = NODE_VECTORCOMPOSE};

    int type() const  { return Type; }

    NodeVectorComposeItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
        addsockets();
        addWidgets();
    }

    ~NodeVectorComposeItem()
    {
        delete widget;

        delete spinBoxX;
        delete sliderX;

        delete spinBoxY;
        delete sliderY;

        delete spinBoxZ;
        delete sliderZ;
    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];
        SocketItem * socket3 =  inputs[2];

        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();
        FloatData *f2 = (FloatData *)socket2->getSocketData();
        FloatData *f3 = (FloatData *)socket3->getSocketData();

        if(socket1->getConnections().size()==0)
        {
            f1->data = spinBoxX->value();
        }
        if(socket2->getConnections().size()==0)
        {
            f2->data = spinBoxY->value();
        }
        if(socket3->getConnections().size()==0)
        {
            f3->data = spinBoxZ->value();
        }

        MultiDataType * v =  new  Vector3Data(f1->data,f2->data,f3->data);




        socket->setSocketData(v);

        Vector3Data *u = (Vector3Data*)v;

        if(_debug)
        {
            printf("==>Vector Combine: %f,%f,%f: \n",u->data.x(),u->data.y(),u->data.z());
            printf("Node executed\n");
        }


    }

    void addsockets()
    {
        removeSockets();


        //QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        SocketItem *a = new SocketItem(QString("X"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("X");

        SocketItem *b = new SocketItem(QString("Y"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Y");

        SocketItem *c = new SocketItem(QString("Z"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::InPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Z");

        inputs.append(a);
        inputs.append(b);
        inputs.append(c);


        SocketItem *d = new SocketItem(QString("Result"),this);
        d->setSocketType(SocketItem::OutPut);
        d->setSocketDataType(NODE_VECTOR);
        d->setSocketName("Result");


        outputs.append(d);

        positionSockets();
        InitilizeNodeSockets();
        enableNode();

     }



    void addWidgets()
    {
        //itemWidget->setWindowFlags(Qt::FramelessWindowHint);
        //itemWidget->setAttribute(Qt::WA_NoSystemBackground);
        //itemWidget->setAttribute(Qt::WA_TranslucentBackground);
        //itemWidget->setAttribute(Qt::WA_PaintOnScreen);
        //itemWidget->setAttribute(Qt::WA_TransparentForMouseEvents);

        widget   = new QWidget;
        sliderX  = new QSlider(Qt::Horizontal);
        spinBoxX = new QSpinBox();

        sliderY  = new QSlider(Qt::Horizontal);
        spinBoxY = new QSpinBox();

        sliderZ  = new QSlider(Qt::Horizontal);
        spinBoxZ = new QSpinBox();

        setMinMaxValue(-1000,1000,0);

        QVBoxLayout * vlayout =  new QVBoxLayout;

        QHBoxLayout * layoutL =  new QHBoxLayout;
        layoutL->addWidget(new QLabel("Vector X Y Z"));

        QHBoxLayout * layoutX =  new QHBoxLayout;
        layoutX->addWidget(new QLabel("X  :"));
        layoutX->addWidget(sliderX);
        layoutX->addWidget(spinBoxX);


        QHBoxLayout * layoutY =  new QHBoxLayout;
        layoutY->addWidget(new QLabel("Y  :"));
        layoutY->addWidget(sliderY);
        layoutY->addWidget(spinBoxY);


        QHBoxLayout * layoutZ =  new QHBoxLayout;
        layoutZ->addWidget(new QLabel("Z  :"));
        layoutZ->addWidget(sliderZ);
        layoutZ->addWidget(spinBoxZ);

        vlayout->addLayout(layoutL);
        vlayout->addLayout(layoutX);
        vlayout->addLayout(layoutY);
        vlayout->addLayout(layoutZ);


        widget->setLayout(vlayout);

        widget->setWindowTitle(QString("Vector X Y Z "));

        widget->setBaseSize(100,20);

        QFile file(":/glowBlue.stylesheet");


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QByteArray  style =file.readAll();
            widget->setStyleSheet(style);
            file.close();
        }

        connect(sliderX,SIGNAL(valueChanged(int)),this,SLOT(setSpinBoxValue()));
        connect(spinBoxX,SIGNAL(valueChanged(int)),this,SLOT(setSliderValue()));

        connect(sliderY,SIGNAL(valueChanged(int)),this,SLOT(setSpinBoxValue()));
        connect(spinBoxY,SIGNAL(valueChanged(int)),this,SLOT(setSliderValue()));

        connect(sliderZ,SIGNAL(valueChanged(int)),this,SLOT(setSpinBoxValue()));
        connect(spinBoxZ,SIGNAL(valueChanged(int)),this,SLOT(setSliderValue()));
    }

    void mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event)
    {
        widget->show();
    }

    float getValueX()
    {
        return sliderX->value();
    }
    float getValueY()
    {
        return sliderY->value();
    }
    float getValueZ()
    {
        return sliderZ->value();
    }

    QVector3D getVector3D()
    {
        return QVector3D(getValueX(),getValueY(),getValueZ());
    }

    QTreeWidgetItem * getTreeWidgetItem(QTreeWidget * tree)
    {
        QTreeWidgetItem * item = new QTreeWidgetItem;

        item->setText(0, QString("Vector X Y Z"));

        QTreeWidgetItem * childItem = new QTreeWidgetItem(item);

        tree->setItemWidget(childItem,0,widget);

        return item;
    }


    void setMinMaxValue(float min,float max,float value)
    {
        sliderX->setMinimum(min);
        sliderX->setMaximum(max);
        sliderX->setValue(value);
        sliderX->setSingleStep(1);

        sliderY->setMinimum(min);
        sliderY->setMaximum(max);
        sliderY->setValue(value);
        sliderY->setSingleStep(1);

        sliderZ->setMinimum(min);
        sliderZ->setMaximum(max);
        sliderZ->setValue(value);
        sliderZ->setSingleStep(1);

        spinBoxX->setMinimum(min);
        spinBoxX->setMaximum(max);
        spinBoxX->setValue(value);
        spinBoxX->setSingleStep(1);

        spinBoxY->setMinimum(min);
        spinBoxY->setMaximum(max);
        spinBoxY->setValue(value);
        spinBoxY->setSingleStep(1);

        spinBoxZ->setMinimum(min);
        spinBoxZ->setMaximum(max);
        spinBoxZ->setValue(value);
        spinBoxZ->setSingleStep(1);

    }

public slots:

    void setSliderValue()
    {
       sliderX->setValue( spinBoxX->value());
       sliderY->setValue( spinBoxY->value());
       sliderZ->setValue( spinBoxZ->value());
    }

    void setSpinBoxValue()
    {
        spinBoxX->setValue(sliderX->value());
        spinBoxY->setValue(sliderY->value());
        spinBoxZ->setValue(sliderZ->value());
    }

};

class NodeVectorDeComposeItem :public NodeBaseItem
{
public:
    enum { Type = NODE_VECTORDECOMPOSE};

    int type() const  { return Type; }
    NodeVectorDeComposeItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
        addsockets();
    }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        SocketItem *a = new SocketItem(QString("X"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::OutPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("X");

        SocketItem *b = new SocketItem(QString("Y"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Y");

        SocketItem *c = new SocketItem(QString("Z"),this);

        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Z");

        outputs.append(a);
        outputs.append(b);
        outputs.append(c);


        SocketItem *d = new SocketItem(QString("Vector In"),this);
        d->setSocketType(SocketItem::InPut);
        //d->setCursor(icoCursor);
        d->setSocketDataType(NODE_VECTOR);
        d->setSocketName("Vector In");

        inputs.append(d);

        positionSockets();
        InitilizeNodeSockets();
        enableNode();
    }


    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  outputs[0];
        SocketItem * socket2 =  outputs[1];
        SocketItem * socket3 =  outputs[2];

        SocketItem * socket  =  inputs[0];

        Vector3Data *v = (Vector3Data *)socket->getSocketData();

        FloatData *f1 = new FloatData(v->data.x());
        FloatData *f2 = new FloatData(v->data.y());
        FloatData *f3 = new FloatData(v->data.z());


        socket1->setSocketData(f1);
        socket2->setSocketData(f2);
        socket3->setSocketData(f3);

        if(_debug)
        {
           printf("==>Vector DeCompose: %f,%f,%f: \n",f1->data,f2->data,f3->data);
           printf("Node executed\n");
        }
    }

};

#include <ctime>

class NodeVectorRandomItem :public NodeBaseItem
{
public:
    enum { Type = NODE_VECTORDECOMPOSE};

    int type() const  { return Type; }
    NodeVectorRandomItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
        addsockets();
    }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        SocketItem *a = new SocketItem(QString("X"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::OutPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("X");

        SocketItem *b = new SocketItem(QString("Y"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Y");

        SocketItem *c = new SocketItem(QString("Z"),this);

        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Z");

        SocketItem *d = new SocketItem(QString("Vector"),this);

        d->setSocketType(SocketItem::OutPut);
        d->setSocketDataType(NODE_VECTOR);
        d->setSocketName("Vector");


        outputs.append(a);
        outputs.append(b);
        outputs.append(c);
        outputs.append(d);


        /*
        SocketItem *d = new SocketItem(QString("Vector In"),this);
        d->setSocketType(SocketItem::InPut);
        d->setCursor(icoCursor);
        d->setSocketDataType(NODE_VECTOR);
        d->setSocketName("Vector In");

        inputs.append(d);
        */

        positionSockets();
        InitilizeNodeSockets();
        enableNode();
    }


    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  outputs[0];
        SocketItem * socket2 =  outputs[1];
        SocketItem * socket3 =  outputs[2];
        SocketItem * socket4 =  outputs[3];

        clock_t startTime = clock();

        //srand(time(0));
        srand(startTime);

        //SocketItem * socket  =  inputs[0];

        //Vector3Data *v = (Vector3Data *)socket->getSocketData();

        float x = randomFunctions::frandom(1000);
        float y = randomFunctions::frandom(1000);
        float z = randomFunctions::frandom(1000);

        FloatData *f1 = new FloatData(x);
        FloatData *f2 = new FloatData(y);
        FloatData *f3 = new FloatData(z);

        Vector3Data *f4 = new Vector3Data(x,y,z);

        socket1->setSocketData(f1);
        socket2->setSocketData(f2);
        socket3->setSocketData(f3);
        socket4->setSocketData(f4);

        if(_debug)
        {
            printf("==>Vector Random: %f,%f,%f: \n",f1->data,f2->data,f3->data);
            printf("Node executed\n");
        }
    }

};

class NodeVectorAddItem :public NodeBaseItem
{
public:
    NodeVectorAddItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
        addsockets();
    }
    enum { Type = NODE_VECTORADD};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        SocketItem *a = new SocketItem(QString("Vector A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_VECTOR);
        a->setSocketName("Vector A");
        inputs.append(a);

        SocketItem *b = new SocketItem(QString("Vector B"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_VECTOR);
        b->setSocketName("Vector B");
        inputs.append(b);


        SocketItem *c = new SocketItem(QString("Vector C"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_VECTOR);
        c->setSocketName("Vector C");

        outputs.append(c);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();
    }

    void compute()
    {

        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];

        SocketItem * socket3  =  outputs[0];

        Vector3Data *f1 = (Vector3Data *)socket1->getSocketData();
        Vector3Data *f2 = (Vector3Data *)socket2->getSocketData();



        QVector3D v = VectorAddition(f1->data , f2->data);

        //Vector3Data *f3 = new Vector3Data(v);

        QScopedPointer<Vector3Data> f3(new Vector3Data(v));

        socket3->setSocketData(f3.take());

        if(_debug)
        {

            printf("==>Vector Addition Results: %f,%f,%f: \n",f3->data.x(),f3->data.y(),f3->data.z());
            printf("Vector Add Node executed\n");

        }

    }

    QVector3D VectorAddition(QVector3D a,QVector3D b)
    {
        QVector3D v;
        v = a;
        v+= b;
        return v;
    }

};

class NodeVectorSubtractionItem :public NodeBaseItem
{
public:
    NodeVectorSubtractionItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
        addsockets();
    }
    enum { Type = NODE_VECTORSUB};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        SocketItem *a = new SocketItem(QString("Vector A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_VECTOR);
        a->setSocketName("Vector A");
        inputs.append(a);

        SocketItem *b = new SocketItem(QString("Vector B"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_VECTOR);
        b->setSocketName("Vector B");
        inputs.append(b);


        SocketItem *c = new SocketItem(QString("Vector C"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_VECTOR);
        c->setSocketName("Vector C");

        outputs.append(c);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];

        SocketItem * socket3  =  outputs[0];

        Vector3Data *f1 = (Vector3Data *)socket1->getSocketData();
        Vector3Data *f2 = (Vector3Data *)socket2->getSocketData();

        QVector3D v = VectorSubtraction(f1->data , f2->data);


        QScopedPointer<Vector3Data> f3(new Vector3Data(v));

        //Vector3Data *f3 = new Vector3Data(v);

        socket3->setSocketData(f3.take());

        if(_debug)
        {

            printf("==>Vector Subtraction Results: %f,%f,%f: \n",f3->data.x(),f3->data.y(),f3->data.z());
            printf("Vector Add Node executed\n");
        }

    }

    QVector3D VectorSubtraction(QVector3D a,QVector3D b)
    {
        QVector3D v;
        v = a;
        v-= b;
        return v;
    }

};

class NodeVectorNormalizedItem :public NodeBaseItem
{
public:
    NodeVectorNormalizedItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
        addsockets();
    }
    enum { Type = NODE_VECTORNORMALIZED};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        SocketItem *a = new SocketItem(QString("Vector A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_VECTOR);
        a->setSocketName("Vector A");
        inputs.append(a);



        SocketItem *c = new SocketItem(QString("Vector C"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_VECTOR);
        c->setSocketName("Vector C");

        outputs.append(c);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];

        SocketItem * socket3  =  outputs[0];

        Vector3Data *f1 = (Vector3Data *)socket1->getSocketData();

        QVector3D v = VectorNormalized(f1->data );

        //Vector3Data *f3 = new Vector3Data(v);
        QScopedPointer<Vector3Data> f3(new Vector3Data(v));

        socket3->setSocketData(f3.take());

        if(_debug)
        {
            printf("==>Vector Normalized Results: %f,%f,%f: \n",f3->data.x(),f3->data.y(),f3->data.z());
            printf("Vector Add Node executed\n");
        }

    }

    QVector3D VectorNormalized(QVector3D a)
    {
        float l = a.length();

        QVector3D v;

        v = a;

        v/=l;

        return v;
    }

};

class NodeVectorCrossItem :public NodeBaseItem
{
public:
    NodeVectorCrossItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
        addsockets();
    }
    enum { Type = NODE_VECTORCROSS};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        SocketItem *a = new SocketItem(QString("Vector A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_VECTOR);
        a->setSocketName("Vector A");
        inputs.append(a);

        SocketItem *b = new SocketItem(QString("Vector B"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_VECTOR);
        b->setSocketName("Vector B");
        inputs.append(b);


        SocketItem *c = new SocketItem(QString("Vector C"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_VECTOR);
        c->setSocketName("Vector C");

        outputs.append(c);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];

        SocketItem * socket3  =  outputs[0];

        Vector3Data *f1 = (Vector3Data *)socket1->getSocketData();
        Vector3Data *f2 = (Vector3Data *)socket2->getSocketData();

        QVector3D v = VectorCross(f1->data , f2->data);

        //Vector3Data *f3 = new Vector3Data(v);

        QScopedPointer<Vector3Data> f3 (new Vector3Data(v));

        socket3->setSocketData(f3.take());

        if(_debug)
        {
            printf("==>Vector Cross Results: %f,%f,%f: \n",f3->data.x(),f3->data.y(),f3->data.z());
            printf("Vector Add Node executed\n");
        }

    }

    QVector3D VectorCross(QVector3D a,QVector3D b)
    {
        return QVector3D::crossProduct(a,b);
    }

};

class NodeVectorDotItem :public NodeBaseItem
{
public:
    NodeVectorDotItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
        addsockets();
    }
    enum { Type = NODE_VECTORDOT};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        SocketItem *a = new SocketItem(QString("Vector A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_VECTOR);
        a->setSocketName("Vector A");
        inputs.append(a);

        SocketItem *b = new SocketItem(QString("Vector B"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_VECTOR);
        b->setSocketName("Vector B");
        inputs.append(b);


        SocketItem *c = new SocketItem(QString("Result"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Result");

        outputs.append(c);

        positionSockets();

        InitilizeNodeSockets();

        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];
        SocketItem * socket3  =  outputs[0];

        Vector3Data *f1 = (Vector3Data *)socket1->getSocketData();
        Vector3Data *f2 = (Vector3Data *)socket2->getSocketData();


        float v  = VectorDot(f1->data , f2->data);
        //FloatData *f3 = new FloatData(v);

        QScopedPointer< FloatData> f3(new FloatData(v));

        socket3->setSocketData(f3.take());

        if(_debug)
        {
            printf("==>Vector Dot: %f \n",f3->data);
            printf("VectorDot executed\n");
        }

    }

    float VectorDot(QVector3D a,QVector3D b)
    {
        return QVector3D::dotProduct(a,b);
    }

};

class NodeVectorDistanceItem :public NodeBaseItem
{
public:
    NodeVectorDistanceItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
        addsockets();
    }
    enum { Type = NODE_VECTORDISTANCE};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        SocketItem *a = new SocketItem(QString("Vector A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_VECTOR);
        a->setSocketName("Vector A");
        inputs.append(a);

        SocketItem *b = new SocketItem(QString("Vector B"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_VECTOR);
        b->setSocketName("Vector B");
        inputs.append(b);


        SocketItem *c = new SocketItem(QString("Result"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Result");

        outputs.append(c);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];
        SocketItem * socket3  =  outputs[0];

        Vector3Data *f1 = (Vector3Data *)socket1->getSocketData();
        Vector3Data *f2 = (Vector3Data *)socket2->getSocketData();

        float v  = VectorDistance(f1->data , f2->data);
        //FloatData *f3 = new FloatData(v);

        QScopedPointer< FloatData> f3(new FloatData(v));


        socket3->setSocketData(f3.take());

        if(_debug)
        {
            printf("==>Vector Distance: %f \n",f3->data);
            printf("VectorDot executed\n");
        }

    }

    float VectorDistance(QVector3D a,QVector3D b)
    {
        QVector3D v = (a - b);
        return v.length();
    }

};

class NodeVectorLengthItem :public NodeBaseItem
{
public:
    NodeVectorLengthItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
        addsockets();
    }

    enum { Type = NODE_VECTORLENGTH};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        SocketItem *a = new SocketItem(QString("Vector A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_VECTOR);
        a->setSocketName("Vector A");
        inputs.append(a);

        SocketItem *c = new SocketItem(QString("Result"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Result");

        outputs.append(c);

        positionSockets();

        InitilizeNodeSockets();

        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];

        SocketItem * socket3  =  outputs[0];

        Vector3Data *f1 = (Vector3Data *)socket1->getSocketData();

        float v  = VectorLength(f1->data);
        //FloatData *f3 = new FloatData(v);

        QScopedPointer< FloatData> f3(new FloatData(v));


        socket3->setSocketData(f3.take());

        if(_debug)
        {
            printf("==>Vector Length: %f \n",f3->data);
            printf("VectorDot executed\n");
        }

    }

    float VectorLength(QVector3D a)
    {
        return a.length();
    }

};

class NodeVectorScalarItem :public NodeBaseItem
{
public:
    NodeVectorScalarItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
        addsockets();
    }
    enum { Type = NODE_VECTORSCALAR};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        SocketItem *a = new SocketItem(QString("Vector A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_VECTOR);
        a->setSocketName("Vector A");
        inputs.append(a);

        SocketItem *b = new SocketItem(QString("Vector B"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Float Value");
        inputs.append(b);


        SocketItem *c = new SocketItem(QString("Vector C"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_VECTOR);
        c->setSocketName("Vector C");

        outputs.append(c);

        positionSockets();
        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];

        SocketItem * socket3  =  outputs[0];

        Vector3Data *f1 = (Vector3Data *)socket1->getSocketData();
        FloatData *f2 = (FloatData *)socket2->getSocketData();

        QVector3D v = VectorScalar(f1->data , f2->data);

        //Vector3Data *f3 = new Vector3Data(v);

        QScopedPointer< Vector3Data> f3(new Vector3Data(v));

        socket3->setSocketData(f3.take());

        if(_debug)
        {
            printf("==>Vector Scalar Results: %f,%f,%f: \n",f3->data.x(),f3->data.y(),f3->data.z());
            printf("Vector Add Node executed\n");
        }

    }

    QVector3D VectorScalar(QVector3D a,float b)
    {
        return b*a;
    }

};

/*
    NODE_FLOAT_PI,
    NODE_FLOAT_E,
    NODE_FLOAT_VALUE,
    NODE_FLOAT_RANDOM,
*/

class NodeFloatItem : public NodeBaseItem
{
    Q_OBJECT

    QSlider * slider;
    QSpinBox* spinBox;

public:

    QWidget * getWidget()
    {
        return widget;
    }

    QTreeWidgetItem * getTreeWidgetItem(QTreeWidget * tree)
    {
        QTreeWidgetItem * item = new QTreeWidgetItem;

        item->setText(0, QString("Float Value"));

        QTreeWidgetItem * childItem = new QTreeWidgetItem(item);

        tree->setItemWidget(childItem,0,widget);

        return item;
    }


    NodeFloatItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
        addsockets();
        addWidgets();
    }

    ~NodeFloatItem()
    {
        delete widget;
        delete spinBox;
        delete slider;
    }

    enum { Type = NODE_FLOAT_VALUE};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        /*
        SocketItem *a = new SocketItem(QString("Value"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);
        */


        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket  =  outputs[0];

        //qDebug()<<"FLoat Value:"<<slider->value();

        //MultiDataType * v =  new  FloatData(slider->value());

        QScopedPointer< MultiDataType> f3(new FloatData(slider->value()));

        socket->setSocketData(f3.take());

        //socket->setSocketData(v);

        //FloatData *u = (FloatData*)v;

        FloatData *u = (FloatData*)f3.data();
        if(_debug)
        {
            printf("==>Float Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }

    void addWidgets()
    {
        //itemWidget->setWindowFlags(Qt::FramelessWindowHint);
        //itemWidget->setAttribute(Qt::WA_NoSystemBackground);
        //itemWidget->setAttribute(Qt::WA_TranslucentBackground);
        //itemWidget->setAttribute(Qt::WA_PaintOnScreen);
        //itemWidget->setAttribute(Qt::WA_TransparentForMouseEvents);

        widget  = new QWidget;
        slider  = new QSlider(Qt::Horizontal);
        spinBox = new QSpinBox();

        setMinMaxValue(-1000,1000,0);

        QHBoxLayout * layout =  new QHBoxLayout;

        layout->addWidget(new QLabel("Float Value:"));
        layout->addWidget(spinBox);
        layout->addWidget(slider);

        widget->setLayout(layout);

        widget->setWindowTitle(QString("Float Value"));

        widget->setBaseSize(100,20);
        QFile file(":/glowBlue.stylesheet");


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QByteArray  style =file.readAll();
            widget->setStyleSheet(style);
            file.close();
        }

        connect(slider,SIGNAL(valueChanged(int)),this,SLOT(setSpinBoxValue()));
        connect(spinBox,SIGNAL(valueChanged(int)),this,SLOT(setSliderValue()));

    }

    void mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event)
    {
        widget->show();
    }



    float getValue()
    {
        return slider->value();
    }


    void setMinMaxValue(float min,float max,float value)
    {
        slider->setMinimum(min);
        slider->setMaximum(max);
        slider->setValue(value);
        slider->setSingleStep(1);

        spinBox->setMinimum(min);
        spinBox->setMaximum(max);
        spinBox->setValue(value);
        spinBox->setSingleStep(1);

    }

public slots:

    void setSliderValue()
    {
       slider->setValue( spinBox->value());
    }

    void setSpinBoxValue()
    {
        spinBox->setValue(slider->value());
    }
};

class NodeFloatPIEItem :public NodeBaseItem
{
public:
    NodeFloatPIEItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_FLOAT_PIE};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        /*
        SocketItem *a = new SocketItem(QString("Value"),this);
        a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);
        */


        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        //SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        //FloatData *f1 = (FloatData *)socket1->getSocketData();
        //MultiDataType * v =  new  FloatData(f1->data);
        //MultiDataType * v =  new  FloatData((float)M_PI);

        QScopedPointer<MultiDataType>  v(new  FloatData((float)M_PI));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat PIE Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }

    }

};

class NodeFloatEItem :public NodeBaseItem
{
public:
    NodeFloatEItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_FLOAT_E};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        /*
        SocketItem *a = new SocketItem(QString("Value"),this);
        a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);
        */


        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        //SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        //eulers constant

        float e = 2.718281828459f;

        //FloatData *f1 = (FloatData *)socket1->getSocketData();
        //MultiDataType * v =  new  FloatData(f1->data);
        //MultiDataType * v =  new  FloatData(e);
        QScopedPointer<  MultiDataType > v(new  FloatData(e));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();


        if(_debug)
        {
            printf("==>Euler's' Constant E Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }

    }

};

class NodeFloatRandomItem :public NodeBaseItem
{
public:
    NodeFloatRandomItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_FLOAT_RANDOM};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        /*
        SocketItem *a = new SocketItem(QString("Value"),this);
        a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);
        */


        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        //SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        clock_t startTime = clock();

        //srand(time(0));
        srand(startTime);

        //random constant

        float c = randomFunctions::frandom(1000);

        //FloatData *f1 = (FloatData *)socket1->getSocketData();
        //MultiDataType * v =  new  FloatData(f1->data);
        //MultiDataType * v =  new  FloatData(c);

        QScopedPointer<MultiDataType> v( new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat Random Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }

    }

};

/*
    NODE_FLOAT_ADD,
    NODE_FLOAT_MULTIPLY,
    NODE_FLOAT_SUBTRACT,
    NODE_FLOAT_DIVIDE,
*/

class NodeFloatAddItem :public NodeBaseItem
{
public:
    NodeFloatAddItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_FLOAT_ADD};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Float A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float A");
        inputs.append(a);

        SocketItem *b = new SocketItem(QString("Float B"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Float B");
        inputs.append(b);



        SocketItem *c = new SocketItem(QString("Result"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Result");

        outputs.append(c);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];

        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();
        FloatData *f2 = (FloatData *)socket2->getSocketData();

        float c =  f1->data + f2->data;
        //MultiDataType * v =  new  FloatData(c);

        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>Float Addition Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }


};

class NodeFloatSubItem :public NodeBaseItem
{
public:
    NodeFloatSubItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_FLOAT_SUBTRACT};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Float A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float A");
        inputs.append(a);

        SocketItem *b = new SocketItem(QString("Float B"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Float B");
        inputs.append(b);



        SocketItem *c = new SocketItem(QString("Result"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Result");

        outputs.append(c);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];

        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();
        FloatData *f2 = (FloatData *)socket2->getSocketData();

        float c =  f1->data - f2->data;
        //MultiDataType * v =  new  FloatData(c);

        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();


        if(_debug)
        {
            printf("==>FLoat Subtractions Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};

class NodeFloatMultiplyItem :public NodeBaseItem
{
public:
    NodeFloatMultiplyItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_FLOAT_MULTIPLY};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Float A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float A");
        inputs.append(a);

        SocketItem *b = new SocketItem(QString("Float B"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Float B");
        inputs.append(b);



        SocketItem *c = new SocketItem(QString("Result"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Result");

        outputs.append(c);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];

        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();
        FloatData *f2 = (FloatData *)socket2->getSocketData();

        float c =  f1->data * f2->data;

        QScopedPointer<MultiDataType> v(new  FloatData(c));
       // MultiDataType * v =  new  FloatData(c);

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>Float Multiply Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};

class NodeFloatDivideItem :public NodeBaseItem
{
public:
    NodeFloatDivideItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_FLOAT_DIVIDE};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Float A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float A");
        inputs.append(a);

        SocketItem *b = new SocketItem(QString("Float B"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Float B");
        inputs.append(b);



        SocketItem *c = new SocketItem(QString("Result"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Result");

        outputs.append(c);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];

        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();
        FloatData *f2 = (FloatData *)socket2->getSocketData();

        float denominator = f2->data;

        if(denominator==0)
            denominator = 1;

        float c =  f1->data / denominator;

        //MultiDataType * v =  new  FloatData(c);
        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat Divide Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};





/*
    NODE_MATH_COS,
    NODE_MATH_SIN,
    NODE_MATH_TAN,
    NODE_MATH_ACOS,
    NODE_MATH_ASIN,
    NODE_MATH_ATAN,

    NODE_MATH_LOG,
    NODE_MATH_LOGE,
    NODE_MATH_POW,
    NODE_MATH_SQRT,
    NODE_MATH_ABS,
    NODE_MATH_FLOOR,
    NODE_MATH_CEIL,
    NODE_MATH_ROUND,
*/

class NodeMathCosItem :public NodeBaseItem
{
public:
    NodeMathCosItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_MATH_COS};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Value"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);



        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();

        float c =  (float)cos(f1->data);
        //MultiDataType * v =  new  FloatData(c);
        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat cos Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};

class NodeMathSinItem :public NodeBaseItem
{
public:
    NodeMathSinItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_MATH_SIN};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Value"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);



        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();

        float c =  (float)sin(f1->data);
        //MultiDataType * v =  new  FloatData(c);

        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat sin Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};

class NodeMathTanItem :public NodeBaseItem
{
public:
    NodeMathTanItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_MATH_TAN};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Value"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);



        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();

        float c =  (float)tan(f1->data);
        //MultiDataType * v =  new  FloatData(c);
        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat Tan Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};

class NodeMathACosItem :public NodeBaseItem
{
public:
    NodeMathACosItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_MATH_ACOS};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Value"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);



        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();

        float c =  (float)acos(f1->data);
        //MultiDataType * v =  new  FloatData(c);
        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat acos Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};

class NodeMathASinItem :public NodeBaseItem
{
public:
    NodeMathASinItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_MATH_ASIN};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Value"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);



        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();

        float c =  (float)asin(f1->data);
        //MultiDataType * v =  new  FloatData(c);
        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat asin Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};

class NodeMathATanItem :public NodeBaseItem
{
public:
    NodeMathATanItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_MATH_ATAN};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Value"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);



        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();

        float c =  (float)atan(f1->data);
        //MultiDataType * v =  new  FloatData(c);
        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat Tan Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};

class NodeMathLogItem :public NodeBaseItem
{
public:
    NodeMathLogItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_MATH_LOG};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Value"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);



        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();

        float c =  (float)log(f1->data);
        //MultiDataType * v =  new  FloatData(c);
        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat cos Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};

class NodeMathPowItem : public NodeBaseItem
{
public:
    NodeMathPowItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_MATH_POW};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Value A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);


        SocketItem *b = new SocketItem(QString("Exponent"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Exponent");
        inputs.append(b);



        SocketItem *c = new SocketItem(QString("Result"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Result");

        outputs.append(c);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];

        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();
        FloatData *f2 = (FloatData *)socket2->getSocketData();

        float c =  (float)pow(f1->data,f2->data);
        //MultiDataType * v =  new  FloatData(c);
        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat pow Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};

class NodeMathSqrtItem :public NodeBaseItem
{
public:
    NodeMathSqrtItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_MATH_SQRT};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Value"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);



        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();

        float c =  (float)sqrt(f1->data);
        //MultiDataType * v =  new  FloatData(c);
        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat Sqrt Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};

class NodeMathAbsItem :public NodeBaseItem
{
public:
    NodeMathAbsItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_MATH_ABS};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Value"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);



        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();

        float c =  (float)fabs(f1->data);
        //MultiDataType * v =  new  FloatData(c);
        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>Float abs Node: %f \n",u->data);
            printf("FLoat Node executed\n");

        }
    }
};

class NodeMathFloorItem :public NodeBaseItem
{
public:
    NodeMathFloorItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_MATH_FLOOR};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Value"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);



        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();

        float c =  (float)floor(f1->data);
        //MultiDataType * v =  new  FloatData(c);
        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat floor Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};

class NodeMathCeilItem :public NodeBaseItem
{
public:
    NodeMathCeilItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_MATH_CEIL};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Value"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);



        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();

        float c =  (float)ceil(f1->data);
        //MultiDataType * v =  new  FloatData(c);
        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat ceil Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};

class NodeMathRoundItem :public NodeBaseItem
{
public:
    NodeMathRoundItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_MATH_ROUND};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Value"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);



        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();

        float c =  (float)round(f1->data);
        //MultiDataType * v =  new  FloatData(c);
        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat round Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};

class NodeMathExpItem :public NodeBaseItem
{
public:
    NodeMathExpItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_MATH_EXP};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Value"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);



        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();

        float c =  (float)exp(f1->data);
        //MultiDataType * v =  new  FloatData(c);
        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat exp Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }

};

class NodeMathModulusItem :public NodeBaseItem
{
public:
    NodeMathModulusItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_MATH_MODULUS};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Value A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);

        SocketItem *b= new SocketItem(QString("Value B"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Float Value");
        inputs.append(b);



        SocketItem *c = new SocketItem(QString("Result"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Result");

        outputs.append(c);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];

        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();
        FloatData *f2 = (FloatData *)socket2->getSocketData();

        float c =  (float)fmod(f1->data,f2->data);
        //MultiDataType * v =  new  FloatData(c);

        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat modulus Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};

class NodeMathCosHItem :public NodeBaseItem
{
public:
    NodeMathCosHItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_MATH_COSH};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Value"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);



        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();

        float c =  (float)cosh(f1->data);
        //MultiDataType * v =  new  FloatData(c);
        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat cosh Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};

class NodeMathSinHItem :public NodeBaseItem
{
public:
    NodeMathSinHItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_MATH_SINH};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Value"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);



        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();

        float c =  (float)sinh(f1->data);
        //MultiDataType * v =  new  FloatData(c);
        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat sinh Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};

class NodeMathTanHItem :public NodeBaseItem
{
public:
    NodeMathTanHItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_MATH_TANH};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        SocketItem *a = new SocketItem(QString("Value"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value");
        inputs.append(a);



        SocketItem *b = new SocketItem(QString("Result"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Result");

        outputs.append(b);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        FloatData *f1 = (FloatData *)socket1->getSocketData();

        float c =  (float)tanh(f1->data);
        //MultiDataType * v =  new  FloatData(c);
        QScopedPointer<MultiDataType> v(new  FloatData(c));

        socket->setSocketData(v.take());

        FloatData *u = (FloatData*)v.data();

        if(_debug)
        {
            printf("==>FLoat Tanh Node: %f \n",u->data);
            printf("FLoat Node executed\n");
        }
    }
};

/*
NODE_VALUE_EQUAL,
NODE_VALUE_LESSTHAN,
NODE_VALUE_GREATERTHAN,
NODE_VALUE_GREATER_OR_EQUAL,
NODE_VALUE_LESS_OR_EQUAL,

*/

class NodeValueEqualItem :public NodeBaseItem
{
public:
    NodeValueEqualItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_VALUE_EQUAL};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Float Value A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value A");
        inputs.append(a);


        SocketItem *b = new SocketItem(QString("Float Value B"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Float Value B");
        inputs.append(b);



        /*
        SocketItem *c = new SocketItem(QString("Result"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Result");
        */


        SocketItem *d = new SocketItem(QString("bool Result"),this);
        //c->setCursor(icoCursor);
        d->setSocketType(SocketItem::OutPut);
        d->setSocketDataType(NODE_BOOL);
        d->setSocketName("bool Result");

        //outputs.append(c);
        outputs.append(d);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];

        SocketItem * socket  =  outputs[0];
        //SocketItem * socket3  =  outputs[1];

        FloatData *f1 = (FloatData *)socket1->getSocketData();
        FloatData *f2 = (FloatData *)socket2->getSocketData();




        if(f1->data==f2->data)
        {
            //b =  new BoolData(true);

            QScopedPointer<MultiDataType> v(new  BoolData(true));
            socket->setSocketData(v.take());

            BoolData *b = (BoolData *)v.data();

            if(_debug)
            {
                //printf("Node A == B Node: % \n",qPrintable(b->data));
                printf("FLoat Node executed\n");
            }

        }
        else
        {
             //b =  new BoolData(false);

             QScopedPointer<MultiDataType> v(new  BoolData(false));
             socket->setSocketData(v.take());

             BoolData *b = (BoolData *)v.data();

             if(_debug)
             {
                 //printf("Node A == B Node: % \n",qPrintable(b->data));
                 printf("FLoat Node executed\n");
             }

        }

        //socket->setSocketData(b);
        //socket3->setSocketData(b);


    }
};

class NodeValueLessThanItem :public NodeBaseItem
{
public:
    NodeValueLessThanItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_VALUE_LESSTHAN};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Float Value A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value A");
        inputs.append(a);


        SocketItem *b = new SocketItem(QString("Float Value B"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Float Value B");
        inputs.append(b);




        SocketItem *c = new SocketItem(QString("Result"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Result");



        SocketItem *d = new SocketItem(QString("bool Result"),this);
        //c->setCursor(icoCursor);
        d->setSocketType(SocketItem::OutPut);
        d->setSocketDataType(NODE_BOOL);
        d->setSocketName("bool Result");

        outputs.append(c);
        outputs.append(d);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];

        SocketItem * socket  =  outputs[0];
        SocketItem * socket3  =  outputs[1];

        FloatData *f1 = (FloatData *)socket1->getSocketData();
        FloatData *f2 = (FloatData *)socket2->getSocketData();


        if(f1->data<f2->data)
        {
            //BoolData *b;
            //FloatData *f3;

            //b =  new BoolData(true);
            //f3 = new FloatData(f1->data);

            QScopedPointer<MultiDataType> b(new BoolData(true));
            QScopedPointer<MultiDataType> f3(new FloatData(f1->data));

            socket->setSocketData(f3.take());
            socket3->setSocketData(b.take());

            if(_debug)
            {
                BoolData *v = (BoolData *)b.data();
                //printf("Node A < B Node: % \n",qPrintable(v->data));
                printf("FLoat Node executed\n");
            }

        }
        else
        {
            //BoolData *b;
           // FloatData *f3;

             //b =  new BoolData(false);
             //f3 = new FloatData(f2->data);

             //socket->setSocketData(f3);
             //socket3->setSocketData(b);

            QScopedPointer<MultiDataType> b(new BoolData(false));
            QScopedPointer<MultiDataType> f3(new FloatData(f1->data));

            socket->setSocketData(f3.take());
            socket3->setSocketData(b.take());

             if(_debug)
             {
                 BoolData *v = (BoolData *)b.data();
                 //printf("Node A < B Node: % \n",qPrintable(v->data));
                 printf("FLoat Node executed\n");
             }

        }


    }
};


class NodeValueGreaterThanItem :public NodeBaseItem
{
public:
    NodeValueGreaterThanItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_VALUE_GREATERTHAN};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Float Value A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value A");
        inputs.append(a);


        SocketItem *b = new SocketItem(QString("Float Value B"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Float Value B");
        inputs.append(b);




        SocketItem *c = new SocketItem(QString("Result"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Result");



        SocketItem *d = new SocketItem(QString("bool Result"),this);
        //c->setCursor(icoCursor);
        d->setSocketType(SocketItem::OutPut);
        d->setSocketDataType(NODE_BOOL);
        d->setSocketName("bool Result");

        outputs.append(c);
        outputs.append(d);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];

        SocketItem * socket  =  outputs[0];
        SocketItem * socket3  =  outputs[1];

        FloatData *f1 = (FloatData *)socket1->getSocketData();
        FloatData *f2 = (FloatData *)socket2->getSocketData();




        if(f1->data>f2->data)
        {
           // BoolData *b;
           // FloatData *f3;

           // b =  new BoolData(true);
           // f3 = new FloatData(f1->data);

            QScopedPointer<MultiDataType> b(new BoolData(true));
            QScopedPointer<MultiDataType> f3(new FloatData(f1->data));

            socket->setSocketData(f3.take());
            socket3->setSocketData(b.take());

            if(_debug)
            {
                BoolData *v = (BoolData *)b.data();
                //printf("Node A > B Node: % \n",qPrintable(v->data));
                printf("FLoat Node executed\n");
            }

        }
        else
        {
            //BoolData *b;
           // FloatData *f3;

             //b =  new BoolData(false);
             //f3 = new FloatData(f2->data);

            QScopedPointer<MultiDataType> b(new BoolData(false));
            QScopedPointer<MultiDataType> f3(new FloatData(f1->data));

             socket->setSocketData(f3.take());
             socket3->setSocketData(b.take());

             if(_debug)
             {
                 BoolData *v = (BoolData *)b.data();
                 //printf("Node A > B Node: % \n",qPrintable(v->data));
                 printf("FLoat Node executed\n");
             }
        }
    }
};


class NodeValueGreaterOrEqualItem :public NodeBaseItem
{
public:
    NodeValueGreaterOrEqualItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_VALUE_GREATER_OR_EQUAL};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Float Value A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value A");
        inputs.append(a);


        SocketItem *b = new SocketItem(QString("Float Value B"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Float Value B");
        inputs.append(b);




        SocketItem *c = new SocketItem(QString("Result"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Result");



        SocketItem *d = new SocketItem(QString("bool Result"),this);
        //c->setCursor(icoCursor);
        d->setSocketType(SocketItem::OutPut);
        d->setSocketDataType(NODE_BOOL);
        d->setSocketName("bool Result");

        outputs.append(c);
        outputs.append(d);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];

        SocketItem * socket  =  outputs[0];
        SocketItem * socket3  =  outputs[1];

        FloatData *f1 = (FloatData *)socket1->getSocketData();
        FloatData *f2 = (FloatData *)socket2->getSocketData();


        //BoolData *b;
        //FloatData *f3;

        if(f1->data>=f2->data)
        {
            //b =  new BoolData(true);
            //f3 = new FloatData(f1->data);
            // BoolData *b;
            // FloatData *f3;

            // b =  new BoolData(true);
            // f3 = new FloatData(f1->data);

             QScopedPointer<MultiDataType> b(new BoolData(true));
             QScopedPointer<MultiDataType> f3(new FloatData(f1->data));

             socket->setSocketData(f3.take());
             socket3->setSocketData(b.take());

             if(_debug)
             {
                 BoolData *v = (BoolData *)b.data();
                 //printf("Node A >= B Node: % \n",qPrintable(v->data));
                 printf("FLoat Node executed\n");
             }

        }
        else
        {
             //b =  new BoolData(false);
             //f3 = new FloatData(f2->data);
            // BoolData *b;
            // FloatData *f3;

            // b =  new BoolData(true);
            // f3 = new FloatData(f1->data);

             QScopedPointer<MultiDataType> b(new BoolData(false));
             QScopedPointer<MultiDataType> f3(new FloatData(f1->data));

             socket->setSocketData(f3.take());
             socket3->setSocketData(b.take());

             if(_debug)
             {
                 BoolData *v = (BoolData *)b.data();
                 //printf("Node A >= B Node: % \n",qPrintable(v->data));
                 printf("FLoat Node executed\n");
             }

        }

        //socket->setSocketData(f3);
        //socket3->setSocketData(b);

        //if(_debug)
        //{
         //   printf("Node A >= B Node: % \n",qPrintable(b->data));
         //   printf("FLoat Node executed\n");
        //}
    }
};


class NodeValueLessOrEqualItem :public NodeBaseItem
{
public:
    NodeValueLessOrEqualItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_VALUE_LESS_OR_EQUAL};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Float Value A"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Float Value A");
        inputs.append(a);


        SocketItem *b = new SocketItem(QString("Float Value B"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_FLOAT);
        b->setSocketName("Float Value B");
        inputs.append(b);




        SocketItem *c = new SocketItem(QString("Result"),this);
        //c->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Result");



        SocketItem *d = new SocketItem(QString("bool Result"),this);
        //c->setCursor(icoCursor);
        d->setSocketType(SocketItem::OutPut);
        d->setSocketDataType(NODE_BOOL);
        d->setSocketName("bool Result");

        outputs.append(c);
        outputs.append(d);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];

        SocketItem * socket  =  outputs[0];
        SocketItem * socket3  =  outputs[1];

        FloatData *f1 = (FloatData *)socket1->getSocketData();
        FloatData *f2 = (FloatData *)socket2->getSocketData();


        //BoolData *b;
        //FloatData *f3;

        if(f1->data<=f2->data)
        {
            //b =  new BoolData(true);
            //f3 = new FloatData(f1->data);

            // BoolData *b;
            // FloatData *f3;

            // b =  new BoolData(true);
            // f3 = new FloatData(f1->data);

             QScopedPointer<MultiDataType> b(new BoolData(true));
             QScopedPointer<MultiDataType> f3(new FloatData(f1->data));

             socket->setSocketData(f3.take());
             socket3->setSocketData(b.take());

             if(_debug)
             {
                 BoolData *v = (BoolData *)b.data();
                 //printf("Node A  <=  B Node: % \n",qPrintable(v->data));
                 printf("FLoat Node executed\n");
             }

        }
        else
        {
             //b =  new BoolData(false);
             //f3 = new FloatData(f2->data);

            // BoolData *b;
            // FloatData *f3;

            // b =  new BoolData(true);
            // f3 = new FloatData(f1->data);

             QScopedPointer<MultiDataType> b(new BoolData(true));
             QScopedPointer<MultiDataType> f3(new FloatData(f1->data));

             socket->setSocketData(f3.take());
             socket3->setSocketData(b.take());

             if(_debug)
             {
                 BoolData *v = (BoolData *)b.data();
                 //printf("Node A  <=  B Node: % \n",qPrintable(v->data));
                 printf("FLoat Node executed\n");
             }

        }

        //socket->setSocketData(f3);
        //socket3->setSocketData(b);

        //if(_debug)
        //{
        //    printf("Node A <= B Node: % \n",qPrintable(b->data));
        //    printf("FLoat Node executed\n");
        //}
    }
};




/*
NODE_SOCKET_PREVIEW
NODE_TIME
*/


class NodeTimeItem :public NodeBaseItem
{
    Q_OBJECT
public:

    NodeTimeItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();

       frame = -1;
    }

    enum { Type = NODE_TIME};

    int type() const  { return Type; }

private slots:

    void advanceFrame()
    {
        frame += 1;
    }

public:

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        /*

        SocketItem *a = new SocketItem(QString("Data"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_FLOAT);
        a->setSocketName("Interval");
        inputs.append(a);

        SocketItem *b = new SocketItem(QString("Data"),this);
        //a->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_INT);
        b->setSocketName("Frame Rate");
        inputs.append(b);
        */



        SocketItem *c = new SocketItem(QString("Frame"),this);
        //b->setCursor(icoCursor);
        c->setSocketType(SocketItem::OutPut);
        c->setSocketDataType(NODE_FLOAT);
        c->setSocketName("Frame");

        /*
        SocketItem *d = new SocketItem(QString("Seconds"),this);
        //b->setCursor(icoCursor);
        d->setSocketType(SocketItem::OutPut);
        d->setSocketDataType(NODE_INT);
        d->setSocketName("Seconds");
        */


        outputs.append(c);
        //outputs.append(d);

        positionSockets();
        InitilizeNodeSockets();
        enableNode();

        //computeBounds();
    }

    void compute()
    {
        advanceFrame();

        using namespace _NodeTypes;

        /*


        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];
        */


        SocketItem * socket   =  outputs[0];
        //SocketItem * socket3  =  outputs[1];

        /*
        FloatData *f1 = (FloatData *)socket1->getSocketData();
        IntData *f2   = (IntData *)socket2->getSocketData();
        */

        //IntData *_frame = new IntData((float)frame);
        //FloatData *_frame = new FloatData((float)frame);

        QScopedPointer<MultiDataType> out(new FloatData((float)frame));


        //IntData *seconds = new IntData(frame*);
        socket->setSocketData(out.take());
        //socket3->setSocketData();


        //StringData *u = (StringData*)v;

        if(_debug)
        {
            FloatData *_frame = (FloatData *)out.data();

            printf("Current Frame: %f \n",_frame->data);
            printf("Node Current executed\n");
        }
    }
};

class NodeSocketPreviewItem :public NodeBaseItem
{
public:
    NodeSocketPreviewItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_SOCKET_PREVIEW};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));

        SocketItem *a = new SocketItem(QString("Data"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_MULTI_DATA_TYPE);
        a->setSocketName("Data");
        inputs.append(a);



        SocketItem *b = new SocketItem(QString("String"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::OutPut);
        b->setSocketDataType(NODE_STRING);
        b->setSocketName("String");

        outputs.append(b);



        frameRect.setWidth(150);



        positionSockets();
        InitilizeNodeSockets();
        enableNode();

        frameRect.setHeight(120);
        computeBounds();


    }

    void compute()
    {
        using namespace _NodeTypes;


        SocketItem * socket1 =  inputs[0];
        SocketItem * socket  =  outputs[0];

        MultiData *f1 = (MultiData *)socket1->getSocketData();

       //f1->Type

        //MultiDataType * v =  new  StringData(f1->getString());

        QScopedPointer<MultiDataType> v(new  StringData(f1->getString()));

        socket->setSocketData(v.take());




        StringData *u = (StringData*)v.data();

        if(_debug)
        {
            //printf("==>Node Socket Preview: %s \n",u->data);
            printf("Node Socket Preview executed\n");
        }

    }



    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
    {
        Q_UNUSED(option);
        Q_UNUSED(widget);

        painter->setRenderHint(QPainter::Antialiasing);

        if(this->isSelected())
        {
            painter->save();
            QPen pen;
            pen.setWidth(1);
            pen.setStyle(Qt::DashLine);

            painter->setPen(pen);
            painter->setBrush(QBrush(Qt::NoBrush));
            painter->drawRect(selectionRect);//boundingRect());
            painter->restore();
        }

        painter->setPen(Qt::NoPen);
        //setBrush(QBrush(QColor(frandom(100)*255,frandom(100)*255,frandom(100)*255,255)));//QtCore.Qt.cyan))

        float roundingX = 6;

        float roundingY = 6 * this->frameRect.width()/this->frameRect.height();

        painter->setBrush(*brush);
        //painter->drawRoundRect(this->boundingRect(),roundingX,roundingY);
        painter->drawRoundRect(frameRect,roundingX,roundingY);


        painter->setPen(QPen(Qt::black, 1));
        //painter->setBrush(QBrush(color));
        //painter->drawRoundRect(this->boundingRect(),roundingX,roundingY);
        painter->drawRoundRect(frameRect,roundingX,roundingY);

        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        MultiDataType *f1 = (MultiDataType *)socket1->getSocketData();



        QRectF r =  frameRect;

        //r.translate(10,r.height()/2);
        r.translate(15,75);
        painter->drawText(r,f1->getString());
    }
};


/*
    NODE_DESCRIPTION_NOTE
    NODE_GROUP
*/
#include<QGraphicsSvgItem>

class NodeShapeIcon : public QGraphicsRectItem
{
    bool _debug = false;
    bool _svg  = false;

    QGraphicsSvgItem *svg;
public:

    void setDebug(bool print = false)
    {
        _debug =  print;
    }

    NodeShapeIcon( QGraphicsItem * parent = 0 ):QGraphicsRectItem(parent)
    {
        setRect(QRectF(0,0,15, 15));
        setToolTip(QString("Drag to resize node"));
        setAcceptHoverEvents(true);

        svg =  new QGraphicsSvgItem(":/cornericon.svg");
        if(_svg)
            svg->setParentItem(this);

        float scale = 2*(15/svg->boundingRect().height());

        svg->setScale(scale);
        svg->setPos(this->scenePos());

    }

    QPainterPath  shape() //usefull for shape selection
    {
        QPainterPath p;
        p.addRoundRect(this->boundingRect(),5,5);
        return p;
    }

    QRectF boundingRect()
    {
         return QRectF(0,0,15, 15);//QRectF(-7.5,-7.5,15, 15)
    }

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
    {
        QPen pen;
        pen.setColor(QColor(0,0,0));
        painter->setPen(pen);
        painter->setOpacity(0.9);
        //painter->drawRect(boundingRect());

        if(_svg)
        {



        }
        else
        {
            painter->drawRoundedRect(boundingRect(), 5, 5, Qt::RelativeSize);
            painter->drawLine(QPoint(2, 3), QPoint(13, 3));
            painter->drawLine(QPoint(2, 6), QPoint(13, 6));
            painter->drawLine(QPoint(2, 9), QPoint(13, 9));
            painter->drawLine(QPoint(2, 12), QPoint(13, 12));
        }


        setCursor(Qt::SizeAllCursor);
    }

    void hoverEnterEvent(QGraphicsSceneHoverEvent *event)
    {
        if(parentItem())
        {
            this->parentItem()->setFlag(ItemIsMovable,false);
            setFlag(ItemIsMovable,true);

        }
        if(_debug)printf("hover enter\n");
        QGraphicsRectItem::hoverEnterEvent(event);

    }




    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
    {
        if(parentItem())
        {
            this->parentItem()->setFlag(ItemIsMovable,true);
            setFlag(ItemIsMovable,false);
            //positionHandle();


        }
        if(_debug)printf("hover leave\n");
        QGraphicsRectItem::hoverLeaveEvent(event);

    }

    QVariant itemChange(GraphicsItemChange change, const QVariant &value)
    {
        if(parentItem())
        {
            resizeParent();


        }

        return QGraphicsRectItem::itemChange(change,value);
    }

    void resizeParent()
    {
        NodeBaseItem * item  = (NodeBaseItem *)parentItem();

        QRectF frameRect = item->getFrameRect();

        QPointF p0 = item->scenePos();
        QPointF p2 = this->scenePos();

        QPointF delta = p2 - p0;

        if(delta.x()<140)
            this->setX(140);
        if(delta.y()<50)
            this->setY(50);

        update();

        delta += QPointF(item->getMargin(),item->getMargin());

        frameRect.setWidth(delta.x() );
        frameRect.setHeight(delta.y());

        item->setFrameRect(frameRect);
        item->computeBounds();        

        item->update();
    }
};



class EditableTextItem:   public QGraphicsTextItem
{
    //QGraphicsRectItem * plate;
    //Q_OBJECT

public:
    //enum { Type = UserType + 3 };

    EditableTextItem(QGraphicsItem *parent = 0):QGraphicsTextItem(parent)
    {
        //plate = new QGraphicsRectItem;
       // plate->setRect(this->boundingRect());
        this->setParentItem(this);
        //setFlag(QGraphicsItem::ItemIsMovable);
        setFlag(QGraphicsItem::ItemIsSelectable);
        setFlag(ItemIsFocusable);

        setPlainText(QString("Give you a peek at the fragment shader for one of the processing stages. Like I said earlier, these shaders are mathematically simple on their own. I bet most of the performance cost is in the texture lookups, not the math. Here�s the shader for the Advect stage:"));

    }


protected:
    QVariant itemChange(GraphicsItemChange change, const QVariant &value)
    {
        if(parentItem())
        {
            /*
            QGraphicsItem * item =  (QGraphicsItem*)parentItem();
            setTextWidth(item->boundingRect().width()-20);

            setPos(QPointF(10,20));
            */

        }
        if (change == QGraphicsItem::ItemSelectedHasChanged)
        {

           // emit selectedChange(this);
        }
        return value;
    }

    void focusOutEvent(QFocusEvent *event)
    {
        setTextInteractionFlags(Qt::NoTextInteraction);
        {
        //emit lostFocus(this);
        }
        QGraphicsTextItem::focusOutEvent(event);
    }

    void mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event)
    {

        if (textInteractionFlags() == Qt::NoTextInteraction)
        {
            setTextInteractionFlags(Qt::TextEditorInteraction);

        }
        QGraphicsTextItem::mouseDoubleClickEvent(event);

    }

};




class NodeDescriptionNoteItem : public NodeBaseItem
{
public:
    enum { Type = NODE_DESCRIPTION_NOTE};

    int type() const  { return Type; }


    EditableTextItem * textDescritpion;
    NodeShapeIcon * handle;

    NodeDescriptionNoteItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
        textDescritpion = new EditableTextItem;
        textDescritpion->setParentItem(this);

        textDescritpion->setTextWidth(this->frameRect.width()-20);

        textDescritpion->setPos(QPointF(10,20));


        handle = new NodeShapeIcon;
        handle->setParentItem(this);
        //handle->setPos(this->pos().x()+ frameRect.width() - margin, this->pos().y()+frameRect.height()-margin);

        handle->setFlag(ItemIsSelectable,false);
        handle->setFlag(ItemIsMovable,false);

        disableNode();
    }



    QVariant itemChange(GraphicsItemChange change, const QVariant &value)
    {
        textDescritpion->setPos(QPointF(10,20));
        textDescritpion->setTextWidth(this->frameRect.width()-20);
        textDescritpion->update();

        /*

        QRectF r = textDescritpion->boundingRect();
        setFrameRect(r);
        computeBounds();
        update();
        */

        return QGraphicsItem::itemChange(change,value);
    }



    void addsockets()
    {
        removeSockets();

    }

    void compute()
    {

    }

};

/*
    NODE_LANG_IF,
    NODE_LANG_IFELSE,
    NODE_LANG_FOR,
    NODE_LANG_FOREACH,
    NODE_LANG_SWITCH,
    NODE_LANG_WHILE,
    NODE_LANG_DOWHILE,
    NODE_COLLECTION,

*/

class NodeIFlItem :public NodeBaseItem
{
public:
    NodeIFlItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
       addsockets();
    }

    enum { Type = NODE_LANG_IF};

    int type() const  { return Type; }

    void addsockets()
    {
        removeSockets();

        QCursor icoCursor(QPixmap(QString(":/cubeomniverse.svg")));


        SocketItem *a = new SocketItem(QString("Condition"),this);
        //a->setCursor(icoCursor);
        a->setSocketType(SocketItem::InPut);
        a->setSocketDataType(NODE_BOOL);
        a->setSocketName("Condition");
        inputs.append(a);


        SocketItem *b = new SocketItem(QString("Data A: true"),this);
        //b->setCursor(icoCursor);
        b->setSocketType(SocketItem::InPut);
        b->setSocketDataType(NODE_MULTI_DATA_TYPE);
        b->setSocketName("Data A: true");
        inputs.append(b);

        SocketItem *c = new SocketItem(QString("Data B: false"),this);
        //b->setCursor(icoCursor);
        c->setSocketType(SocketItem::InPut);
        c->setSocketDataType(NODE_MULTI_DATA_TYPE);
        c->setSocketName("Data B: false");
        inputs.append(c);





        SocketItem *d = new SocketItem(QString("Data C"),this);
        //c->setCursor(icoCursor);
        d->setSocketType(SocketItem::OutPut);
        d->setSocketDataType(NODE_MULTI_DATA_TYPE);
        d->setSocketName("Data C");

        outputs.append(d);

        positionSockets();

        InitilizeNodeSockets();
        enableNode();

    }

    void compute()
    {
        using namespace _NodeTypes;

        SocketItem * socket1 =  inputs[0];
        SocketItem * socket2 =  inputs[1];
        SocketItem * socket3 =  inputs[2];


        SocketItem * socket4  =  outputs[0];

        BoolData *f1  = (BoolData *)socket1->getSocketData();

        MultiData *f2 = (MultiData *)socket2->getSocketData();
        MultiData *f3  = (MultiData *)socket3->getSocketData();


        if(f1->data)
        {
            socket4->setSocketData(f2);
        }
        else
        {
            socket4->setSocketData(f3);
        }

        if(_debug)
        {
            //printf("If Node: % \n",qPrintable(f1->data));
            printf("If Node executed\n");
        }
    }
};



#endif

