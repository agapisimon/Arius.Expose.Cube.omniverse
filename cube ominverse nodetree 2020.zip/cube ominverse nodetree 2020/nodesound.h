#ifndef NODESOUND_H
#define NODESOUND_H

#include<QtWidgets>
#include<QtCore>
//#include<QtMultimedia>

/*
 Author: Agapi Simon

  Wave File FORMATETC

  The Riff chunk descriptor
  {
     The format made of two sub chunks fmt and data


    Name:   size(bytes) offset(byte)  endian
    ChunkID        4       0             big
    ChunkSize      4       4             little
    Format         4       8             big

  }

  The Fmt Sub-Chunk
  {
     The format of the sound information in the data sub chunk


    Name:         size(bytes) offset(byte)  endian
    SubChunkID        4         12           big
    SubChunkSize      4         16           little
    AudioFormat       2         20           little
    NumChannels       2         22           little
    SampleRate        4         24           little
    ByteRate          4         28           little
    BlockAlign        2         32           little
    BitsPerSample     2         34           little
  }

  The data sub chunk
  {
     Indicates the size of the sound information and
     contains the raw sound


    Name:   size(bytes) offset(byte)  endian
    ChunkID        4       36          big
    ChunkSize      4       40          little
    Data                   44          litte

  }


*/

struct chunk
{
    char        id[4];
    quint32     size;
};

struct RIFFHeader
{
    chunk       descriptor;     // "RIFF"
    char        type[4];        // "WAVE"
};

struct WAVEHeader
{
    chunk       descriptor;

    quint16     audioFormat;
    quint16     numChannels;
    quint32     sampleRate;
    quint32     byteRate;
    quint16     blockAlign;
    quint16     bitsPerSample;
};

struct DATAHeader
{
    chunk       descriptor;
};

struct CombinedHeader
{
    RIFFHeader  riff;
    WAVEHeader  wave;
};

/*

class WavFile : public QFile
{
private:
    QAudioFormat audioFormat;
    qint64 headerLength;

public:
    WavFile(QObject *parent = 0):QFile(parent)
    , headerLength(0)
    {

    }

    bool open(const QString &fileName)
    {
        close();
        setFileName(fileName);
        return QFile::open(QIODevice::ReadOnly) && readHeader();

    }
    const QAudioFormat &fileFormat()
    {
        return audioFormat;
    }
    qint64 headerLength()
    {
        return headerLength;
    }

private:
    bool readHeader()
    {
        seek(0);
        CombinedHeader header;
        bool result = read(reinterpret_cast<char *>(&header), sizeof(CombinedHeader)) == sizeof(CombinedHeader);

        if (result)
        {
            if ((memcmp(&header.riff.descriptor.id, "RIFF", 4) == 0
                || memcmp(&header.riff.descriptor.id, "RIFX", 4) == 0)
                && memcmp(&header.riff.type, "WAVE", 4) == 0
                && memcmp(&header.wave.descriptor.id, "fmt ", 4) == 0
                && (header.wave.audioFormat == 1 || header.wave.audioFormat == 0))
            {

                // Read off remaining header information
                DATAHeader dataHeader;

                if (qFromLittleEndian<quint32>(header.wave.descriptor.size) > sizeof(WAVEHeader))
                {
                    // Extended data available
                    quint16 extraFormatBytes;

                    if (peek((char*)&extraFormatBytes, sizeof(quint16)) != sizeof(quint16))
                        return false;

                    const qint64 throwAwayBytes = sizeof(quint16) + qFromLittleEndian<quint16>(extraFormatBytes);
                    if (read(throwAwayBytes).size() != throwAwayBytes)
                        return false;
                }

                if (read((char*)&dataHeader, sizeof(DATAHeader)) != sizeof(DATAHeader))
                    return false;

                // Establish format
                if (memcmp(&header.riff.descriptor.id, "RIFF", 4) == 0)
                    audioFormat.setByteOrder(QAudioFormat::LittleEndian);
                else
                    audioFormat.setByteOrder(QAudioFormat::BigEndian);

                int bps = qFromLittleEndian<quint16>(header.wave.bitsPerSample);
                audioFormat.setChannels(qFromLittleEndian<quint16>(header.wave.numChannels));
                audioFormat.setCodec("audio/pcm");
                audioFormat.setFrequency(qFromLittleEndian<quint32>(header.wave.sampleRate));
                audioFormat.setSampleSize(qFromLittleEndian<quint16>(header.wave.bitsPerSample));
                audioFormat.setSampleType(bps == 8 ? QAudioFormat::UnSignedInt : QAudioFormat::SignedInt);
            }
            else
            {
                result = false;
            }
        }

        headerLength = pos();

        return result;

    }



};
*/

class nodesound
{
public:
    nodesound();
};

#endif // NODESOUND_H
