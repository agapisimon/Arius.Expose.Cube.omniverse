/*
__author__ = 'AGAPI SIMON'
copyright 2015
mittisimone@gmail.com

project: cube omniverse nodetree
*/


#ifndef NODES
#define NODES

#include<QtWidgets>
#include<typeinfo>

/*

QScopedPointer..

From the Qt 4.6 documentation,

The QScopedPointer class stores a pointer to a
dynamically allocated object, and deletes it
 upon destruction. Managing heap allocated objects
manually is hard and error prone, with the common
result that code leaks memory and is hard to maintain.
QScopedPointer is a small utility class that heavily
simplifies this by assigning stack-based memory ownership
to heap allocations, more generally called resource
acquisition is initialization(RAII).

For Example,

You will use,

QScopedPointer<QWidget> p(new QWidget());
instead of

QWidget *p = new QWidget();
and add the QScopedPointer into your QList
without worrying about memory leak and
dangling pointers.


so the inner loop looks like this:
QScopedPointer<MyObject> obj(new MyObject());
if (obj->Init(map.values(i)) { list.append(obj.take()); } ...



The scoped ptr still OWNS the instance,
thats why i used .take().

QScopedPointer is non-copyable and can therefore not be added to a QList.


Qt’s smart pointer classes are neatly grouped now as follows:

///Shared data
QSharedDataPointer,
QExplicitlySharedDataPointer
Sharing of data (not of pointers),
implicitly and explicitly. Also known as “intrusive pointers”.


Shared pointers
QSharedPointer,
QWeakPointer	Thread-safe sharing pointers,
like C++11′s std::shared_ptr only with a nice Qt API


Scoped pointers
QScopedPointer,
QScopedPointerArray	For RAII usage:
takes ownership of a pointer and ensures it is
properly deleted at the end of the scope. No sharing.


Tracking
QObjects
QPointer
Tracks the lifetime of a given QObject instance



*/

class QFloatSlider : public QSlider
{
    Q_OBJECT

public:
    QFloatSlider(Qt::Orientation orientation, QWidget* parent = 0):QSlider(orientation, parent)
    {
        scale =1.0f;
    }

    void setScale(float scale)
    {
        this->scale=scale;
    }

public slots:
    void sliderChange(SliderChange change)
    {
        if(change==QAbstractSlider::SliderValueChange)
        {
             emit valueChanged(value()*scale);
        }
        //for completeness. Also, one could send integer and float signals
        //if desired.
        QSlider::sliderChange(change);
    }


    void setValue(float value)
    {
        QSlider::setValue(value/scale);
    }

signals:
    void valueChanged(float value);


private:
    float scale;
};

class QDoubleSlider : public QSlider
{
    Q_OBJECT

public:
    QDoubleSlider(Qt::Orientation orientation, QWidget* parent = 0):QSlider(orientation, parent)
    {
        scale =1.0f;
    }

    void setScale(double scale)
    {
        this->scale=scale;

    }

public slots:
    void sliderChange(SliderChange change)
    {
        if(change==QAbstractSlider::SliderValueChange)
        {
             emit valueChanged(value()*scale);
        }
        //for completeness. Also, one could send integer and float signals
        //if desired.
        QSlider::sliderChange(change);
    }


    void setValue(double value)
    {
        QSlider::setValue(value/scale);
    }

signals:
    void valueChanged(double value);


private:
    double scale;
};

class QColorWidget : public QFrame
{
    Q_OBJECT


    QColor color;

    QMenu * colorPresetsMenu;

public:

    QGradientStop  stop;

    qreal dt;

    void setColor(QColor color)
    {
        this->color  =  color;
    }

    QColor  getColor()
    {
        return color;
    }

    QColorWidget(QWidget * parent =0):QFrame(parent)
    {
        setFixedSize(QSize(40,25));

        color  = QColor(0,0,0,255);

        colorPresetsMenu  = new QMenu;


    }

    void paintEvent(QPaintEvent *event)
    {
        QPainter *painter = new QPainter;

        painter->begin(this);

        QBrush b(color);

        QString str = QString("Color:")+QString("R:")+QString::number(color.red())
                +QString(",")+QString("G:")+QString::number(color.green())
                +QString(",")+QString("B:")+QString::number(color.blue());

        setToolTip(str);

        painter->setBrush(b);

        painter->drawRect(rect());

        painter->end();

        update();
    }

    void contextMenuEvent(QContextMenuEvent *event)
    {


    }


    void mouseDoubleClickEvent(QMouseEvent *event)
    {
         color =  QColorDialog::getColor(color);

         if(color.isValid())
         {
             stop.second =  color;
             emit valueChanged(color);
         }

       QFrame::mouseDoubleClickEvent(event);
    }

signals:
    void valueChanged(QColor color);
};

class QFloatWidget : public QWidget
{
    Q_OBJECT

    QDoubleSlider * slider;
    QDoubleSpinBox * spinbox;

public:

    float getValue()
    {
        return slider->value();
    }

    void setMinMaxValue(float min,float max,float value,float step=0.01)
    {
        slider->setMinimum(min);
        slider->setMaximum(max);
        slider->setValue(value);
        slider->setSingleStep(step);

    }


    QFloatWidget(QWidget * parent =0):QWidget(parent)
    {
         //setGeometry(0,0,200,100);
         QHBoxLayout  *layout  = new QHBoxLayout;

         //setMinMaxValue(-100.0,100.0,0.0);

         slider   = new QDoubleSlider(Qt::Horizontal);
         spinbox =  new QDoubleSpinBox;

         layout->addWidget(slider);
         layout->addWidget(spinbox);

         setLayout(layout);
         connect(slider,SIGNAL(valueChanged(double)),spinbox,SLOT(setValue(double)));
         connect(spinbox,SIGNAL(valueChanged(double)),slider,SLOT(setValue(double)));

         setMinMaxValue(0.0,100.0,0.0,0.01);
    }
};

class QDoubleWidget : public QWidget
{
    Q_OBJECT
    QDoubleSlider * slider;
    QDoubleSpinBox * spinbox;

public:

    float getValue()
    {
        return slider->value();
    }

    void setMinMaxValue(float min,float max,float value,float step=0.01)
    {
        slider->setMinimum(min);
        slider->setMaximum(max);
        slider->setValue(value);
        slider->setSingleStep(step);

    }


    QDoubleWidget(QWidget * parent =0):QWidget(parent)
    {
         //setGeometry(0,0,200,100);
         QHBoxLayout  *layout  = new QHBoxLayout;

         setMinMaxValue(0,100.0,0.0,0.01);

         slider   = new QDoubleSlider(Qt::Horizontal);
         spinbox =  new QDoubleSpinBox;

         layout->addWidget(slider);
         layout->addWidget(spinbox);

         setLayout(layout);
         connect(slider,SIGNAL(valueChanged(double)),spinbox,SLOT(setValue(double)));
         connect(spinbox,SIGNAL(valueChanged(double)),slider,SLOT(setValue(double)));
    }

};

class QIntWidget : public QFrame
{
    Q_OBJECT
    QSlider * slider;
    QSpinBox * spinbox;
    //QLineEdit * editor;


public:

    int getValue()
    {
        return slider->value();
    }

    void setSliderMinMaxValue(int min,int max,int value,int step)
    {
        slider->setMinimum(min);
        slider->setMaximum(max);
        slider->setValue(value);
        slider->setSingleStep(step);

    }

    QIntWidget(QWidget * parent =0):QFrame(parent)
    {
        setGeometry(0,0,200,100);
        QHBoxLayout  *layout  = new QHBoxLayout;

         setSliderMinMaxValue(0,100,0,0);

         slider   = new QSlider;
         spinbox =  new QSpinBox;
         //editor = new QLineEdit;

         //layout->addWidget(editor);
         layout->addWidget(slider);
         layout->addWidget(spinbox);

         setLayout(layout);
         connect(slider,SIGNAL(valueChanged(int)),spinbox,SLOT(setValue(int)));
         connect(spinbox,SIGNAL(valueChanged(int)),slider,SLOT(setValue(int)));
    }
};

class QStringWidget : public QFrame
{
    Q_OBJECT

    QLineEdit * lineEdit;

public:

    QString getValue()
    {
        return lineEdit->text();
    }

    void setString(QString string)
    {
        lineEdit->setText(string);
    }

    QStringWidget(QWidget * parent =0):QFrame(parent)
    {
         setGeometry(0,0,200,100);
         QHBoxLayout  *layout  = new QHBoxLayout;

         lineEdit  = new QLineEdit;
         layout->addWidget(lineEdit);

         setLayout(layout);

         //connect(str,SIGNAL(textChanged(QString)),this,SLOT(setSpinBoxValue()));
      }

private slots:

    void setText(QString string)
    {
        lineEdit->setText(string);
    }
};

class QBoolWidget : public QFrame
{
    Q_OBJECT
    QCheckBox *checkbox;
public:

    bool getValue()
    {
        return checkbox->isChecked();
    }

    void setValue(bool on = false)
    {
        //checkbox->setAttribute(Qt::Checked,on);
        //checkbox->setAttribute(Qt::Checked,on);
        checkbox->setEnabled(on);
    }

    QBoolWidget(QWidget * parent =0):QFrame(parent)
    {
        checkbox = new QCheckBox;
        QHBoxLayout * layout = new QHBoxLayout;

        layout->addWidget(checkbox);
        setLayout(layout);
    }

};

class QColorEditorWidget: public QFrame
{
    Q_OBJECT

    QColor color;
    QLabel * label;

    QSpinBox *RSpinner;
    QSpinBox *GSpinner;
    QSpinBox *BSpinner;
    QSpinBox *ASpinner;

    QColorWidget * colorWidget;

public:

    void setColor(QColor color)
    {
        this->color  =  color;
    }

    QColor  getColor()
    {
        return color;
    }

    QColorEditorWidget(QWidget * parent =0):QFrame(parent)
    {
        setGeometry(0,0,150,100);

        colorWidget = new QColorWidget;
        RSpinner = new QSpinBox ;
        GSpinner = new QSpinBox ;
        BSpinner = new QSpinBox ;
        ASpinner = new QSpinBox ;
        label  = new QLabel(QString("Color:"));


        RSpinner->setRange(0,255);
        GSpinner->setRange(0,255);
        BSpinner->setRange(0,255);
        ASpinner->setRange(0,255);

        color  = QColor(0,0,0,255);

        connect(RSpinner,SIGNAL(valueChanged(int)),this,SLOT(setRValue()));
        connect(GSpinner,SIGNAL(valueChanged(int)),this,SLOT(setGValue()));
        connect(BSpinner,SIGNAL(valueChanged(int)),this,SLOT(setBValue()));
        connect(ASpinner,SIGNAL(valueChanged(int)),this,SLOT(setAValue()));
        connect(colorWidget,SIGNAL(valueChanged(QColor)),this,SLOT(setRGBA()));

        QHBoxLayout * layout =  new QHBoxLayout;

        layout->addWidget(label);
        layout->addWidget(colorWidget);
        layout->addWidget(new QLabel("R:"));
        layout->addWidget(RSpinner);
        layout->addWidget(new QLabel("G:"));
        layout->addWidget(GSpinner);
        layout->addWidget(new QLabel("B:"));
        layout->addWidget(BSpinner);
        layout->addWidget(new QLabel("A:"));
        layout->addWidget(ASpinner);


        setLayout(layout);
    }
private slots:
    void setRValue()
    {
        color.setRed(RSpinner->value());
        colorWidget->setColor(color);
    }
    void setGValue()
    {
        color.setGreen(GSpinner->value());
        colorWidget->setColor(color);
    }
    void setBValue()
    {
        color.setBlue(BSpinner->value());
        colorWidget->setColor(color);
    }
    void setAValue()
    {
        color.setAlpha(ASpinner->value());
        colorWidget->setColor(color);
    }

    void setRGBA()
    {
        color  = colorWidget->getColor();

        RSpinner->setValue(color.red());
        GSpinner->setValue(color.green());
        BSpinner->setValue(color.blue());
        ASpinner->setValue(color.alpha());
    }
};

class QRamp : public QFrame
{
    Q_OBJECT

    QLinearGradient gradient;

    QList<QColorWidget*> colorwidgets;

    QRect gradientRect;
    QRect slidersRect;

    QColorWidget *child;
public:
    QLinearGradient  getGradient()
    {
        return gradient;
    }


    void setGradient(QLinearGradient gradient)
    {
        this->gradient  =  gradient;
    }


    QRamp(QWidget * parent=0):QFrame(parent)
    {
        setMinimumWidth(200);
        setMinimumHeight(60);

        gradient.setColorAt(0,	Qt::blue);
        gradient.setColorAt(0.2,Qt::green);
        gradient.setColorAt(0.4,Qt::red);
        gradient.setColorAt(0.75,Qt::yellow);
        gradient.setColorAt(1,Qt::cyan);
        computeGradientRect();

        addstops();
    }


    void computeGradientRect()
    {
        QPoint p1 = rect().topLeft();
        QPoint p2 = rect().topRight();

        QPoint p3 = rect().topLeft();
        QPoint p4 = rect().topRight();

        p1 += QPoint(20,0);
        p2 -= QPoint(20,0);
        p2 += QPoint(0,40);

        gradientRect = QRect(p1,p2);

        p3 += QPoint(20,40);
        p4 -= QPoint(20,40);

        p4 += QPoint(0,20);

        slidersRect = QRect(p3,p4);

        gradient.setStart(gradientRect.topLeft());
        gradient.setFinalStop(gradientRect.topRight());
        gradient.setInterpolationMode(QGradient::ColorInterpolation);


    }

    void addstops()
    {
        QGradientStops stops = gradient.stops();

        for(int i = 0;i<stops.count();i++)
        {
            QGradientStop stop= stops[i];

            QColorWidget *colorwidget = new QColorWidget(this);
            colorwidget->setFixedSize(8,8);

            QRect r = QRect(0,0,8,8);

            colorwidget->setFrameRect(r);

            colorwidget->setColor(stop.second);

            colorwidget->stop =  stop;

            float dx = stop.first* slidersRect.width();

            QPoint p = QPoint(dx,0)+slidersRect.topLeft();

            colorwidget->move(p);
            colorwidget->show();

            colorwidgets.append(colorwidget);

        }
    }


    void addStop(QMouseEvent *event)
    {
        if(event->modifiers()==Qt::ControlModifier && event->button()==Qt::LeftButton)
        {
            QPointF p = QPointF(event->pos());

            if(gradientRect.contains(p.x(),p.y(),true))
            {
                float dx = (float)( p.x()- gradientRect.topLeft().x())/ gradientRect.width();

                gradient.setColorAt(dx,Qt::white);

                QGradientStop stop;

                stop.first = dx;
                stop.second = Qt::white;

                addStopSlider(stop);

                emit valueChanged(gradient);

            }
        }
    }

    void addStopSlider(QGradientStop _stop)
    {
        QColorWidget *colorwidget = new QColorWidget(this);

        colorwidget->setFixedSize(8,8);

        //QRect r = QRect(-4,-4,8,8);
        QRect r = QRect(0,0,8,8);

        colorwidget->setFrameRect(r);

        colorwidget->setColor(_stop.second);

        colorwidget->stop =  _stop;

        float dx = _stop.first* slidersRect.width();

        QPoint p = QPoint(dx,0)+slidersRect.topLeft();


        colorwidget->move(p);

        colorwidget->show();

        colorwidgets.append(colorwidget);
    }

    void deleteStope(QMouseEvent *event)
    {
      if(event->modifiers()==Qt::AltModifier && event->button()==Qt::LeftButton)
      {
          //if(QString::fromStdString(typeid(child).name()).endsWith("QColorWidget"))
          //{
              if(child->stop.first = 0)
              {

              }
              else if(child->stop.first==1)
              {

              }
              else
              {
                  colorwidgets.removeAt(colorwidgets.indexOf(child));

                  delete child;


              }
          //}
       }
    }

    void resizeEvent(QResizeEvent *event)
    {
        computeGradientRect();
    }


    void mousePressEvent(QMouseEvent *event)
    {
        getGetColorWidgetAndStop(event);

        deleteStope(event);
        addStop(event);
    }

    void getGetColorWidgetAndStop(QMouseEvent *event)
    {
        //child = static_cast<QColorWidget*>(childAt(event->pos()));

        child = dynamic_cast<QColorWidget*>(childAt(event->pos()));


    }



    void mouseMoveEvent(QMouseEvent *event)
    {
        if(child )
        {
            float dy =  child->pos().y();
            float dx =  event->pos().x();

            QPoint p = QPoint(dx,dy);

            if(slidersRect.contains(p))
            {

                if(child->stop.first ==0)
                {

                }
                else if(child->stop.first ==1)
                {

                }
                else
                {
                    child->move(p);
                    update();
                    emit valueChanged(child->dt);
                }


            }
        }
    }

    void mouseReleaseEvent(QMouseEvent *event)
    {
        if(child)
        {
            child = NULL;
        }
    }

    void paintEvent(QPaintEvent *event)
    {
        QList<qreal> list;

        foreach(QColorWidget * w,colorwidgets)
        {
            qreal d =(qreal)(w->pos().x()-20)/gradientRect.width();

            w->dt = d;

            list.append(d);
        }

        qSort(list);

        QGradientStops _stops;

        QGradientStop _stop;

        _stop.first = colorwidgets[0]->dt;
        _stop.second = colorwidgets[0]->getColor();

        _stops.prepend(_stop);

        for(int i =0;i<list.size();i++)
        {
            foreach(QColorWidget * w,colorwidgets)
            {
                if(list[i] = w->dt)
                {
                    QGradientStop _stop;

                    _stop.first = list[i];
                    _stop.second = w->getColor();

                    _stops.append(_stop);
                }
            }
        }

        QPainter painter(this);

        gradient.setStops(_stops);

        gradient.setSpread(QGradient::PadSpread);

        QBrush b(gradient);

        painter.setBrush(b);

        painter.drawRect(gradientRect);

        update();
    }

signals:
    void valueChanged(float dt);
    void valueChanged(QLinearGradient grad);

};

class QGradientRampWidget: public QWidget
{
    Q_OBJECT
    QRamp * ramp;
public:

    void setGradient(QLinearGradient gradient)
    {
        ramp->setGradient(gradient);
    }

    QLinearGradient  getGradient()
    {
        return ramp->getGradient();
    }

    QGradientRampWidget(QWidget * parent =0):QWidget(parent)
    {
        setMinimumWidth(250);
        setMinimumWidth(100);

        QVBoxLayout * layout  = new QVBoxLayout;
        QHBoxLayout * hlayout = new QHBoxLayout;

        QGroupBox * group =  new QGroupBox(QString("Gradient Ramp"));
        ramp = new QRamp(this);
        layout->addWidget(ramp);

        group->setLayout(layout);

        hlayout->addWidget(group);
        setLayout(hlayout);
    }
private slots:

};

class QVector3DWidget: public QFrame
{
    Q_OBJECT

    QVector3D _vector;
    //QLabel * label;

    QSpinBox *XSpinner;
    QSpinBox *YSpinner;
    QSpinBox *ZSpinner;


public:

    void setVector(QVector3D vector)
    {
        _vector  =  vector;

        emit valueChanged(_vector);
    }

    QVector3D  getVector()
    {
        return _vector;
    }

    QVector3DWidget(QWidget * parent =0):QFrame(parent)
    {
        setGeometry(0,0,150,100);


        XSpinner = new QSpinBox ;
        YSpinner = new QSpinBox ;
        ZSpinner = new QSpinBox ;

        //label  = new QLabel(QString("Color"));

        XSpinner->setRange(-10000,10000);
        YSpinner->setRange(-10000,10000);
        ZSpinner->setRange(-10000,10000);

        _vector  = QVector3D(0,0,0);

        connect(XSpinner,SIGNAL(valueChanged(int)),this,SLOT(setXValue()));
        connect(YSpinner,SIGNAL(valueChanged(int)),this,SLOT(setYValue()));
        connect(ZSpinner,SIGNAL(valueChanged(int)),this,SLOT(setZValue()));

        connect(this,SIGNAL(valueChanged(QVector3D)),this,SLOT(setXYZ()));


        QHBoxLayout * layout =  new QHBoxLayout;

        //layout->addWidget(label,0,0);
        layout->addWidget(new QLabel("X:"));
        layout->addWidget(XSpinner);
        layout->addWidget(new QLabel("Y:"));
        layout->addWidget(YSpinner);
        layout->addWidget(new QLabel("Z:"));
        layout->addWidget(ZSpinner);

        setLayout(layout);
    }
private slots:
    void setXValue()
    {
        _vector.setX(XSpinner->value());
           }
    void setYValue()
    {
        _vector.setY(YSpinner->value());

    }
    void setZValue()
    {
        _vector.setZ(ZSpinner->value());

    }

    void setXYZ()
    {
        XSpinner->setValue(_vector.x());
        YSpinner->setValue(_vector.y());
        ZSpinner->setValue(_vector.x());
    }
signals:
    void valueChanged(QVector3D v);
};

class QVector2DWidget: public QFrame
{
    Q_OBJECT

    QVector2D _vector;

    QSpinBox *XSpinner;
    QSpinBox *YSpinner;


public:

    void setVector(QVector2D vector)
    {
        this->_vector  =  vector;

        emit valueChanged(_vector);
    }

    QVector2D  getVector()
    {
        return _vector;
    }

    QVector2DWidget(QWidget * parent =0):QFrame(parent)
    {
        setGeometry(0,0,150,100);


        XSpinner = new QSpinBox ;
        YSpinner = new QSpinBox ;

        //label  = new QLabel(QString("Color"));

        XSpinner->setRange(-10000,10000);
        YSpinner->setRange(-10000,10000);

        _vector  = QVector2D(0,0);

        connect(XSpinner,SIGNAL(valueChanged(int)),this,SLOT(setXValue()));
        connect(YSpinner,SIGNAL(valueChanged(int)),this,SLOT(setYValue()));

        connect(this,SIGNAL(valueChanged(QVector2D)),this,SLOT(setXY()));


        QHBoxLayout * layout =  new QHBoxLayout;

        //layout->addWidget(label,0,0);
        layout->addWidget(new QLabel("X:"));
        layout->addWidget(XSpinner);
        layout->addWidget(new QLabel("Y:"));
        layout->addWidget(YSpinner);

        setLayout(layout);
    }
private slots:
    void setXValue()
    {
        _vector.setX(XSpinner->value());
           }
    void setYValue()
    {
        _vector.setY(YSpinner->value());

    }


    void setXY()
    {
        XSpinner->setValue(_vector.x());
        YSpinner->setValue(_vector.y());

    }
signals:
    void valueChanged(QVector2D v);
};

class QRampCurveWidget : public QFrame
{
    Q_OBJECT

    QList<QColorWidget*> knots;
    QPolygonF polygon;

    QRect polygonRect;

    QColorWidget *child;

public:
    QList<QPointF>  getPoints()
    {
        polygon.clear();

        foreach(QColorWidget * w,knots)
        {
            polygon.append(QPointF(w->pos()));
        }

        return polygon.toList();
    }


    void setGradient(QList<QPointF> points)
    {
        polygon.fromList(points);
    }


    QRampCurveWidget(QWidget * parent=0):QFrame(parent)
    {
        setMinimumWidth(200);
        setMinimumHeight(100);

        computePolygonRect();

        addstops();
    }


    void computePolygonRect()
    {
        QPoint p1 = rect().topLeft();
        QPoint p2 = rect().bottomRight();

        p1 += QPoint(5,5);
        p2 -= QPoint(5,5);

        polygonRect = QRect(p1,p2);

    }

    void addstops()
    {
        QList<QPointF> points =  polygon.toList();

        for(int i = 0;i<points.count();i++)
        {
            QColorWidget *knot = new QColorWidget(this);
            knot->setFixedSize(8,8);
            knot->setDisabled(true);


            QPoint p = points[i].toPoint();
            knot->move(p);
            knot->show();

            knots.append(knot);

        }
    }


    void addStop(QMouseEvent *event)
    {
        if(event->modifiers()==Qt::ControlModifier && event->button()==Qt::LeftButton)
        {
            QPointF p = QPointF(event->pos());

            if(polygonRect.contains(p.x(),p.y(),true))
            {
                addStopSlider(p);

                emit valueChanged(polygon);

            }
        }
    }

    void addStopSlider(QPointF p)
    {
        QColorWidget *knot = new QColorWidget(this);

        knot->setFixedSize(8,8);
        knot->move(p.toPoint());
        knot->setDisabled(true);

        knot->show();

        knots.append(knot);
    }

    void deleteStope(QMouseEvent *event)
    {
      if(event->modifiers()==Qt::AltModifier && event->button()==Qt::LeftButton)
      {
          knots.removeAt(knots.indexOf(child));

          delete child;
       }
    }

    void resizeEvent(QResizeEvent *event)
    {
        computePolygonRect();
    }


    void mousePressEvent(QMouseEvent *event)
    {
        getGetColorWidgetAndStop(event);

        deleteStope(event);
        addStop(event);
    }

    void getGetColorWidgetAndStop(QMouseEvent *event)
    {

        child = dynamic_cast<QColorWidget*>(childAt(event->pos()));


    }



    void mouseMoveEvent(QMouseEvent *event)
    {
        if(child )
        {
            QPoint p =  event->pos();

            if(polygonRect.contains(p))
            {
                child->move(p);

                update();

                emit valueChanged(child->pos());
            }
        }
    }

    void mouseReleaseEvent(QMouseEvent *event)
    {
        if(child)
        {
            child = NULL;
        }
    }

    void paintEvent(QPaintEvent *event)
    {

        polygon.clear();

        foreach(QColorWidget * w,knots)
        {
            polygon.append(QPointF(w->pos()));
        }

        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);
        painter.setPen(QPen(QColor(5,5,5),2));
        painter.drawRect(rect());

        painter.setPen(QPen(QColor(150,150,150),2));
        painter.drawRect(polygonRect);
        painter.setPen(QPen(QColor(25,25,25),2));
        painter.setBrush(QBrush(QColor(93,93,93),Qt::SolidPattern));
        painter.drawPolygon(polygon);

        update();
    }

signals:
    void valueChanged(QPoint p);
    void valueChanged(QPolygonF  poly);

};

class QPropertiesWidget : public QTreeWidget
{
    Q_OBJECT


    QList<QWidget*> widgets;

public:
    QPropertiesWidget(QWidget * parent = 0): QTreeWidget(parent)
    {

        QStringList panes;

        panes.append(QString("Vector Combine"));
        panes.append(QString("Vector Normalize"));
        panes.append(QString("Vector Cross"));
        panes.append(QString("Vector Dot"));
        panes.append(QString("Comments"));

        QStringList combinevector;

        combinevector.append(QString("x"));
        combinevector.append(QString("y"));
        combinevector.append(QString("z"));
        combinevector.append(QString("w"));



        setColumnCount(1);
        setHeaderLabel("Properties Editor");
        verticalScrollBar()->setSingleStep(1);
        setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);
        //setAlternatingRowColors(true);


        for(int i=0;i<panes.length();i++)
        {
           QTreeWidgetItem * item = new QTreeWidgetItem(this);

           item->setText(0, panes[i]);

           QTreeWidgetItem * childItem = new QTreeWidgetItem(item);

           QFrame *frame = new QFrame;

           QGridLayout *layout = new QGridLayout;

           for(int p =0;p<panes.size();p++)
           {
               QRadioButton *c = new QRadioButton;
               c->setCheckable(true);
               c->setMaximumWidth(20);
               c->setMinimumWidth(20);

               QLabel *l = new QLabel(panes[i]);
               l->setMaximumWidth(100);
               l->setMinimumWidth(100);
               QSlider *sl = new QSlider(Qt::Horizontal);
               sl->setMaximumWidth(150);
               //sl->setMinimumWidth(150);

               //QLineEdit *ql = new QLineEdit;
               //ql->setValidator( new QDoubleValidator(0, 20, 2, this) );

               QSpinBox *ql = new QSpinBox();
               ql->setMaximumWidth(50);
               ql->setMinimumWidth(50);
               ql->setRange(0,100);

               connect(sl,SIGNAL(valueChanged(int)),ql,SLOT(setValue(int)));

               connect(ql,SIGNAL(valueChanged(int)),sl,SLOT(setValue(int)));


               layout->addWidget(c,p,0);
               layout->addWidget(l,p,1);
               layout->addWidget(sl,p,2);
               layout->addWidget(ql,p,3);
           }

           QColorEditorWidget * cs  = new QColorEditorWidget;
           layout->addWidget(cs);

           QGradientRampWidget *ge = new QGradientRampWidget;
           layout->addWidget(ge);

           QVector3DWidget *k =  new QVector3DWidget;
           layout->addWidget(k);

           QVector2DWidget *m =  new QVector2DWidget;
           layout->addWidget(m);

           QRampCurveWidget *curv =  new QRampCurveWidget;
           layout->addWidget(curv);


           frame->setLayout(layout);

           setItemWidget(childItem, 0, frame);


        }
    }
};

enum FRAME_RATES
{
    FPS_24 = 24,
    FPS_25 = 25,
    FPS_30 = 30,
    FPS_60 = 60,
    FPS_90 = 90,

    FPS_REALTIME,
    FPS_CUSTOMN,
};

class TimeLineFrame : public QFrame
{
    Q_OBJECT

    int startFrame;
    int currentFrame;
    int endFrame;

    int totalFrames;

    int fps;

    int LoopCount;
    int currentLoop;

    /*
    bool isRealtime;
    bool isplaying;
    int step;
    */

    QPoint indexPos;

    //QList<QTimeLine *> timelines;

    float interval;

    int ticks = 1000;//1000ms = 1s;

    QTimer * timer;

    //QSlider *sliderTimeLine;

    QRectF timelineRect;

    bool isPlaying;


public:

    QTimer* getTimer()
    {
        return timer;
    }
    /*
    QSlider* getQProgressBar()
    {
        return sliderTimeLine;
    }
    */

    void setTimeLine(QTimer * _timer)
    {
        timer =  _timer;
    }

    int getStartFrame()
    {
        return startFrame;
    }

    int getEndFrame()
    {
        return endFrame;
    }

    int getCurrentFrame()
    {
       return currentFrame;
    }


    int getLoopCount()
    {
        return LoopCount;
    }
    void setLoopCount(int count)
    {
        LoopCount = count;
    }

    void setFrameRate(int FrameRate = FPS_24)
    {
        if(FrameRate = FPS_24)
        {
            fps =  24;
            interval = (float)1/24 * ticks;
        }
        else if(FrameRate = FPS_25)
        {
            fps= 25;
            interval = (float)1/25 * ticks;
        }
        else if(FrameRate = FPS_30)
        {
            fps =  30;
            interval = (float)1/30 * ticks;
        }
        else if(FrameRate = FPS_60)
        {
            fps = 60;
            interval = (float)1/60 * ticks;
        }
        else if(FrameRate = FPS_90)
        {
            fps = 90;
            interval = (float)1/90 * ticks;
        }
        else if(FrameRate = FPS_REALTIME)
        {
            fps = -1;
            interval = 0;
        }
        else if(FrameRate = FPS_CUSTOMN)
        {
            fps = 120;
            interval = (float)1/120 * ticks;
        }

        timer->setInterval(interval);

    }

    void setStartFrame(int frame=0)
    {
        startFrame =  frame;
    }

    void setEndFrame(int frame=0)
    {
        endFrame = frame;
    }

    void setCurrentFrame(int frame)
    {
        currentFrame = frame;
    }
    void setClipFrame()
    {
        /*
        if(startFrame>endFrame)
        {
            startFrame =  endFrame;
        }

        if(startFrame<endFrame)
        {
            endFrame =  startFrame;
        }
        */


        if(currentFrame<startFrame)
        {
            //currentFrame = startFrame;
            //currentLoop -= 1;

            goToLastFrame();
        }
        else if(currentFrame>endFrame)
        {
            //currentFrame = endFrame;
            //currentLoop+= 1;

            //currentLoop+= 1;

            goToStartFrame();

            /*

            if(currentLoop>=LoopCount)
            {
                this->timer->stop();
            }
            else
            {
                goToStartFrame();

            }
            */
        }

        //setProgress();

        emit valueChanged(currentFrame);
    }

    void setFrameRange(int start,int end)
    {
        startFrame = start;
        endFrame = end;
    }





public:

    TimeLineFrame(QFrame *parent = 0): QFrame(parent)
    {
        indexPos     = QPoint(0,0);
        startFrame   = 0;
        currentFrame = 0;
        endFrame     = 150;
        fps          = 25;
        LoopCount    = 5;
        currentLoop  = 0;
        totalFrames  = endFrame - startFrame;

        timer = new QTimer(this);

        isPlaying =  false;

        //sliderTimeLine = new QSlider(this);
        //sliderTimeLine->setTickInterval(5);
        //sliderTimeLine->setTickPosition(QSlider::TicksBelow);

        //sliderTimeLine->hide();



        /*
        step = 1;

        isRealtime = false;
        isplaying = false;
        */



        this->setFrameRate(FPS_24);
        this->setFrameRange(startFrame,endFrame);
        this->setLoopCount(5);

        //sliderTimeLine->setMinimum(startFrame);
        //sliderTimeLine->setMaximum(endFrame);
        //sliderTimeLine->setRange(startFrame,endFrame);
        //sliderTimeLine->setOrientation(Qt::Horizontal);

        setMinimumSize(1, 30);

        //connect(timer, SIGNAL(timeout()), this, SLOT(setProgress()));
        connect(timer,SIGNAL(timeout()),this,SLOT(playForward()));

        //connect(sliderTimeLine,SIGNAL(valueChanged(int)),this,SLOT(setCurrentFrameFromProgress()));



        computeTimelineRect();
    }

    void computeTimelineRect()
    {
        QPoint p1 = rect().topLeft();
        QPoint p2 = rect().bottomRight();

        p1 += QPoint(25,5);
        p2 -= QPoint(25,5);

        timelineRect = QRect(p1,p2);

    }

    void wheelEvent(QWheelEvent *event)
    {
        positionIndex(event);
    }

    /*

    enum FRAMERATES
    {
        FPS_25,
        FPS_30,
        FPS_60,
        FPS_REALTIME,
        FPS_CUSTOMN,
    };
    */

    void paintEvent( QPaintEvent * event)
    {
        computeTimelineRect();

        QPainter painter(this);


        painter.setPen(QPen(QColor(25,25,25),2));
        painter.setBrush(QBrush(QColor(93,93,93),Qt::SolidPattern));

        painter.drawRect(rect());
        painter.setPen(QPen(QColor(5,5,5,20),2));
        painter.drawRect(timelineRect);

        totalFrames = endFrame- startFrame;

        drawIndexMarker();
        drawRuler();


        update();
    }

    float computeFrameWidth()
    {
        float dx = timelineRect.width()* (currentFrame-startFrame)/totalFrames;

        return dx;

    }

    void drawIndexMarker()
    {
        QPainter p(this);
        QFont f( "Courier", 10, QFont::Normal );

        p.setFont(f);
        p.setPen(Qt::cyan);
        p.setBrush(QBrush(QColor(Qt::cyan)));

        QRect indexRect(1,0,2,timelineRect.height());

        float dx  = computeFrameWidth();

        QPointF _p  = timelineRect.topLeft();

        _p+= QPointF(dx,0);

        indexRect.moveTo(_p.toPoint());

        p.drawRect(indexRect);


    }

    void positionIndex(QWheelEvent *event)
    {
        if(isPlaying==false)
        {
            if(timelineRect.contains(event->pos()))
            {
                qDebug()<<"delta"<<event->delta();

                float dl = event->delta();

                if( dl < 0 )
                {
                    //currentFrame -= 1;
                    goToPreviousFrame();

                }
                else if( dl > 0 )
                {
                    goToNextFrame();
                    //currentFrame += 1;
                }

                //playForward();
            }
        }

        update();

    }

    void positionIndex(QMouseEvent *event)
    {
        if(event->buttons() & Qt::LeftButton)
        {
            if(isPlaying==false)
            {
                if(timelineRect.contains(QPointF(event->pos())))
                {
                    QPointF _p =  QPointF(event->pos());

                    float dx = _p.x() - timelineRect.topLeft().x();

                    float fr = totalFrames *dx/timelineRect.width();

                    currentFrame = (int)floor(fr);

                    qDebug()<<"Pos:"<<event->pos()<<"Frame:"<<currentFrame;

                    playForward();
                }
            }
        }
        update();
    }

    /*
    void drawFrameRange()
    {
        QPainter p(this);
        p.setPen(Qt::black);

        float dx1 = width()*(currentFrame- startFrame)/totalFrames;
        float dx2 = width()*(currentFrame- startFrame)/totalFrames;
        QRectF rec(0,0);
        p.drawRect();
    }
    */

    void drawRuler()
    {
        QFont f( "Courier", 8, QFont::Normal );

        QPainter p(this);
        p.setPen(Qt::black);
        p.setFont(f);


        int stepFrames = (int)totalFrames/25;

        for(int i=0;i<=totalFrames;i+=stepFrames)
        {
            QPointF s = timelineRect.bottomLeft();
            QPointF e = timelineRect.bottomLeft();

            float ddx = timelineRect.width()* i/totalFrames;

            s += QPoint(ddx,0);
            s -= QPoint(0,2);


            e += QPoint(ddx,0);

            e -= QPoint(0,10);
            e -= QPoint(0,2);

            p.drawLine(s,e);

            p.setPen(Qt::black);
            p.drawText(e,QString::number(i+startFrame));


        }



        for(int j=0;j<totalFrames;j+=1)
        {
            QPointF s = timelineRect.bottomLeft();
            QPointF e = timelineRect.bottomLeft();

            float ddx = timelineRect.width()* j/totalFrames;

            s += QPoint(ddx,0);
            s -= QPoint(0,2);


            e += QPoint(ddx,0);

            e -= QPoint(0,4);
            e -= QPoint(0,2);

            p.drawLine(s,e);

        }


    }

    void resizeEvent(QResizeEvent *event)
    {
        //sliderTimeLine->resize(width(),20);

        QFrame::resizeEvent(event);
    }




    void mousePressEvent(QMouseEvent *event)
    {
        positionIndex(event);
    }

    void mouseMoveEvent(QMouseEvent *event)
    {
        positionIndex(event);
    }

signals:
    void valueChanged(int frame);

public slots:



    void play()
    {
        isPlaying = true;
        timer->start();
    }

    void stop()
    {
        isPlaying = false;
        timer->stop();
    }

    void goToNextFrame()
    {
        currentFrame += 1;
        setClipFrame();

    }
    void goToPreviousFrame()
    {
        currentFrame -= 1;
        setClipFrame();
    }

    void goToLastFrame()
    {
        currentFrame  =  endFrame;
        setClipFrame();
    }
    void goToStartFrame()
    {
        currentFrame  =  startFrame;
        setClipFrame();
    }

    void playForward()
    {

         currentFrame += 1;
         setClipFrame();
         //printf("Frame:%i \n",currentFrame);
    }
    void playBackWard()
    {

         currentFrame -= 1;
         setClipFrame();
         //printf("Frame:%i \n",currentFrame);
    }

    /*

    void setProgress()
    {
        sliderTimeLine->setValue(currentFrame);
    }

    void setCurrentFrameFromProgress()
    {
        currentFrame =sliderTimeLine->value();
    }
    */
};

class TimeLineWidget : public QWidget
{
    Q_OBJECT

    TimeLineFrame *timelineframe;

    QSpinBox * spinBoxStartFrame;
    QSpinBox * spinBoxEndFrame;
    QSpinBox * spinBoxCurrentFrame;
    QComboBox * cbox;

public:

    TimeLineWidget (QWidget *parent=0) : QWidget(parent)
    {
        timelineframe = new TimeLineFrame;
        spinBoxCurrentFrame  = new QSpinBox();

        QVBoxLayout *vlayout = new QVBoxLayout;
        QHBoxLayout *layout = new QHBoxLayout;

        /*
        enum FRAME_RATES
        {
            FPS_24 = 24,
            FPS_25 = 25,
            FPS_30 = 30,
            FPS_60 = 60,
            FPS_90 = 90,

            FPS_REALTIME,
            FPS_CUSTOMN,
        };
        */

        cbox = new  QComboBox;

        cbox->addItem(QString("fps 24"));
        cbox->addItem(QString("fps 25"));
        cbox->addItem(QString("fps 30"));
        cbox->addItem(QString("fps 60"));
        cbox->addItem(QString("fps 90"));
        cbox->addItem(QString("fps RealTime"));


        cbox->setMinimumWidth(50);

        QPushButton * firstbutton =  new QPushButton(QString("|<"));
        QPushButton * prevbutton =  new QPushButton(QString("<<"));
        QPushButton * playbutton =  new QPushButton(QString(">"));
        QPushButton * nextbutton =  new QPushButton(QString(">>"));
        QPushButton * lastbutton =  new QPushButton(QString(">|"));
        QPushButton * pausebutton =  new QPushButton(QString("||"));
        QPushButton * stopbutton =  new QPushButton(QString("|o|"));


        spinBoxCurrentFrame->setValue(timelineframe->getCurrentFrame());


        //currentFrame->setText(QString("Frame: ")+QString::number( timelineframe->getCurrentFrame()));

        layout->addWidget(new QLabel("Frame:"));
        layout->addWidget(spinBoxCurrentFrame);

        layout->addWidget(firstbutton);
        layout->addWidget(prevbutton);
        layout->addWidget(playbutton);
        layout->addWidget(pausebutton);
        layout->addWidget(stopbutton);
        layout->addWidget(nextbutton);
        layout->addWidget(lastbutton);

        layout->addWidget(new QLabel("Frames/Seconds:"));
        layout->addWidget(cbox);


        connect(firstbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(goToStartFrame()));
        connect(lastbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(goToLastFrame()));
        connect(prevbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(goToPreviousFrame()));
        connect(playbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(play()));
        connect(nextbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(goToNextFrame()));
        connect(pausebutton,SIGNAL(clicked(bool)),timelineframe,SLOT(stop()));
        connect(stopbutton,SIGNAL(clicked(bool)),timelineframe,SLOT(stop()));

        connect(timelineframe,SIGNAL(valueChanged(int)),spinBoxCurrentFrame,SLOT(setValue(int)));
        //connect(timelineframe->getQProgressBar(),SIGNAL(valueChanged(int)),this,SLOT(setLabel()));
        //connect(timelineframe->getQProgressBar(),SIGNAL(valueChanged(int)),spinBoxCurrentFrame,SLOT(setValue(int)));


                /*

        setStartFrame = new QLineEdit();
        QValidator *svalidator = new QIntValidator(0, 10000, this);
        setStartFrame->setValidator(svalidator);

        setEndFrame = new QLineEdit();
        QValidator *evalidator = new QIntValidator(0, 10000, this);
        setEndFrame->setValidator(evalidator);

                */
        spinBoxStartFrame = new QSpinBox();
        spinBoxEndFrame = new QSpinBox();



        spinBoxCurrentFrame->setRange(0,10000);
        spinBoxEndFrame->setRange(0,10000);
        spinBoxStartFrame->setRange(0,10000);


        layout->addWidget(new QLabel(QString("Start Frame:")));
        layout->addWidget(spinBoxStartFrame);

        layout->addWidget(new QLabel(QString("End Frame:")));
        layout->addWidget(spinBoxEndFrame);

        /*

        layout->addWidget(new QLabel(QString("   Current Frame:")));
        layout->addWidget(new QLineEdit());

        layout->addWidget(new QLabel(QString("   Frames Per Second:")));
        layout->addWidget(cbox);
        layout->addWidget(new QLineEdit());

        layout->addWidget(new QLabel(QString("   Total Frames:")));
        layout->addWidget(new QLineEdit());


        layout->addWidget(new QLabel(QString("set Loop Frames")));
        layout->addWidget(new QRadioButton());

        layout->addWidget(new QLabel(QString("set Frame Range")));
        layout->addWidget(new QRadioButton());
        */

        connect(spinBoxEndFrame,SIGNAL(editingFinished()),this,SLOT(setEndFrameLabel()));
        connect(spinBoxStartFrame,SIGNAL(editingFinished()),this,SLOT(setStartFrameLabel()));
        connect(spinBoxCurrentFrame,SIGNAL(editingFinished()),this,SLOT(setCurrentFrameLabel()));

        //connect(spinBoxEndFrame,SIGNAL(valueChanged(int)),this,SLOT(setEndFrameLabel()));
        //connect(spinBoxStartFrame,SIGNAL(valueChanged(int)),this,SLOT(setStartFrameLabel()));
        connect(spinBoxCurrentFrame,SIGNAL(valueChanged(int)),this,SLOT(setCurrentFrameLabel()));

        connect(cbox,SIGNAL(currentIndexChanged(int)),this,SLOT(setFrameRate()));


        vlayout->addWidget(timelineframe);
        vlayout->addLayout(layout);

        spinBoxStartFrame->setValue(timelineframe->getStartFrame());
        spinBoxEndFrame->setValue(timelineframe->getEndFrame());


        setLayout(vlayout);
    }

private slots:

    void setFrameRate()
    {
        //cbox->currentIndex();
        //cbox->currentText();
       //cbox->itemText()

        timelineframe->stop();


        if(cbox->currentText() =="fps 24")
        {
            timelineframe->setFrameRate(FPS_24);

        }
        else if(cbox->currentText() =="fps 25")
        {
            timelineframe->setFrameRate(FPS_30);
        }
        else if(cbox->currentText() =="fps 30")
        {
            timelineframe->setFrameRate(FPS_30);
        }
        else if(cbox->currentText() =="fps 60")
        {
            timelineframe->setFrameRate(FPS_60);
        }
        else if(cbox->currentText() =="fps 90")
        {
            timelineframe->setFrameRate(FPS_90);

        }
        else if(cbox->currentText() =="fps RealTime")
        {
            timelineframe->setFrameRate(FPS_REALTIME);
        }
        //timelineframe->setClipFrame();

        timelineframe->stop();
    }

    void setLabel()
    {
       // currentFrame->setText(QString("Frame: ")+QString::number( timelineframe->getCurrentFrame()));
    }

    void setCurrentFrameLabel()
    {
        timelineframe->setCurrentFrame(spinBoxCurrentFrame->text().toInt());
        timelineframe->setClipFrame();
    }

    void setStartFrameLabel()
    {
        timelineframe->setStartFrame(spinBoxStartFrame->text().toInt());
        timelineframe->setClipFrame();
    }

    void setEndFrameLabel()
    {
        timelineframe->setEndFrame(spinBoxEndFrame->text().toInt());
        timelineframe->setClipFrame();
    }
};

/*

class QTimeLineSlider : public QWidget
{
     Q_OBJECT

    static const int GRID_WIDTH = 10000;
    static const int PADDING = GRID_WIDTH / 3;

    QGridLayout* layout;
    QSlider* slider;
    QVector<int>* values;
    QList<QLabel*> labels;

public:
    QTimeLineSlider(QVector<int>* values, int min =0, int max=150, QWidget *parent = 0, Qt::WFlags flags = 0)
    {
        layout = new QGridLayout();
        layout->setSpacing(0);

        slider = new QSlider(Qt::Horizontal);
        slider->setTickInterval(25);
        slider->setTickPosition(QSlider::TicksBelow);


        layout->addWidget(slider, 0, PADDING, 1, GRID_WIDTH - PADDING, Qt::AlignBottom);

        //populate bottom row with labels
        QVector<int>::Iterator iterator = values->begin();
        while(iterator != values->end())
        {
            //place the label at the relative position under the slider
            int columnIndex = ((double)*iterator / (double)max) * (double)GRID_WIDTH;
            QString labelString = QString::number(*iterator);
            QLabel* label = new QLabel(labelString);
            labels.append(label);
            layout->addWidget(label, 1, columnIndex, 1, 1, Qt::AlignTop);

            iterator++;
        }

       this->setLayout(layout);

    }

    void resizeEvent(QResizeEvent * event)
    {
        foreach(QLabel* l,labels)
        {
            //l->move();
        }

        QWidget::resizeEvent(event);


    }

    ~QTimeLineSlider()
    {

    }


};



*/




#endif // NODES

