#include "nodesound.h"

nodesound::nodesound()
{

}

