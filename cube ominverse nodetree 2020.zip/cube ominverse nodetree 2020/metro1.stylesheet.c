/*===========================================================================
 * Colors
 *===========================================================================

Textcolor: rgb(227, 227, 227) lightgray 
Textcolor_grey: rgb(146, 146, 146);
Textcolor:disabled rgb(89, 89, 89) gray
Background: rgb(51, 51, 51) dark grey
TextcolorHighlightBlue: rgb(72, 183, 231) lightblue
WidgetBorderColor: rgb(81, 81, 81);
HighlightColor: palette(highlight);
SelectionColor: rgba(247, 138, 9, 127);
SelectionGrey: rgb(102, 102, 102);
IndicatorsAndArrows: rgb(180, 180, 180);

alternate-base
| base
| bright-text
| button
| button-text
| dark
| highlight
| highlighted-text
| light
| link
| link-visited
| mid
| midlight
| shadow
| text
| window
| window-text 
*/


/*===========================================================================
 * QWidget
 *===========================================================================*/
QWidget
{
    color: rgb(227, 227, 227);
}

QWidget:disabled
{
    color: rgb(89, 89, 89);
}

QtLabb--CStyledWidget
{
    background: rgb(51, 51, 51);
}

/*===========================================================================
 * QScrollArea
 *===========================================================================*/
QScrollArea
{
    background: rgb(51, 51, 51);
}

QScrollArea > QWidget > QWidget
{
    background: rgb(51, 51, 51);
}
 
/*===========================================================================
 * QProgressBar
 *===========================================================================*/
QProgressBar 
{
    text-align: center;
    border: none;
    background: rgb(81, 81, 81);
    color: rgb(31, 31, 31);
    padding: 2px;
}

QProgressBar:disabled
{
    background: rgb(61, 61, 61);
    color: rgb(61, 61, 61);
}


QProgressBar::chunk:horizontal 
{
    width: 1px;
    background: palette(highlight);
}

QProgressBar::chunk:vertical
{
    border: none;
    background: palette(highlight);
    height: 1px;
}


/*===========================================================================
 * QTabWidget
 *===========================================================================*/
QTabWidget::pane
{
    background: rgb(51, 51, 51);
    border: 1px solid rgb(81, 81, 81);
}


QTabBar
{
    tabbar-elide-mode: 1;
    background-color: rgb(51, 51, 51);
    font-size: 12px;
    qproperty-drawBase: false;
}


QTabBar::tab
{
    padding: 3px;
    font-size: 11px;
}

 
QTabBar::close-button 
{
     image: url(:/metro/images/tabbar_close_button.png);
}

QTabBar::close-button:hover 
{
     image: url(:/metro/images/tabbar_close_button_hoover.png);
}


QTabBar::tab:top
{
    border-left: 1px solid rgb(81, 81, 81);
    border-top: 1px solid rgb(81, 81, 81);
}


QTabBar::tab:bottom
{
    border-left: 1px solid rgb(81, 81, 81);
    border-bottom: 1px solid rgb(81, 81, 81);
}


QTabBar::tab:top:last
{
   border-right: 1px solid rgb(81, 81, 81);
}

QTabBar::tab:bottom:last
{
   border-right: 1px solid rgb(81, 81, 81);
}


QTabBar::tab:!selected
{
	background-color: rgb(51, 51, 51);
}


QTabBar::tab:hover:!selected 
{
    background-color: rgb(102, 102, 102);
}

QTabBar::tab:selected
{
    background-color: rgb(81, 81, 81);
    color: palette(highlight);
}


/*===========================================================================
 * QMainWindow
 *===========================================================================*/
QMainWindow::separator 
{
    background: rgb(51, 51, 51);
    width: 6px;
}

QMainWindow::separator:hover 
{
    background: rgba(247, 138, 9, 96);
}
 
QMainWindow
{
    background: rgb(51, 51, 51);
}

QSplitter::handle:horizontal
{
    image: url(:/metro/images/splitter_handle_horizontal.png);
}

QSplitter::handle:vertical
{
    image: url(:/metro/images/splitter_handle_vertical.png);
}

 
/*===========================================================================
 * QMenu
 *===========================================================================*/
QMenu
{
    border: 1px solid rgb(81, 81, 81);
    background-color: rgb(51, 51, 51);
    color: rgb(227, 227, 227);
    margin: 0px;
    padding: 1px;
}
 

QMenu::item 
{
    padding-left: 29px;
    padding-top: 3px;
    padding-right: 20px;
    padding-bottom: 3px;
    border: 1px solid transparent; /* reserve space for selection border */
}

QMenu::item:disabled
{
    color: rgb(89, 89, 89);
}

QMenu::item:selected:!disabled 
{
    border: 1px solid transparent;
    background-color: palette(highlight);
    color: rgb(51, 51, 51);
}


QMenu::icon:checked:selected
{ 
    /* appearance of a 'checked' icon */
    background-color: rgb(81, 81, 81);
    border: 1px solid palette(highlight);
}


QMenu::icon:checked:!selected
{ 
     /* appearance of a 'checked' icon */
    background-color: rgb(81, 81, 81);
    color: palette(highlight);
    border: 1px solid palette(highlight);
}

 
QMenu::icon
{
     border-radius: 0px;
     margin-left: -1px;
     padding-top: 5px;
     padding-right: 3px;
     padding-bottom: 1px;
     padding-left: 4px;
}


QMenu::separator 
{
     height: 1px;
     background-color: rgb(81, 81, 81);
     margin-left: 1px;
     margin-right: 1px;
     margin-top: 3px;
     margin-bottom: 3px;
}

QMenu::indicator 
{
    width: 11px;
    height: 10px;
    margin-left: 4px;
}

/* non-exclusive indicator = check box style indicator (see QActionGroup::setExclusive) */
QMenu::indicator:non-exclusive:unchecked 
{
    image: none;
}

QMenu::indicator:non-exclusive:unchecked:selected {
    image: none;
}

QMenu::indicator:non-exclusive:checked {
    image: url(:/metro/images/menu_checkbox_indicator_orange.png);
}

QMenu::indicator:non-exclusive:checked:selected {
    image: url(:/metro/images/menu_checkbox_indicator_backgroundcolor.png);
}

/* exclusive indicator = radio button style indicator (see QActionGroup::setExclusive) */
QMenu::indicator:exclusive:unchecked 
{
    image: none;
}

QMenu::indicator:exclusive:unchecked:selected 
{
    image: none;
}

QMenu::indicator:exclusive:checked 
{
    image: url(:/metro/images/menu_checkbox_indicator_orange.png);
}

QMenu::indicator:exclusive:checked:selected 
{
    image: url(:/metro/images/menu_checkbox_indicator_backgroundcolor.png);
}

QMenu::right-arrow
{
    image: url(:/metro/images/menu_right_arrow.png);
    padding-right: 5px;
}

QMenu::right-arrow:selected
{
    image: url(:/metro/images/menu_right_arrow_backgroundcolor.png);
}

QMenu::right-arrow:disabled
{
    image: url(:/metro/images/menu_right_arrow_disabled.png);
}


/*===========================================================================
 * QMenuBar
 *===========================================================================*/
QMenuBar
{
    background-color: rgb(51, 51, 51);
    color: rgb(227, 227, 227);
}

QMenuBar::item:selected:!disabled 
{
     color: rgb(51, 51, 51);
     background-color: palette(highlight);
}

QMenuBar::item 
{
    border: none;
    padding-top: 3px;
    padding-bottom: 3px;
    padding-left: 6px;
    padding-right: 6px;
    margin-right: 3px;
    margin-top: 1px;
    margin-bottom: 1px;
    border-radius: 0px;
}
 
/*===========================================================================
 * QToolBar
 *===========================================================================*/
QToolBar
{
    background-color: rgb(51, 51, 51);
    border: none;
    padding: 6px;
    spacing: 6px;
}



QToolBar::handle:vertical
{
    background-image: url(:/metro/images/toolbar_handle_single.png);
    background-repeat: repeat-x;
    margin-left: 4px;
    margin-right: 4px;
    height: 12px;
}

QToolBar::handle:horizontal
{
    background-image: url(:/metro/images/toolbar_handle_single.png);
    width: 14px;
    background-repeat: repeat-y;
	margin-top: 4px;
	margin-bottom: 4px;
}


QToolBar::separator:horizontal
{
    width: 1px;
    background-color: rgb(81, 81, 81);
    margin-top:6px;
    margin-bottom: 6px;
    margin-left: 2px;
    margin-right: 2px;
}

QToolBar::separator:vertical
{
    height: 1px;
    background-color: rgb(81, 81, 81);
    margin-top: 2px;
    margin-bottom: 2px;
    margin-left: 6px;
    margin-right: 6px;
}


 
/*===========================================================================
 * QToolButton
 *===========================================================================*/
QToolButton
{
	background-color: none;
    border: 1px solid transparent;
    padding: 4px;
    font-size: 10px;
}


QToolButton[vsmall="true"]
{
	padding: 0px;
	padding-left: 3px;
	padding-right: 3px;
}
 
 
QToolButton:hover
{
    border: 1px solid rgb(102, 102, 102);
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                    stop:0 rgb(55, 55, 55), 
                    stop:1 rgb(44, 44, 44));
}

QToolButton:pressed
{
    background-color: rgb(81, 81, 81);
    color: palette(highlight);
    border-color: rgb(81, 81, 81);
}


QToolButton:checked:!pressed
{
    background-color: rgb(81, 81, 81);
    color: palette(highlight);
    border-color: palette(highlight);
}

QToolBarExtension
{
	padding:0px;
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                                      stop:0 rgb(110, 110, 110), 
                                      stop:1 rgb(94, 94, 94));
}


QToolBarExtension:hover
{
	border: 1px solid rgb(146, 146, 146);
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                                      stop:0 rgb(110, 110, 110), 
                                      stop:1 rgb(94, 94, 94));
}

/*===========================================================================
 * QToolBar#sidebar
 *===========================================================================*/

QToolBar#sidebar > QToolButton
{
    width: 64px;
    height: 64px;
}

/* all too buttons are grey tiles */
/*QToolBar#sidebar > QToolButton:checked:!pressed
{
    color: rgb(51, 51, 51);
    border-color: 1px solid qlineargradient(x1:0, y1:0, x2:1, y2:1, 
                                      stop:0 rgb(222, 126, 9), 
                                      stop:1 palette(highlight)); 
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1, 
                                      stop:0 rgb(222, 126, 9), 
                                      stop:1 palette(highlight));
}


QToolBar#sidebar > QToolButton:hover:!checked
{
    background: rgb(102, 102, 102);
}*/


QToolBar#sidebar > .QToolButton:checked:!pressed
{
    color: rgb(51, 51, 51);
    border: 1px solid qlineargradient(x1:0, y1:0, x2:1, y2:1, 
                                      stop:0 rgb(222, 126, 9), 
                                      stop:1 palette(highlight)); 
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1, 
                                      stop:0 rgb(222, 126, 9), 
                                      stop:1 palette(highlight));
}


/*===========================================================================
 * QPushButton
 *===========================================================================*/
 

QPushButton
{
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                                      stop:0 rgb(70, 70, 70), 
                                      stop:1 rgb(60, 60, 60));
    border: 1px solid rgb(81, 81, 81);
    /*min-height: 12px;*/
    padding: 5px;
}

QPushButton:focus
{
    border-color: palette(highlight);
}

QPushButton:hover
{
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                                      stop:0 rgb(88, 88, 88), 
                                      stop:1 rgb(72, 72, 72));
}

QPushButton:hover:!focus
{
	border: 1px solid rgb(101, 101, 101);
}

QPushButton:pressed
{
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                                      stop:0 rgb(60, 60, 60), 
                                      stop:1 rgb(70, 70, 70));
    color: palette(highlight);
    border-color: rgb(81, 81, 81);
}


QPushButton:checked
{
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                                      stop:0 rgb(60, 60, 60), 
                                      stop:1 rgb(70, 70, 70));
    color: palette(highlight);
    border-color: palette(highlight);
}

QPushButton:checked:hover
{
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                                      stop:0 rgb(72, 72, 72), 
                                      stop:1 rgb(88, 88, 88));
}


QDialogButtonBox > QPushButton
{
    min-width: 70px;
}

QDialogButtonBox  > QPushButton#ok
{
    qproperty-icon: url(:/metro/images/check2_16.png);
}

QDialogButtonBox  > QPushButton#cancel
{
    qproperty-icon: url(:/metro/images/delete2_16.png);
}

 
 
/*===========================================================================
 * QDockWidget
 *===========================================================================*/
QDockWidget::title 
{
    text-align: left; /* align the text to the left */
    background-color: rgb(81, 81, 81);
    padding-left: 5px;
    border-none;
}


QDockWidget::title:hover
{
    border-left: 5px solid palette(highlight);
    padding-left: 0px;
}

 
QDockWidget 
{
    font-weight: bold;
    color: rgb(146, 146, 146);
    titlebar-normal-icon: url(:/metro/images/dockwidget_float_button.png);
    titlebar-close-icon: url(:/metro/images/dockwidget_close_button.png);
    border:  1px solid rgb(81, 81, 81);
}


QDockWidget::close-button,
QDockWidget::float-button
{
	border-radius: 0px;
}

QDockWidget::close-button:hover,
QDockWidget::float-button:hover
{
	border: 1px solid rgb(146, 146, 146);
}

QDockWidget::close-button:pressed,
QDockWidget::float-button:pressed
{
    border: 1px solid rgb(146, 146, 146);
    background: rgb(51, 51, 51);
}


QDockWidget[floating="false"] > QWidget
{
    margin-left: 1px;
    margin-right: 1px;
    margin-bottom: 1px;
}


QDockWidget QDialog
{
     border: none;
}

QDockWidget > QWidget
{
	border: none;
	background: rgb(51, 51, 51);
}



/*===========================================================================
 * QLineEdit
 *===========================================================================*/
QLineEdit
{
    background: rgb(51, 51, 51);
    border: 1px solid rgb(81, 81, 81);
    selection-background-color: rgba(247, 138, 9, 127);
    padding-left:   2px;
    padding-right:  2px;
    padding-top:    3px;
    padding-bottom: 3px;
}

QLineEdit:read-only
{
    background: transparent;
}


QLineEdit:focus:!read-only
{
    border-color: palette(highlight);
}



/*===========================================================================
 * QTextEdit, QPlainTextEdit
 *===========================================================================*/
QTextEdit,
QPlainTextEdit
{
    background: rgb(41, 41, 41);
    border: 1px solid rgb(81, 81, 81);
    selection-background-color: rgba(247, 138, 9, 127);
    padding-left:   2px;
    padding-right:  2px;
    padding-top:    3px;
    padding-bottom: 3px;
}

QTextEdit:read-only,
QPlainTextEdit:read-only
{
    background: transparent;
}

QTextEdit:focus:!read-only,
QPlainTextEdit:focus:!read-only
{
    border-color: palette(highlight);
}


/*===========================================================================
 * QComboBox
 *===========================================================================*/
QComboBox
{
    border: 1px solid rgb(81, 81, 81);
    background-color: rgb(51, 51, 51);
    padding: 2px;
}

QComboBox:focus, QComboBox:on
{   
    border-color: palette(highlight);
}


QComboBox::drop-down
{
    border: none;
    border-left: 1px solid transparent;
    width: 20px;
    margin-left: 6px;
}

QComboBox::drop-down:hover
{
    background: rgb(61, 61, 61);
    border-left: 1px solid rgb(81, 81, 81);   
}

QComboBox::drop-down:on
{
    background: rgb(81, 81, 81);
    border-left: 1px solid rgb(81, 81, 81);   
}

QComboBox::down-arrow
{
    image: url(:/metro/images/combobox_down_arrow.png);  
}

QComboBox QAbstractItemView 
{
    border: 1px solid rgb(81, 81, 81);
    border-top: 1px solid palette(highlight);
    background-color: rgb(51, 51, 51);
    selection-background-color: palette(highlight);
    selection-color: rgb(51, 51, 51);
    padding: 1px;
}

QComboBox QAbstractItemView::item
{
    padding-top: 2px;
    padding-bottom: 2px;
}


QComboBox[emphasize="true"]
{
    color: palette(highlight);
    font-size: 14pt;	
}



/*===========================================================================
 * QCompleter popup configuratoion
 *===========================================================================*/
QAbstractItemView#completerPopup 
{
    border: 1px solid rgb(81, 81, 81);
    padding: 1px;
}

QAbstractItemView#completerPopup::item 
{
    padding-top: 2px;
    padding-bottom: 2px;
}


/*===========================================================================
 * QAbstractSpinBox
 *===========================================================================*/
QAbstractSpinBox
{
	background: rgb(51, 51, 51);
    border: 1px solid rgb(81, 81, 81);
    selection-background-color: rgba(247, 138, 9, 127);
    padding-top: 3px;
    padding-bottom: 3px;
    padding-left: 2px;
    padding-right: 2px;
}


QAbstractSpinBox:focus:!read-only
{
	border-color: palette(highlight);
}

QAbstractSpinBox:disabled,
QAbstractSpinBox:read-only
{
    background: transparent;
}


QAbstractSpinBox::up-button,
QAbstractSpinBox::down-button
{
    border-left: 1px solid rgb(81, 81, 81);
    background: rgb(51, 51, 51);
}

QAbstractSpinBox::up-button:disabled,
QAbstractSpinBox::down-button:disabled
{
    background: transparent;
}


QAbstractSpinBox::up-button:hover
{
    background: rgb(81, 81, 81);
}

QAbstractSpinBox::down-button:hover
{
    background: rgb(81, 81, 81);
}

QAbstractSpinBox::up-button:pressed
{
    background: rgb(51, 51, 51);
    border-bottom: 1px solid rgb(81, 81, 81);
}

QAbstractSpinBox::down-button:pressed
{
    background: rgb(51, 51, 51);
    border-top: 1px solid rgb(81, 81, 81);
}


QAbstractSpinBox::up-arrow
{
    image: url(:/metro/images/spinbox_up_arrow.png);
}

QAbstractSpinBox::down-arrow
{
     image: url(:/metro/images/spinbox_down_arrow.png);
}


QAbstractSpinBox::up-arrow:disabled
{
    image: url(:/metro/images/spinbox_up_arrow_disabled.png);
}

QAbstractSpinBox::down-arrow:disabled
{
     image: url(:/metro/images/spinbox_down_arrow_disabled.png);
}


QAbstractItemView > QWidget > QAbstractSpinBox::down-button
{
    margin-bottom: 1px;
    margin-right: 1px;
}



QAbstractItemView > QWidget > QAbstractSpinBox::up-button
{
    margin-top: 1px;
    margin-right: 1px;
}

/*===========================================================================
 * QDateTimeEdit
 *===========================================================================*/
QDateTimeEdit::drop-down
{
    border-style: none;;
}

QDateTimeEdit[calendarPopup="true"]::down-arrow
{
    image: url(:/metro/images/combobox_down_arrow.png);  
}
 
 
 
/*===========================================================================
 * QDial
 *===========================================================================*/
QDial
{
    background-color: grey;
}


/*===========================================================================
 * QSlider vertical
 *===========================================================================*/
QSlider:vertical
{
    min-width: 21px;
    max-width: 21px;
    padding-top: 5px;
    padding-bottom: 5px;	
} 
 
QSlider::groove:vertical
{   
    width: 3px;
    border: 1px solid rgb(81, 81, 81);
    background: rgb(61, 61, 61);
}

QSlider::groove:vertical:disabled
{

}

QSlider::handle:vertical
{
     border: 1px solid rgb(146, 146, 146);
     background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                                      stop:0 rgb(108, 108, 108), 
                                      stop:1 rgb(92, 92, 92));
     width: 19px;
     height: 8px;
     margin-top: -5px;
     margin-bottom: -5px;
     margin-left: -9px;
     margin-right: -9px;
}

QSlider::handle:vertical:disabled
{

}

QSlider::add-page:vertical
{
    background: palette(highlight);
    border: 1px solid rgb(81, 81, 81);
}

QSlider::add-page:vertical:disabled 
{

}


/*===========================================================================
 * QSlider horizontal
 *===========================================================================*/
 
QSlider:horizontal
{
    color: red;
    min-height: 21px;
    max-height: 21px;
    padding-left: 5px;
    padding-right: 5px;
} 
 
QSlider::groove:horizontal
{
    height: 3px;
    border: 1px solid rgb(81, 81, 81);
    background: rgb(61, 61, 61);
}

QSlider::groove:horizontal:disabled
{

}

QSlider::handle:horizontal 
{
     border: 1px solid rgb(146, 146, 146);
     background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                                      stop:0 rgb(108, 108, 108), 
                                      stop:1 rgb(92, 92, 92));
     width: 8px;
     height: 19px;
     margin-top: -9px;
     margin-bottom: -9px;
     margin-left: -5px;
     margin-right: -5px;
}

QSlider::handle:horizontal:disabled
{

}

QSlider::sub-page:horizontal 
{
    background: palette(highlight);
    border: 1px solid rgb(81, 81, 81);
}



/*===========================================================================
 * QGroupBox
 *===========================================================================*/
QGroupBox
{
    border: none;
    background: rgb(61, 61, 61);
    border-radius: 0px;
    padding: 4px;
    padding-top: 24px;
    font-size: 9pt;
}

QGroupBox QLineEdit,
QGroupBox QAbstractSpinBox
{
    border-color: rgb(91, 91, 91);
}


/*
 * This group box style tests for the property "hasTitle". This is a dynamic
 * property that a group box should set if the title string is empty
 */
QGroupBox[hasTitle="no"]
{
    padding-top: 4px;  
}

/*
 * If the group box sourrounds an graphics view, than we do not want padding
 */
QGroupBox[graphicsView="true"]
{
    padding-left: 0px;
	padding-right: 0px;
	padding-bottom: 0px;
	border-bottom-left-radius: 0px;
	border-bottom-right-radius: 0px;
}
 
 
QGroupBox::title 
{
    subcontrol-position: top left;
    subcontrol-origin: padding;
    left: 4px;
    top:  4px;
}

QGroupBox[header="true"]
{
    color: palette(highlight);
    font-size: 9pt;
}

QGroupBox::indicator
{
    border: 1px solid rgb(81, 81, 81);
    background: rgb(51, 51, 51);
    background-repeat: no-repeat;
    background-position: center;
    width: 15px;
    height: 15px;
    padding: 0px;
}

QGroupBox::indicator::checked
{
   image: url(:/metro/images/checkbox_indicator.png);
   image-position: center;
}


/*===========================================================================
 * QRadioButton
 *===========================================================================*/
QRadioButton
{
    spacing: 8px;
    padding-top: 2px;
    padding-bottom: 2px;
}

QRadioButton::disabled
{
    color: rgb(81, 81, 81);
}

QRadioButton::indicator
{
    border: none;
    background: none;
    width: 18px;
    height: 18px;
    background-repeat: no-repeat;
    background-position: center;
    background-image: url(:/metro/images/radiobutton_background.png);
}

QRadioButton::indicator::checked
{
    image: url(:/metro/images/radiobutton_indicator.png);
    image-position: center;
}


QRadioButton::indicator::disabled::checked
{
    background-image: url(:/metro/images/radiobutton_indicator_disabled.png);
}


/*===========================================================================
 * QCheckBox
 *===========================================================================*/
QCheckBox
{
    spacing: 8px;
}

QCheckBox::disabled
{
    color: rgb(81, 81, 81);
}

QCheckBox::indicator
{
    border: 1px solid rgb(81, 81, 81);
    background: rgb(51, 51, 51);
    background-repeat: no-repeat;
    background-position: center;
    width: 15px;
    height: 15px;
    padding: 0px;
}

QCheckBox::indicator::checked
{
   image: url(:/metro/images/checkbox_indicator.png);
   image-position: center;
}


QCheckBox::indicator::disabled::checked
{
    image: url(:/metro/images/checkbox_rounded_indicator_disabled.png);
    image-position: center;
}


QCheckBox[header="true"]
{
    color: palette(highlight);
    font-size: 9pt;
}

QCheckBox[branch="true"]
{
	spacing: 2px;
}


QCheckBox[branch="true"]::indicator
{
    image: url(:/metro/images/treeview_branch_closed.png);
    border: none;
    background: none;
    width: 10px;
    height: 10px;
    background: none;
}


QCheckBox[branch="true"]::indicator::checked
{
   image: url(:/metro/images/treeview_branch_open.png);
   image-position: left;
}



/*===========================================================================
 * QAbstractItemView
 *===========================================================================*/
QAbstractItemView
{
    background-color: rgb(51, 51, 51);
    border: 1px solid rgb(81, 81, 81);
    alternate-background-color: rgba(60, 60, 60, 255);
    gridline-color: rgb(81, 81, 81);
}


QAbstractItemView::item:hover:!selected
{
   background-color: rgb(102, 102, 102);
   color: rgb(51, 51, 51);
}

QAbstractItemView::item:selected
{
    background-color: palette(highlight);
    color: rgb(51, 51, 51);
}

QListView::item QLineEdit
{
    background: rgb(51, 51, 51);
    border: none;
    selection-background-color: rgba(247, 138, 9, 127);
    padding: 0px;
}



/*===========================================================================
 * QHeaderView
 *===========================================================================*/
QHeaderView
{
    background-color: rgb(51, 51, 51);
    border: none;
}

QHeaderView::section:checked
{
     color: palette(highlight);
     font-weight: normal;
     font-style: normal;
}

/* horizontal ---------------------------------*/
QHeaderView::section:horizontal
{
     /*background-color: rgb(81, 81, 81); filled style*/
     background-color: rgb(61, 61, 61);
     padding: 3px;
     border: none;
     border-bottom: 1px solid rgb(87, 81, 81);
}


QHeaderView::section:horizontal:middle,
QHeaderView::section:horizontal:first
{
     border-right: 1px solid rgb(81, 81, 81);
}


/*QHeaderView::section:horizontal:first
{
     border-left: 1px solid rgb(81, 81, 81);
}*/

QHeaderView::section:horizontal:last
{
     border-right: 1px solid rgb(81, 81, 81);
}

QHeaderView::down-arrow
{
    image: url(:/metro/images/headerview_down_arrow.png);
}

QHeaderView::up-arrow
{
    image: url(:/metro/images/headerview_up_arrow.png);
}


/* vertical ---------------------------------*/
QHeaderView:vertical
{
    border: none;
}

QHeaderView::section:vertical
{
     background-color: rgb(51, 51, 51);
     padding: 3px;
     border: 1px solid rgb(67, 67, 67);
     border-top: none;
     border-bottom: 1px solid rgb(67, 67, 67);
     border-left: none;
}


QHeaderView > QLineEdit
{ 
    background: rgb(41, 41, 41);
}

QHeaderView > QLineEdit:!focus
{ 
    border: none;
	margin-bottom: 1px;
}



QHeaderView > QToolButton
{
    margin-top: 0px;
    padding: 0px;
}



/*===========================================================================
 * QTableView
 *===========================================================================*/
QTableView QTableCornerButton::section 
{
     background-color: rgb(51, 51, 51);
     border-top: none;
     border-left: none;
     border-right: 1px solid rgb(81, 81, 81);
     border-bottom: 1px solid rgb(81, 81, 81);
}


QTableView
{
	qproperty-showGrid: true;
	qproperty-alternatingRowColors: false;
}

/*
QTableView::item
{
	border-right: 1px solid rgb(67, 67, 67);
	border-bottom: 1px solid rgb(67, 67, 67);	
}*/


QTableView#eventLog
{
    qproperty-showGrid: false;
    qproperty-alternatingRowColors: true;   
}

QTableView QScrollBar:vertical
{
    border-right: 1px solid rgb(81, 81, 81);
}

QTableView QScrollBar::add-line:vertical
{
    border-right: 1px solid rgb(81, 81, 81);
    border-bottom: 1px solid rgb(81, 81, 81);
}


QTableView QScrollBar::sub-line:vertical
{
    border-right: 1px solid rgb(81, 81, 81);
}


/*===========================================================================
 * QTreeView
 *===========================================================================*/
QTreeView::branch:has-children:!has-siblings:closed,
QTreeView::branch:closed:has-children:has-siblings 
{
    border-image: none;
    image: url(:/metro/images/treeview_branch_closed.png);
}


QTreeView::branch:open:has-children:!has-siblings,
QTreeView::branch:open:has-children:has-siblings  
{
    border-image: none;
    image: url(:/metro/images/treeview_branch_open.png);
}


/*===========================================================================
 * QGraphicsView
 *===========================================================================*/
QGraphicsView
{
    background: #333333;
    border: none;
}

/*===========================================================================
 * QScrollBar horizontal
 *===========================================================================*/ 
QScrollBar:horizontal 
{
    background-color: rgb(61, 61, 61);
    border: none;
    height: 16px;
    margin-left: 0px;
    margin-right: 0px;
    padding: 0px;
}


QScrollBar:horizontal:disabled
{
    background-color: rgb(61, 61, 61);
}


QScrollBar::add-line:horizontal,
QScrollBar::sub-line:horizontal
{
    border: none;
    background-color: rgb(61, 61, 61);
}

QScrollBar::add-line:horizontal:hover,
QScrollBar::sub-line:horizontal:hover
{
    background-color: rgb(81, 81, 81);
}

QScrollBar::add-line:horizontal:pressed,
QScrollBar::sub-line:horizontal:pressed
{
    background-color: rgb(61, 61, 61);
}

QScrollBar::handle:horizontal:pressed,
QScrollBar::handle:horizontal:hover
{
	background: rgb(102, 102, 102);
	border: 1px solid rgb(146, 146, 146);
}


QScrollBar::handle:horizontal:disabled,
QScrollBar::add-line:horizontal:disabled,
QScrollBar::sub-line:horizontal:disabled
{
    background-color: rgb(61, 61, 61);
}


QScrollBar::handle:horizontal 
{
    border: none;
    background-color: rgb(81, 81, 81);
    min-width: 10px;
    margin-left: 20px;
    margin-right: 20px;
    margin-top: 3px;
    margin-bottom: 3px;
}

 
QScrollBar::add-line:horizontal 
{
    width: 17px;
    subcontrol-position: right;
}

QScrollBar::sub-line:horizontal 
{
    width: 17px;
    subcontrol-position: left;
}

QScrollBar:left-arrow:horizontal
{
     image: url(:/metro/images/scrollbar_left_arrow.png);
}

QScrollBar:right-arrow:horizontal
{
     image: url(:/metro/images/scrollbar_right_arrow.png);
}


/*===========================================================================
 * QScrollBar vertical
 *===========================================================================*/
QScrollBar:vertical 
{
    background-color: rgb(61, 61, 61);
    width: 16px;
    border: none;
    margin-top: 0px;
    margin-bottom: 0px;
    padding: 0px;
}


QScrollBar:vertical:disabled
{
    background-color: rgb(61, 61, 61);
}


QScrollBar::add-line:vertical,
QScrollBar::sub-line:vertical
{
    border: none;
    background-color: rgb(61, 61, 61);
}

QScrollBar::add-line:vertical:hover,
QScrollBar::sub-line:vertical:hover
{
    background-color: rgb(81, 81, 81);
}

QScrollBar::add-line:vertical:pressed,
QScrollBar::sub-line:vertical:pressed
{
    background-color: rgb(61, 61, 61);
}



QScrollBar::handle:vertical:pressed,
QScrollBar::handle:vertical:hover
{
    background: rgb(102, 102, 102);
    border: 1px solid rgb(146, 146, 146);
}


QScrollBar::handle:vertical:disabled,
QScrollBar::add-line:vertical:disabled,
QScrollBar::sub-line:vertical:disabled
{
    background-color: rgb(61, 61, 61);
}


QScrollBar::handle:vertical 
{
    /*border: 1px solid rgb(102, 102, 102);*/
    background-color: rgb(81, 81, 81);
    margin-left: 3px;
    margin-right: 3px;
    margin-top: 20px;
    margin-bottom: 20px;
    min-height: 10px;
}
 
QScrollBar::add-line:vertical
{
    height: 17px;
    subcontrol-position: bottom;
}

QScrollBar::sub-line:vertical 
{
    height: 17px;
    subcontrol-position: top;
}

QScrollBar:up-arrow:vertical
{
     image: url(:/metro/images/scrollbar_up_arrow.png);
}

QScrollBar:down-arrow:vertical
{
     image: url(:/metro/images/scrollbar_down_arrow.png);
}


/*===========================================================================
 * QScrollBar
 *===========================================================================*/
QScrollBar::sub-line:pressed, 
QScrollBar::add-line:pressed,
QScrollBar::handle:pressed 
{

}
 
QScrollBar::add-page, 
QScrollBar::sub-page
{
    background: transparent;
}


/*===========================================================================
 * QToolTip
 *===========================================================================*/
QToolTip
{
    border: 1px solid rgb(64, 64, 64);
    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, 
                                      stop:0 rgba(255, 249, 151), 
                                      stop:1 rgba(211, 205,  98));
    color: black;
}


/*===========================================================================
 * QLabel
 *===========================================================================*/
QLabel
{
    color: rgb(227, 227, 227);
}

QLabel#headerLabel
{
    color: rgba(20, 138, 189, 255);
    border: 1px;
    border-bottom: 1px solid rgba(20, 138, 189, 255);
    padding-bottom: 15px;
    font-size: 11pt;
} 

QLabel[header="true"]
{
    color: palette(highlight);
    font-size: 9pt;
}

QLabel[bignumber="true"]
{
    color: palette(highlight);
    font-size: 20px;
}

QLabel[border="true"]
{
    border: 1px solid rgb(81, 81, 81);
}

/*===========================================================================
 * QDialog
 *===========================================================================*/
QDialog
{
    background: #333333;
}

QFrame#line
{
    border: none;
    background: #666666;
    max-height: 1px;
}


QFrame[border="true"]
{
	border: 1px solid rgb(81, 81, 81);
}


/*===========================================================================
 * QSizeGrip - the size grip in the right border of the main window
 *===========================================================================*/
QSizeGrip
{
    image: url(:/metro/images/sizegrip.png);
}


/*===========================================================================
 * QStatusBar
 *===========================================================================*/
QStatusBar::item
{
     border-left: 1px solid #595959;

}

QStatusBar
{
    min-height: 24px;
}

QStatusBar 
{
    background: #333333;
}

/*QtLabb--Core--CStatusBarProgressIndicator
{
	background: yellow;
}*/


/*===========================================================================
 * QFileDialog
 *===========================================================================*/
QFileDialog > QToolButton
{
    padding: 0px;   
}

/*===========================================================================
 * QToolBox
 *===========================================================================*/
 
QToolBox
{
    background: rgb(51, 51, 51);
	icon-size: 24px;
}

/*QToolBox > QScrollArea > QWidget > QWidget 
{
    background: rgb(51, 51, 51);
    padding: -9px;	
}*/


QToolBox > QScrollArea
{
    background: rgb(51, 51, 51);
    padding: -9px; 
}


QToolBox::tab
{
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                                      stop:0 rgb(55, 55, 55), 
                                      stop:1 rgb(44, 44, 44));
    border: 1px solid rgb(81, 81, 81);
    color: #cccccc;
    padding-right: 5px;
    padding-left: 14px;
    background-repeat: no-repeat;
    background-image: url(:/metro/images/toolbox_tab_closed.png);
    background-position: center left;
}


QToolBox::tab:selected
{
    background-color: rgb(81, 81, 81);
    color: palette(highlight);
    border-color: palette(highlight);
    background-image: url(:/metro/images/toolbox_tab_open.png);
    background-position: center left;
}


/*===========================================================================
 * QCalendarWidget
 *===========================================================================*/
QWidget#qt_calendar_navigationbar
{
    background: palette(highlight);
}

QWidget#qt_calendar_navigationbar QToolButton:!hover:!pressed
{
    color: rgb(51, 51, 51);
}


/*===========================================================================
 * External libraries
 *===========================================================================*/
 
 /*===========================================================================
 * QtLabb Library
 *===========================================================================*/
QtLabb--Core--CWorkbenchManager > QWidget#qt_scrollarea_viewport > QtLabb--CStyledWidget
{
    border: 1px solid rgb(81, 81, 81);
}

QtLabb--Core--CWorkbenchManager > QWidget#qt_scrollarea_viewport > QFrame
{
    border: 1px solid rgb(81, 81, 81);
}



Qvi--CLiveImageDisplay
{
    background: black;
    border: none;
}


Qvi--CCameraSettingsWidget QLabel#exposureSettingsLabel,
Qvi--CCameraSettingsWidget QLabel#cameraFeaturesLabel
{
    color: palette(highlight);
    font-size: 9pt;
}

QtLabb--CValvePositionConfigWidget QLabel#valveLabel,
QtLabb--CValvePositionConfigWidget QLabel#positionsLabel
{
    color: palette(highlight);
    font-size: 9pt;
}


/*===========================================================================
 * CRulerWidget
 *===========================================================================*/
QtLabb--CRulerWidget
{
    color: rgb(146, 146, 146); /*textcolor*/
    border: none;
    font-size: 8px;
}


QtLabb--CImageViewer
{
    background-color: #333333;
}

QtLabb--CPositioningMap
{
    background-color: #333333;
}


/*===========================================================================
 * CDialEx
 *===========================================================================*/
QtLabb--CDialEx
{
    background-color: rgb(60, 60, 60);
}


/*===========================================================================
 * QWizard
 *===========================================================================*/
 
 /*main wizard background */
QWizard > QWidget
{
    background: rgb(51, 51, 51);
}


/*watermark container, complete page, buttons*/
QWizard > QWidget > .QWidget,
QWizard > QWidget > .QFrame
{
    background: rgb(51, 51, 51);
}

/* watermark image*/
QWizard > QWidget > QWidget > QWidget
{
    background: rgb(51, 51, 51);
}

QWizard QLabel#wizardTitleLabel
{
    font: normal 12pt;
    color: palette(highlight); 
}

QWizard QLabel#wizardWatermarkPixmapLabel
{
    border: 1px solid rgb(81, 81, 81);
}

QWizardPage
{
	padding: 0px;
}

QWizard QAbstractButton[wizardButton="true"]
{
	min-width: 70px;
}

QWizard QAbstractButton#wizardNext
{
    qproperty-icon: url(:/metro/images/navigate_right_16.png);
}

QWizard QAbstractButton#wizardBack
{
    qproperty-icon: url(:/metro/images/navigate_left_16.png);
}

QWizard QAbstractButton#wizardFinish
{
    qproperty-icon: url(:/metro/images/check2_16.png);
}

QWizard QAbstractButton#wizardCancel
{
    qproperty-icon: url(:/metro/images/delete2_16.png);
}


/*===========================================================================
 * QProgressIndicator
 *===========================================================================*/
QProgressIndicator
{
    qproperty-color: palette(highlight);
}


/*===========================================================================
 * QtLabb--CHeaderWidget
 *===========================================================================*/
QtLabb--CHeaderWidget
{
    background-color: rgb(51, 51, 51);
    border: none;
    padding: 0px;
    padding-left: 9px;
}

QtLabb--CHeaderWidget QLabel#captionLabel
{
    /*font-size: 16pt;
	font-family: "Segoe WP Light";*/
	font-size: 12pt;
	color: palette(highlight);
}


/*===========================================================================
 * QtLabb--CAboutDialog
 *===========================================================================*/
QtLabb--CAboutDialog QFrame#contentFrame
{
    background: rgb(41, 41, 41);
}

QtLabb--CAboutDialog QLabel#applicationLabel
{
    font-size: 13pt;	
    font-weight: normal;
    color: palette(highlight);
}

QtLabb--CAboutDialog QLabel#urlLabel
{ 
    color: palette(highlight);
    text-decoration: underline; 
}

/*===========================================================================
 * QtLabb--Core--CActivationDialog
 *===========================================================================*/
 QtLabb--Core--CProductActivationDialog QLabel#titleLabel
{	
	font: 12pt;
    color: rgb(20, 138, 189); 
}

 QtLabb--Core--CProductActivationDialog QFrame#titleFrame
{	
	border-top: 1px solid transparent;
	border-left: 1px solid transparent;
	border-right: 1px solid transparent;
	border-bottom: 1px solid #7f7f7f;
}

QtLabb--Script--CScriptDoubleSpinBox
{
    background-image: url(:/metro/images/var_indicator_orange.png);
    background-position: center left;
    background-repeat: no-repeat;
    padding-left: 16px;
}

QtLabb--Script--CScriptLineEdit
{
    background-image: url(:/metro/images/var_indicator_orange.png);
    background-position: center left;
    background-repeat: no-repeat;
    padding-left: 16px;
}


/*===========================================================================
 * QtLabb--CHintWidget
 *===========================================================================*/
QtLabb--CHintWidget
{
    border: 1px solid rgb(81, 81, 81);
    border-left: 6px solid palette(highlight);
    background: rgb(61, 61, 61);
}


QtLabb--CHintWidget > QLabel
{
   background: none;
}


/*===========================================================================
 * QtLabb--Core--CMainWindow
 *===========================================================================*/
QtLabb--Core--CMainWindow
{
	qproperty-drawDockTabBarBase: false;
}

QtLabb--Core--CFutureProgressV2
{
	background: rgb(61, 61, 61);
    margin-bottom: 6px;
}

QtLabb--Core--CProgressView
{
	padding: 6px;
}


/*===========================================================================
 * QtLabb--CScriptTreeView
 *===========================================================================*/
QtLabb--CScriptTreeView
{
	qproperty-currentFunctionBrush: rgb(0, 117, 170, 255);
	qproperty-functionActiveBrush: rgb(0, 117, 170, 50);
	
    qproperty-captionColor: rgb(227, 227, 227);                               
    qproperty-parametersColor: rgba(255, 255, 255, 160);
    qproperty-statusColor: palette(highlight);
   
    qproperty-mouseOverCaptionColor: rgb(41, 41, 41);                               
    qproperty-mouseOverParametersColor: rgb(51, 51, 51);
    qproperty-mouseOverStatusColor: palette(highlight);
    
    qproperty-selectedCaptionColor: rgb(51, 51, 51);  
    qproperty-selectedParametersColor: rgb(51, 51, 51, 180);
    qproperty-selectedStatusColor: rgb(51, 51, 51);
    
    qproperty-currentFunctionCaptionColor: rgb(41, 41, 41);                               
    qproperty-currentFunctionParametersColor: rgb(41, 41, 41, 180);
    qproperty-currentFunctionStatusColor: palette(highlight);
    
    qproperty-functionActiveCaptionColor: rgb(227, 227, 227);                               
    qproperty-functionActiveParametersColor: rgba(255, 255, 255, 160);
    qproperty-functionActiveStatusColor: palette(highlight);
}


/*===========================================================================
 * QtLabb qwt library
 *===========================================================================*/
QtLabb--CStylablePlot
{
    qproperty-majorGridColor: rgb(51, 51, 51);
    qproperty-majorGridPenStyle: SolidLine;
    qproperty-minorGridColor: rgb(61, 61, 61);
    qproperty-minorGridPenStyle: SolidLine;
    /* font family, pointSizeF, pixelSize, QFont::StyleHint, QFont::Weight, 
       QFont::Style, underline, strikeOut, fixedPitch, rawMode*/
    qproperty-yAxisTitleFont: "none,10,-1,5,0,0,0,0,0,0";
    qproperty-xAxisTitleFont: "none,10,-1,5,0,0,0,0,0,0";
    qproperty-xAxisTitleColor: palette(highlight);
    qproperty-yAxisTitleColor: palette(highlight);
}

QwtPlotCanvas
{
    border: none;
    background: rgb(31, 31, 31);
}


QwtLegend,
QwtLegend QWidget,
QWidget#QwtLegendViewContents
{
    background: rgb(61, 61, 61);
}


QwtScaleWidget
{
    color: rgb(146, 146, 146);
    font-size: 9px;
}

QToolBar#plotToolBar > QToolButton
{
    padding: 2px;
}

QwtKnob
{
    color: rgb(133, 133, 133);
    font-size: 9px;
    qproperty-knobColor: rgb(51, 51, 51);
    qproperty-borderWidth: 1;
}



