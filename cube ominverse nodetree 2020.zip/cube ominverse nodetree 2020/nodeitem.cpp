#include"nodeitems.h"

void ConnectionItem::sendDataAcrossConnetion()
{
    if(startSocketItem!=NULL && endSocketItem!=NULL)
    {
        if(startSocketItem->getSocketDataType()== endSocketItem->getSocketDataType()
                || endSocketItem->getSocketDataType()==NODE_MULTI_DATA_TYPE)
        {
            MultiDataType * dat = startSocketItem->getSocketData();

            endSocketItem->setSocketData(dat);

            if(_debug)
                printf("Data sent along connection\n");

            QPen pen1;

            pen1.setWidthF(1.0f);
            pen1.setColor(Qt::black);

            QBrush brush;
            brush.setColor(Qt::cyan);
            brush.setStyle(Qt::SolidPattern);

            deletorItem->setBrush(brush);
            deletorItem->setPen(pen1);

        }
        else
        {
            if(_debug)
                printf("no connection:");

            QPen pen1;

            pen1.setWidthF(1.0f);
            pen1.setColor(Qt::black);

            QBrush brush;
            brush.setColor(Qt::red);
            brush.setStyle(Qt::SolidPattern);

            deletorItem->setBrush(brush);
            deletorItem->setPen(pen1);

        }
    }
    /*


    MultiDataType * dat = startSocketItem->getSocketData();

    endSocketItem->setSocketData(dat);

    printf("Data sent along connection\n");
    */


}
