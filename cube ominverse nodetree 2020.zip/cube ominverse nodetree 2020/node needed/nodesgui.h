#ifndef NODESGUI
#define NODESGUI

#include<QtGui>
/*
#include "nodes.h"
#include "nodeitems.h"


class NodeVectorComposeItem : public NodeBaseItem
{

public:

    enum { EntityType = NODE_NODEVECTORCOMPOSE };

    int type() const { return EntityType; }


    //NodeBase * node;

    NodeVectorCompose * node;

    NodeVectorComposeItem(QGraphicsItem *parent =0):NodeBaseItem(parent)
    {
        node = new NodeVectorCompose;
    }

    void initialiseInputsAndOutputs()
    {



    }
};
*/


#endif // NODESGUI

