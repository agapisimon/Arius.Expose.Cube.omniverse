/*
__author__ = 'AGAPI SIMON'
copyright 2015
mittisimone@gmail.com

project: cube omniverse nodetree
*/


#ifndef STANDARDMODEL_H
#define STANDARDMODEL_H
#include<QtGui>
#include<QStandardItemModel>
/*
class listViewModel :  public QStandardItemModel
{
public:
    listViewModel()
    {

    }

    QStringList mmimeTypes()
    {
        QStringList ll(QString("Node/name"));
        return ll;
    }

    QMimeData * mimeData(const QModelIndexList &indexes)
    {
       QMimeData * mimedata =new QMimeData;

       for(int i=0;i<indexes.size();i++)
       {
          QModelIndex idx = indexes[i];

           if( idx.isValid())
           {
               QVariant txt = data(idx, Qt::DisplayRole);

               mimedata->setData(QString("Node/name"), txt.toByteArray());
           }
       }

       return mimedata;
    }
};

*/

#endif // STANDARDMODEL_H
