/*
__author__ = 'AGAPI SIMON'
copyright 2015
mittisimone@gmail.com

project: cube omniverse nodetree
*/

#ifndef GRAPHICSVIEW
#define GRAPHICSVIEW

#include<QtGui>

#include<nodesgui.h>
//#include "nodesgui.h"
#include "nodesmanager.h"
#include "utilities.h"
#include<nodeitems.h>

/*
QList<QString> nodenames;
QStringList nodelist;
nodelist.append(nodenames);
*/

enum
{
    INSERTNODE,
    INSERTCONNECTIONNODE,
    INSERTDECRIPTIONNODE,
};

class ScreenCapture : public QWidget
{
    Q_OBJECT

    QTimer *timer;
    int frameCount;
    int frameCounter;
    int fps;
    float  msec;

    QWidget * source;

public:
    ScreenCapture(QWidget* parent=0):QWidget(parent)
    {
        frameCount = 100;
        fps = 25;
        msec = 1000.0f/fps;
        timer  = new QTimer;
        timer->setInterval(msec);
        frameCounter = 0;
    }
    void setCaptureSource(QWidget * _source)
    {
        source = _source;
    }

    void captureFrameRange()
    {
        for(int i=0;i<frameCount;i++)
        {
            QPixmap piximage = QPixmap::grabWidget(source,source->rect());

            QString fileName = "Image"+QString::number(i)+".png";

            piximage.save(fileName);

            //piximage.save(QString(":/"));
        }
    }

public slots:

    void startCapture()
    {
        timer->start();
        frameCounter = 0;
    }

    void stopCapture()
    {
        timer->stop();
        frameCounter = 0;
    }

    void capturePerFrame()
    {
        frameCounter += 1;

        QPixmap piximage = QPixmap::grabWidget(source,source->rect());

        QString fileName = "Image"+QString::number(frameCounter)+".png";

        piximage.save(fileName);
    }

protected:

    void timerEvent(QTimerEvent *event)
    {
        if(timer)
            capturePerFrame();

        QWidget::timerEvent(event);
    }
};

class NavigatorView :public QFrame
{
    float margin = 50;

    QRectF frameRect;
    QPixmap alphaCannel;

    QGraphicsView * viewEntireScene;
    QGraphicsView * view;



public:
    float myscale = 0.1;

    NavigatorView(QWidget * parent=0):QFrame(parent)
    {
        setAttribute(Qt::WA_TranslucentBackground);

        //setCursor(Qt::CrossCursor);
        setCursor(Qt::OpenHandCursor);

        viewEntireScene = new QGraphicsView;

        viewEntireScene->setParent(this);

        viewEntireScene->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        viewEntireScene->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        //viewEntireScene->hide();
    }

    void setViewScene(QGraphicsScene * scene)
    {
        viewEntireScene->setScene(scene);
    }


    void resizeEvent(QResizeEvent * event)
    {
        view =( QGraphicsView *)this->parentWidget();

        if(view)
        {
            viewEntireScene->setScene(view->scene());

            //float aspectratio = qMax(this->size().width(),this->size().height());
            //QRectF  viewrect = view->sceneRect().adjusted(1,1,-1,-1);
            //QSizeF s = viewrect.size().toSize();

            //viewEntireScene->resize();
            viewEntireScene->resize(this->size());
            //viewEntireScene->centerOn();
            //viewEntireScene->move(this->pos());
        }
    }



    /*
     * slow  approach
    bool resized = false;
    void paintEvent(QPaintEvent *event)
    {
        QPainter painter;

        painter.begin(this);

        view =( QGraphicsView *)this->parentWidget();

        if(view)
        {
            if(!resized)
            {
                viewEntireScene->resize(view->sceneRect().size().toSize());
                viewEntireScene->setScene(view->scene());
                resized = true;
            }

            hide();
            QPixmap piximage = QPixmap::grabWidget(viewEntireScene,viewEntireScene->rect());
            show();
            piximage.scaledToWidth(height());

            alphaCannel = piximage;
            alphaCannel.fill(Qt::gray);
            piximage.setAlphaChannel(alphaCannel);
            painter.drawPixmap(rect(),piximage);
        }

        painter.drawRect(rect().adjusted(1,1,-1,-1));
        painter.end();
    }
    */

    /*

    void mousePressEvent(QMouseEvent *event)
    {
        printf("mouse press enter\n");

        QFrame::mousePressEvent(event);
    }

    void mouseReleaseEvent(QMouseEvent *event)
    {
        printf("mouse release\n");

        QFrame::mouseReleaseEvent(event);
    }
    void mouseMoveEvent(QMouseEvent *event)
    {
        printf("mouse move\n");
        QFrame::mouseMoveEvent(event);
    }

    */
};

class Navigator : public QFrame
{

    float margin = 50;
    QRectF frameRect;
    QPixmap alphaCannel;

public:
    float myscale = .1;

    Navigator(QWidget * parent=0):QFrame(parent)
    {
        setAttribute(Qt::WA_TranslucentBackground);

        //setCursor(Qt::CrossCursor);
        setCursor(Qt::OpenHandCursor);
    }


    void paintEvent(QPaintEvent *event)
    {
        QPainter painter;

        painter.begin(this);

        QGraphicsView * view =( QGraphicsView *)this->parentWidget();

        if(view)
        {
            hide();
            QPixmap piximage = QPixmap::grabWidget(view,view->rect());
            show();
            piximage.scaledToWidth(height());
            alphaCannel = piximage;
            alphaCannel.fill(Qt::gray);
            piximage.setAlphaChannel(alphaCannel);
            painter.drawPixmap(rect(),piximage);
        }

        painter.drawRect(rect().adjusted(1,1,-1,-1));
        painter.end();
    }

    /*

    void mousePressEvent(QMouseEvent *event)
    {
        printf("mouse press enter\n");

        QFrame::mousePressEvent(event);
    }

    void mouseReleaseEvent(QMouseEvent *event)
    {
        printf("mouse release\n");

        QFrame::mouseReleaseEvent(event);
    }
    void mouseMoveEvent(QMouseEvent *event)
    {
        printf("mouse move\n");
        QFrame::mouseMoveEvent(event);
    }
    */

};

class NavigatorViewExt : public QGraphicsView
{
public:
};




class NodeCollection : public QGraphicsView
{
    int nodeIndex;
    int insertNodeMode;

    int InteractiveMode = CREATING;

    QList<NodeBaseItem*> nodes;
    QList<ConnectionItem*> connections;

    Navigator * navigator;
    NavigatorView * navigatorviewEntireScene;
    NavigatorViewExt *navigatorView;


public:

    enum NodeDragMode
    {
        CREATING,
        RESIZING,
        DRAGGING,
        NONE,
    };

    QGraphicsLineItem * InteractiveLine;
       bool addgrid =false;
    NodeCollection( QWidget *parent = 0 ):QGraphicsView(parent)
    {
        InteractiveLine = new QGraphicsLineItem;




        navigator = new Navigator;
        navigator->setParent(this);
        navigator->resize(navigator->myscale *width(), navigator->myscale * height());
        navigator->move(width()*(1 - .15), height()*(1 - .15));

        /*
        navigatorviewEntireScene = new NavigatorView;
        navigatorviewEntireScene->setParent(this);
        navigatorviewEntireScene->resize(navigatorviewEntireScene->myscale *width(), navigatorviewEntireScene->myscale * height());
        navigatorviewEntireScene->move(width()*(1 - .15), height()*(1 - .15));


        navigatorView = new NavigatorViewExt;
        navigatorView->setParent(this);
        navigatorView->resize(.1 *width(), .1 * height());
        navigatorView->move(width()*(1 - .15), height()*(1 - .15));
        navigatorView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        navigatorView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        */

        QPen pen;

        pen.setWidthF(1.5f);
        pen.setColor(Qt::cyan);
        pen.setStyle(Qt::DashDotLine);
        pen.setCapStyle(Qt::RoundCap);
        pen.setJoinStyle(Qt::RoundJoin);

        InteractiveLine->setPen(pen);

        //setCacheMode(QGraphicsView::CacheBackground);
        setViewportUpdateMode(QGraphicsView::BoundingRectViewportUpdate);
        //setViewportUpdateMode(QGraphicsView::FullViewportUpdate);
        //setRenderHint(QPainter::Antialiasing);

        //setViewportUpdateMode(QGraphicsView::SmartViewportUpdate);

        setRenderHints(QPainter::Antialiasing | QPainter::SmoothPixmapTransform);

        timerId =0;
        nodeIndex = 0;
        insertNodeMode = 0;

        //setInteractiveMode(CREATING);
        setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        setDragMode(ScrollHandDrag); //panning
        setInteractive(true);

    }


    void resizeEvent(QResizeEvent *event)
    {
        navigator->resize(navigator->myscale *width(), navigator->myscale * height());
        navigator->move(width()*(1 - .15), height()*(1 - .15));


       /*
        navigatorviewEntireScene->setViewScene(this->scene());
        navigatorviewEntireScene->resize(navigatorviewEntireScene->myscale *width(), navigatorviewEntireScene->myscale * height());
        navigatorviewEntireScene->move(width()*(1 - .15), height()*(1 - .15));

        navigatorView->setScene(this->scene());

        navigatorView->resize(.1 *width(), .1 * height());
        navigatorView->move(width()*(1 - .15), height()*(1 - .15));
        */
    }

    void centerOnNode(QGraphicsItem * centerItem)
    {
        centerOn(centerItem);
    }

    void fitNodesInView()
    {
        //fitInView()
    }


    void viewTransfromations()
    {
        this->setGeometry(QRect(50, 50, 400, 200));

        /*
        this->rotate();
        this->translate();
        this->scale();
        this->transform();
        */
    }

    /*

    void resizeEvent(QResizeEvent *event)
    {

    }

    */

    void ZoomViewAtPoint(QWheelEvent* event)
    {
        double scaleFactor = 1.05;

        if (event->modifiers() & Qt::ControlModifier)
            scaleFactor += 0.3;

        if(event->delta() < 0)
            scaleFactor = 1.0 / scaleFactor;

        scale(scaleFactor, scaleFactor);

        centerOn( mapToScene(event->pos()) );
    }


    void scaleGraphicsView(qreal scaleFactor)
    {
        qreal factor = transform().scale(scaleFactor, scaleFactor).mapRect(QRectF(0, 0, 1, 1)).width();

        if (factor < 0.1 || factor > 1.5)
            return;

        scale(scaleFactor, scaleFactor);

        //navigatorView->scale(scaleFactor,scaleFactor);
        //navigatorView->fitInView(this->scene()->sceneRect());

    }

    void zoomView(QWheelEvent *event)
    {
        float s = pow( 2.0f ,-1.0f * event->delta() / 240.0f );

        scaleGraphicsView(s);

        //centerOn( mapToScene(event->pos()) );
    }

    void wheelEvent(QWheelEvent *event)
    {
        zoomView(event);

        //ZoomViewAtPoint(event);

        QGraphicsView::wheelEvent(event);
    }

    bool drawingInteractiveLine = false;
    bool containsSocket = false;

    QPointF  prevPoint;

    class HitSocketInfo
    {
    public:

        HitSocketInfo(){}

        SocketItem * startStocketItem;
        SocketItem * endSocketItem;

        QPointF p1;
        QPointF p2;

        NodeBaseItem * getStartItemParent()
        {
            return dynamic_cast<NodeBaseItem*>(startStocketItem->parentItem());
        }

        NodeBaseItem * getEndItemParent()
        {
            return dynamic_cast<NodeBaseItem*>(endSocketItem->parentItem());
        }

    };

    HitSocketInfo hitselection;

    int NodeDrag_Mode = 0;

    SocketItem * getSocketAtPos(QPointF pos)
    {
        QList<QGraphicsItem*> items = scene()->items(pos);

        foreach( QGraphicsItem *item ,items)
        {
            if(endwith(typeid(*item).name(),"SocketItem") == 1) //safe guard check
            {
                SocketItem * socket =  qgraphicsitem_cast<SocketItem*>(item);

                if(socket)
                {
                    printf("SocketItem: %s\n",qPrintable(socket->socketNameItem->toPlainText()));

                    return socket;

                }
            }
        }

        return NULL;
    }

    NodeBaseItem * getNodeBaseItemUnderMouse()
    {
        QList<QGraphicsItem*> items = scene()->selectedItems();

        foreach( QGraphicsItem *item ,items)
        {
            NodeBaseItem * nodebaseitem =  (NodeBaseItem*)item;//very important casting

            if(nodebaseitem)
            {
                if(nodebaseitem->isUnderMouse())
                {
                    return nodebaseitem;

                }
            }
        }

        return NULL;
    }

    NodeBaseItem * getNodeBaseItemAtPos(QPointF pos)
    {
        QList< QGraphicsItem* > items = scene()->items(pos);

        foreach( QGraphicsItem *item ,items)
        {
            if(endwith(typeid(*item).name(),"NodeBaseItem")==1) //safe guard check
            {
                NodeBaseItem * nodebaseitem =  dynamic_cast<NodeBaseItem*>(item);

                if(nodebaseitem)
                {
                    printf("SocketItem: %s\n",qPrintable(nodebaseitem->label->toPlainText()));

                    return nodebaseitem;
                }
            }
        }

        return NULL;
    }

    void createConnection()
    {
        if(hitselection.startStocketItem && hitselection.endSocketItem)
        {
            if(hitselection.startStocketItem->ID != hitselection.endSocketItem->ID)
            {
                ConnectionItem * connection  = new ConnectionItem(hitselection.startStocketItem,hitselection.endSocketItem);

                connection->p1 = hitselection.startStocketItem->scenePos();
                connection->p2 = hitselection.endSocketItem->scenePos();

                connection->setConnectionType(ConnectionItem::BEZIER);

                hitselection.startStocketItem->addConnection(connection);
                hitselection.endSocketItem->addConnection(connection);

                scene()->addItem(connection);

                connections.append(connection);

                printf("Connection Created \n");
            }
        }
    }

    void createInteractiveLine(QMouseEvent *event)
    {
        if(event->buttons() & Qt::LeftButton)// && event->modifiers()&Qt::ControlModifier)
        {
            SocketItem * socket = getSocketAtPos(mapToScene( event->pos()));

            if(socket!=NULL && socket->getSocketType() ==SocketItem::OutPut)
            {
                drawingInteractiveLine = true;

                hitselection.startStocketItem =  socket;

                qDebug()<<"Socket Details:"<<socket<<"ScenePose:"<<socket->scenePos();

                QLineF line(mapToScene( event->pos()),mapToScene(event->pos()));

                InteractiveLine->setLine(line);

                scene()->addItem(InteractiveLine);

                if(socket->parentItem())
                {
                    NodeBaseItem *item = dynamic_cast<NodeBaseItem*>(socket->parentItem());

                    if(item)
                    {
                        //if(socket->getSocketType()==SocketItem::OutPut)
                        {
                            item->setFlag(QGraphicsItem::ItemIsMovable,false );
                        }

                        qDebug()<<"Node base Details:"<<item->label->toPlainText();
                    }
                }
            }
            else
            {
                scene()->clearSelection();

            }
        }
    }

    void updateInteractiveLine(QMouseEvent *event)
    {
        if(drawingInteractiveLine)
        {
            QLineF line = InteractiveLine->line();

            line.setP2( mapToScene( event->pos()) );

            InteractiveLine->setLine(line);
        }
    }

    void finaliseInteractiveLineCreation(QMouseEvent *event)
    {
        if(drawingInteractiveLine)
        {
            printf("Mouse release \n");

            SocketItem * socket = getSocketAtPos(  mapToScene( event->pos() ) );

            if( socket )
            {
                hitselection.endSocketItem =  socket;

                if( hitselection.startStocketItem->ID != hitselection.endSocketItem->ID )
                {
                    createConnection();

                    SocketItem * socket = hitselection.startStocketItem;

                    if(socket->parentItem())
                    {
                        NodeBaseItem *item = dynamic_cast<NodeBaseItem*>(socket->parentItem());

                        if(item)
                        {
                            item->setFlag(QGraphicsItem::ItemIsMovable,true );

                            qDebug()<<"Node base Details:"<<item->label->toPlainText();
                        }
                    }


                    qDebug()<<"Socket Details:"<<socket<<"ScenePose:"<<socket->scenePos()<<"socket ID:"<<socket->ID;

                }
            }

            scene()->removeItem(InteractiveLine);            

            drawingInteractiveLine = false;
        }
    }

    void deleteInteractiveLine(QKeyEvent *event)
    {
        if(event->key()==Qt::Key_Escape)
        {
            if(drawingInteractiveLine)
            {
               scene()->removeItem(InteractiveLine);

               drawingInteractiveLine = false;
            }
        }
    }

    void updateConnections(QMouseEvent * event)
    {
        if(event->buttons()& Qt::LeftButton)
        {
            //printf("Updating connections:\n");
            //printf("Items selected: %i \n",scene()->selectedItems().size());

            QList<QGraphicsItem*> items = scene()->selectedItems();

            foreach( QGraphicsItem *item ,items)
            {
                NodeBaseItem * nodebaseitem =  (NodeBaseItem*)item;//very important casting

                if(nodebaseitem)
                {
                    if(nodebaseitem->isUnderMouse())
                    {
                        foreach( SocketItem *socket ,nodebaseitem->inputs)
                        {
                            foreach( ConnectionItem *connector ,socket->getConnections())
                            {
                                connector->p2 = socket->scenePos();
                            }
                        }

                        foreach( SocketItem *socket ,nodebaseitem->outputs)
                        {
                            foreach( ConnectionItem *connector ,socket->getConnections())
                            {
                                connector->p1 = socket->scenePos();
                            }
                        }

                        scene()->update();

                        //printf(" NodeBaseItem connections:\n");

                        break;
                    }
                }

                /*
                if(endwith(typeid(*item).name(),"SocketItem")==1)
                {
                    printf("SocketItem ,Updating connections:\n");

                    break;
                }
                */
            }
        }

        update();
    }

    void panView(QMouseEvent *event)
    {
        if(event->buttons() & Qt::LeftButton && event->modifiers()& Qt::AltModifier)
        {
            ///more work required

            QPointF c = event->posF();;

            QPointF  delta =  c - prevPoint;

            qDebug()<<"View Translate:"<<delta;

            //translate(delta.x(),delta.y());

            scrollContentsBy((int)delta.x(),(int)delta.y());

            prevPoint = c;

            //update();
        }
    }



    void setInteractiveMode(int mode = CREATING)
    {
        InteractiveMode = mode;
    }


    void keyPressEvent(QKeyEvent *event)
    {
        //if (InteractiveMode = CREATING)
        {
            deleteInteractiveLine(event);
        }

        //if(InteractiveMode = RESIZING)
        {

        }
        //update();



        QGraphicsView::keyPressEvent(event);
    }


    void mouseReleaseEvent(QMouseEvent *event)
    {
        //if (InteractiveMode = CREATING)
        {
            finaliseInteractiveLineCreation(event);
            //update();
        }
        /*

        if(InteractiveMode = RESIZING)
        {
            NodeBaseItem  * node = getNodeBaseItemUnderMouse();

            if(node)
            {
                node->setFlag(QGraphicsItem::ItemIsMovable,true);
            }
        }
        */

        QGraphicsView::mouseReleaseEvent(event);
    }

    void mousePressEvent(QMouseEvent *event)
    {
        if(event->buttons()&Qt::LeftButton && event->modifiers() &Qt::ControlModifier)
        {
            this->setInteractiveMode(CREATING);
            printf("set Creation Node Mode:\n");
        }


        if(event->buttons() &Qt::LeftButton && event->modifiers() &Qt::AltModifier)
        {
            this->setInteractiveMode(RESIZING);
            printf("set Resize Node Mode:\n");
        }


        //if (InteractiveMode = CREATING)
        {
            createInteractiveLine(event);
           //update();
        }
        /*
        if(InteractiveMode  ==RESIZING)
        {
            NodeBaseItem  * node = getNodeBaseItemUnderMouse();

            if(node)
            {
                node->setFlag(QGraphicsItem::ItemIsMovable,false);
            }
        }
        */

        QGraphicsView::mousePressEvent(event);
    }

    void mouseMoveEvent(QMouseEvent *event)
    {
        //if (InteractiveMode = CREATING)
        {
           updateInteractiveLine(event);
        }
        /*

        if(InteractiveMode = RESIZING)
        {



        }
        */

        updateConnections(event);

        //panView(event);

        //qDebug()<<"View Mouse Move:";

        //update();

        QGraphicsView::mouseMoveEvent(event);
    }

    void dragEnterEvent(QDragEnterEvent *event)
    {
        qDebug()<<"drag Enter function:"<<event->mimeData()->text();

        for(int i=0;i<event->mimeData()->formats().size();i++)
        {
            //qDebug()<<"format"<<event->mimeData()->formats()[i];
        }

        if(event->mimeData()->hasText())
        {
            printf("drag Enter \n");
            event->accept();
        }

        QGraphicsView::dragEnterEvent(event);
    }

    void dragMoveEvent(QDragMoveEvent *event)
    {
        event->accept(); //very important

        //QGraphicsView::dragMoveEvent(event); never add  this
    }

    void dropEvent(QDropEvent *event)
    {
        event->accept();

        if(event->mimeData()->hasText())
        {
            //if(event->mimeData()->text().startsWith(QString("Node")))
            //{
                //add nodes here
            //}

            NodeBaseItem  *node = new NodeBaseItem();
            node->setFlag(QGraphicsPolygonItem::ItemIsSelectable , true);
            node->label->setPlainText(event->mimeData()->text());
            node->setPos(this->mapToScene(event->pos()));
            node->setToolTip(event->mimeData()->text());

            scene()->addItem(node);

            //navigatorView->fitInView(this->scene()->sceneRect());

            event->acceptProposedAction();
        }

        QGraphicsView::dropEvent(event);
    }

    int timerId;

    void StartTimer()
    {
        if (timerId)
            timerId = startTimer(1000 / 25);
    }

    void stopTimer()
    {
        killTimer(timerId);
        timerId = 0;
    }

    void timerEvent(QTimerEvent *event)
    {
        // compute node tree here
    }
};




#endif // GRAPHICSVIEW

