#ifndef CONNECTION_H
#define CONNECTION_H
#include<QtGui>

/*
class PortItem: public QGraphicsEllipseItem
{
public:
    QString name;
    QTextItem textItem;
    //Represents a port to a subsystem
    PortItem(QString name, QGraphicsItem *parent=0)
    {
        this->setRect(QRectF(-4,-4,8,8));
        setCursor(QCursor(Qt::CrossCursor));
        //Properties:
        setBrush(QBrush(Qt::red));
        //Name:
        name = name
        //self.posCallbacks = []
        setFlag(ItemSendsScenePositionChanges, true);
        //self.transform().translate(-4,-4)
        textItem =  QGraphicsTextItem(name);
        textItem.setPos(pos().x(),pos().y());
    }





    void itemChange(self, change, value)
    {
        if change == self.ItemScenePositionHasChanged:
            for cb in self.posCallbacks:
                cb(value)
                return value
        return super(PortItem, self).itemChange(change, value)
    }

    void mousePressEvent(QMouseEvent * event)
    {
        editor.startConnection(self)
    }
}

class Connection
{
public:
    Connection(self, fromPort, toPort)
    {
        self.fromPort = fromPort
        self.pos1 = QPointF(0,0)
        self.pos2 = QPointF(0,0)

        if fromPort:
            self.pos1 = fromPort.scenePos()
            fromPort.posCallbacks.append(self.setBeginPos)

        self.toPort = toPort
        # Create arrow item:
        self.arrow = ArrowItem()
        editor.diagramScene.addItem(self.arrow)
    }

    void setFromPort(fromPort)
    {
        self.fromPort = fromPort
        if self.fromPort:
            self.pos1 = fromPort.scenePos()
            self.fromPort.posCallbacks.append(self.setBeginPos)
    }

    void setToPort(self, toPort)
    {
        self.toPort = toPort
        if self.toPort:
             self.pos2 = toPort.scenePos()
             self.toPort.posCallbacks.append(self.setEndPos)
    }

    void setEndPos(self, endpos)
    {
        self.pos2 = endpos
        self.arrow.setLine(QLineF(self.pos1, self.pos2))
    }

    void setBeginPos(self, pos1)
    {
        self.pos1 = pos1
        self.arrow.setLine(QLineF(self.pos1, self.pos2))
    }

    void delete(self)
    {
        editor.diagramScene.removeItem(self.arrow)
        //Remove position update callbacks
    }
}*/

#endif // CONNECTION_H
