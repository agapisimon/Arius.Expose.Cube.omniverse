
/*
__author__ = 'AGAPI SIMON'
copyright 2015
mittisimone@gmail.com

project: cube omniverse nodetree
*/

#ifndef DIALOGITEM
#define DIALOGITEM

#include<QtGui>

class propertiesWidget : public QDialog
{

public:
    propertiesWidget(QDialog *parent=0):QDialog(parent)
    {

        QPushButton * button = new QPushButton(QString("Ok"));
        QVBoxLayout * layout = new QVBoxLayout;

        layout->addWidget(button);

        this->setLayout(layout);
        //QObject::connect(button,SIGNAL(clicked),this,SLOT(OK));
        //QObject::connect(button,SIGNAL(clicked),OK);
        //button.clicked.connect(OK);
    }
public slots:
    void OK()
    {
       close();
    }
};

#endif // DIALOGITEM

