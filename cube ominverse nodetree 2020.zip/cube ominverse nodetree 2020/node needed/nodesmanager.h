#ifndef NODESMANAGER
#define NODESMANAGER
#include <QtGui>
#include "nodesgui.h"

class NodesManager
{
    int nodeIndex;
    int insertNodeMode;

    QList<NodeBaseItem*> nodes;
    QList<ConnectionItem*> pipes;

public:

    void insertNode(const QPointF & p,QGraphicsScene *scene)
    {
        if(nodeIndex==NODE_NODEVECTORCOMPOSE)
        {
            NodeBaseItem  *node = new NodeVectorComposeItem;
            node->setFlag(QGraphicsItem::ItemIsSelectable , true);
            node->label->setPlainText(QString("Vector Combine"));
            node->setPos(p);

            scene->addItem(node);
            nodes.append(node);
        }

        if(nodeIndex==NODE_VECTORADD)
        {
            NodeBaseItem  *node = new NodeBaseItem;
            node->setFlag(QGraphicsItem::ItemIsSelectable , true);
            node->label->setPlainText(QString("Vector Addition"));
            node->setPos(p);
            scene->addItem(node);
            nodes.append(node);
        }

        if(nodeIndex== NODE_VECTORSUB)
        {
            NodeBaseItem  *node = new NodeBaseItem;
            node->setFlag(QGraphicsItem::ItemIsSelectable , true);
            node->label->setPlainText(QString("Vector Substraction"));
            node->setPos(p);
            scene->addItem(node);
            nodes.append(node);
        }

        if(nodeIndex== NODE_DESCRIPTION_NOTE)
        {
        }

        if(nodeIndex== NODE_NODEVECTORCOMPOSE)
        {
        }

        if(nodeIndex== NODE_VECTORSCALAR)
        {
        }


        if(nodeIndex== NODE_VECTORDIV)
        {
        }
        if(nodeIndex== NODE_VECTORCROSS)
        {
        }

        if(nodeIndex== NODE_VECTORDOT)
        {
        }

        if(nodeIndex== NODE_VECTORLENGTH)
        {
        }

        if(nodeIndex== NODE_VECTORDISTANCE)
        {
        }

        if(nodeIndex== NODE_VECTORREFLECT)
        {
        }

        if(nodeIndex== NODE_VECTORREFRACT)
        {
        }
    }
};



#endif // NODESMANAGER

