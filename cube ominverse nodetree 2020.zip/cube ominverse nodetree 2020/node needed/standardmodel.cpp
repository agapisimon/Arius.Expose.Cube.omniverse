#include "standardmodel.h"

standardModel::standardModel()
{

}

