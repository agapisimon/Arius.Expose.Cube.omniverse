#ifndef UTLITIES
#define UTLITIES
#include<stdlib.h>
#include<string>
#include <typeinfo>
#include<stdio.h>
#include <iostream>

namespace utils
{
    bool endwith( std::string value, std::string ending)
    {
        if(ending.size()>value.size())
            return false;
        return std::equal(ending.rbegin(),ending.rend(),value.rbegin());
    }
}


class GlobalSettings
{
public:

};

/*

bool endwith( const char *text, const char *ending)
{
    size_t text_len = strlen(text);
    size_t ending_len = strlen(ending);
    int cmp  = text_len - ending_len;
    if(cmp<0)
        return false;
    return strcmp(text+cmp,ending)==0;
}
*/
#endif // UTLITIES

