
/*
__author__ = 'AGAPI SIMON'
copyright 2015
mittisimone@gmail.com

project: cube omniverse nodetree
*/

#ifndef GRAPHICSSCENE
#define GRAPHICSSCENE

#include<QtGui>

class GraphicsScene : public QGraphicsScene
{
    Grid * grid;
public:
    GraphicsScene()
    {
        grid = new Grid;

        addItem(grid);

        setSceneRect(QRectF(0, 0, 4000, 4000));
    }
};


class NodesListView : public QListView
{
public:

    NodesListView(QWidget* parent =0):QListView(parent)
    {
        setIconSize(QSize(15,15));
    }

    void mouseReleaseEvent(QMouseEvent *event)
    {
        setCursor(Qt::OpenHandCursor);
        QListView::mouseReleaseEvent(event);
    }


    void selectionChanged(const QItemSelection &selected, const QItemSelection &deselected)
    {
        const QModelIndex index = this->selectionModel()->currentIndex();

        QString selectedText = index.data(Qt::DisplayRole).toString();

        qDebug()<<"Selection Change:"<<index;
        qDebug()<<"Selection Text:"<<selectedText;

        QListView::selectionChanged(selected,deselected);
    }

    void mousePressEvent(QMouseEvent *event)
    {
        setCursor(Qt::ClosedHandCursor);
        QListView::mousePressEvent(event);
    }

    void mouseMoveEvent(QMouseEvent *event)
    {
        QDrag * drag = new QDrag(this);

        QMimeData * mime = new QMimeData;

        drag->setMimeData(mime);

        const QModelIndex index = this->selectionModel()->currentIndex();

        QString selectedText = index.data(Qt::DisplayRole).toString();

        qDebug()<<"Selection Change:"<<index;
        qDebug()<<"Selection Text:"<<selectedText;

        //QString str("Node/name");
        mime->setText(selectedText);

        drag->exec();
        setCursor(Qt::OpenHandCursor);

        QListView::mouseMoveEvent(event);
    }    
};





#endif // GRAPHICSSCENE

