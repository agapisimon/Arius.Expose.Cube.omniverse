/*
__author__ = 'AGAPI SIMON'
copyright 2015
mittisimone@gmail.com

project: cube omniverse nodetree
*/

#ifndef NODETREE
#define NODETREE

#include<QtGui>
#include<vector>
#include<list>
#include<QStandardItem>
#include <QtXml>

#include<stdio.h>


//#include "standardmodel.h"
//#include "dialogitem.h"
#include "graphicsview.h"
#include "graphicsscene.h"
#include "nodeitems.h"

class nodeTreeXml
{
    QDomDocument * doc;

    QFile *file;

    QString xmlfileEmbedded;

    QXmlReader *xmlreader;

public:

    class ParentChildren
    {
    public:
        ParentChildren(){}

        QString name;

        QStringList childrenList;
    };

     QList<ParentChildren> rootNodesLists;


    nodeTreeXml()
    {
        doc  = new QDomDocument("NodeTree");

        ReadNodeTree();

        printAllNodeNames();
    }

    void printAllNodeNames()
    {
        printf("Parent Node: \n\n");

        for(int i=0;i<rootNodesLists.size();i++)
        {
            printf("Parent Node: %s \n",qPrintable(rootNodesLists[i].name));


            for(int j=0;j<rootNodesLists[i].childrenList.size();j++)
            {
                printf("child  Node: %s \n",qPrintable(rootNodesLists[i].childrenList[j]));

            }
        }

    }

    void ReadNodeTree()
    {

        file = new QFile(":/cubeOmniverseNodetree.xml");//file must be added in the resource file

        printf("Reading xml file %s\n",qPrintable(file->fileName()));

        if (file->open(QIODevice::ReadOnly)==false)
        {
             printf("Reading xml file failed \n");

             return;
        }

        if (doc->setContent(file)== false)
        {
            file->close();

            return;
        }

         file->close();

         printf("Parsing xml content \n");

         // print out the element names of all elements that are direct children
         // of the outermost element.
         QDomElement docElem = doc->documentElement();

         printf("Root Node: %s \n",qPrintable(docElem.nodeName()));

         QDomNodeList parentNodelist = docElem.childNodes();

         for(int i =0;i<parentNodelist.count();i++)
         {
             QDomNode parentNode = parentNodelist.at(i);

             printf("%s:\n",qPrintable(parentNode.nodeName()));

             if(parentNode.nodeName()=="copyright")
             {

             }

             if(parentNode.nodeName()=="NodeTypes")
             {

             }

             if(parentNode.nodeName()=="NodeTree")
             {
                 QDomNodeList childNodelist = parentNode.childNodes();

                 for(int child=0;child<childNodelist.count();child++)
                 {
                     QDomNode childnode = childNodelist.at(child);

                     printf("%s \n",qPrintable(childnode.nodeName()));


                     ParentChildren parentChildren;
                     parentChildren.name = childnode.nodeName();



                     if(childnode.hasAttributes())
                     {
                         QDomElement element = childnode.toElement();

                         for(int attributeIndex=0;attributeIndex<element.attributes().count();attributeIndex++)
                         {
                             QDomAttr attribute = element.attributeNode(QString("name"));

                             printf("Has attributes: %s \n",qPrintable(attribute.value()));
                         }
                     }


                     QDomNode sibling = childnode.firstChild();

                     while(sibling.isNull() == false)
                     {
                         QDomElement element = sibling.toElement();

                         if(element.isNull() == false)
                         {
                             QDomAttr attribute  = element.attributeNode(QString("name"));
                             QDomAttr attribute1 = element.attributeNode(QString("class"));

                             printf("Sibling Name: %s \n",qPrintable(element.nodeName()));

                             printf("Attribute Name: %s \n",qPrintable(attribute.value()));
                             printf("Attribute Class: %s \n",qPrintable(attribute1.value()));

                             parentChildren.childrenList.append(attribute.value());

                         }

                         sibling = sibling.nextSibling();
                     }


                     rootNodesLists.append(parentChildren);
                 }
             }
         }
    }
};


class nodeTreeEditor : public QWidget
{
    QList<QStandardItem*>  listviewItems;

public:
    NodeCollection* graphicsview;
    GraphicsScene * scene;    
    NodesListView * listview;

    QStandardItemModel * viewmodel;
    QItemSelectionModel * selectionModel;
    nodeTreeXml * nodesXml;


    //Connection startedConnection;
    //QList<NodeBaseItem*> nodes;
    //QList<Connection*> connections;



    nodeTreeEditor(QWidget * parent = 0)
    {
        setTheme();
        setTitleDetails();

        // Widget layout and child widgets:
        QVBoxLayout * layout   = new QVBoxLayout;
        QSplitter * splitter   = new QSplitter;

        splitter->setOrientation(Qt::Vertical);

        graphicsview  = new NodeCollection(this);
        viewmodel     = new QStandardItemModel;
        scene         = new GraphicsScene;
        listview      = new NodesListView;


        nodesXml =  new nodeTreeXml;

        viewmodel->setColumnCount(1);

        QIcon  icon(QString(":/cubeomniverse.svg"));
        /*

        for(int i=0;i<25;i++)
        {
            QStandardItem * d = new QStandardItem(icon,QString("Node:"+QString::number(i)));

            listviewItems.append( d);
        }
        */

        for(int i=0;i<nodesXml->rootNodesLists.size();i++)
        {
            for(int j=0;j<nodesXml->rootNodesLists[i].childrenList.size();j++)
            {
                QString nodeName = nodesXml->rootNodesLists[i].childrenList[j];

                //QStandardItem * nodeitem = new QStandardItem(icon,QString("Node:"+QString::number(i)));
                QStandardItem * nodeitem = new QStandardItem(icon,nodeName);

                listviewItems.append(nodeitem);
            }
        }

        for(int i=0;i<listviewItems.size();i++)
        {
            viewmodel->appendRow(listviewItems[i]);
        }

        listview->setModel(viewmodel);

        listview->setViewMode(QListView::IconMode);
        listview->setMaximumHeight(100);
        //listview->setDragDropMode(QListView::DragOnly);


        //selectionModel = listview->selectionModel();


        //connect(selectionModel, SIGNAL(selectionChanged (const QItemSelection &, const QItemSelection &)),
        //                 this, SLOT(selectionChangedSlot(const QItemSelection &, const QItemSelection &)));

        splitter->addWidget(graphicsview);
        splitter->addWidget(listview);

        layout->addWidget(splitter);

        //NodeBaseItem  * b1 = new NodeBaseItem; b1->setFlag(QGraphicsItem::ItemIsSelectable, true);
        //NodeBaseItem  * b2 = new NodeBaseItem; b2->setFlag(QGraphicsItem::ItemIsSelectable, true);

        //b1->setPos(50,100);
        //scene->addItem(b1);

        //b2->setPos(-250,0);
        //scene->addItem(b2);

        scene->setParent(this);
        graphicsview->setScene(scene);


        //startedConnection = None

        this->setLayout(layout);



    }

public slots:
    /*

    void selectionChangedSlot(const QItemSelection & , const QItemSelection & )
     {
         //get the text of the selected item
         const QModelIndex index = listview->selectionModel()->currentIndex();

         QString selectedText = index.data(Qt::DisplayRole).toString();

         qDebug()<<"Selection Change:"<<selectedText;

     }
    */

public:

    void setTheme()
    {
        QFile file(":/glowBlue.stylesheet");

        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
           setStyleSheet(file.readAll());
           file.close();
        }

        setWindowIcon(QIcon(":/cubeomniverse.svg"));

    }

    void setTitleDetails()
    {
       setWindowTitle(QString("CUBE Omniverse: node tree"));
    }
};








#endif // NODETREE

