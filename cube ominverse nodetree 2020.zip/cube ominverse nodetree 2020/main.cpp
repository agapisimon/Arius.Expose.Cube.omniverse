/*
__author__ = 'AGAPI SIMON'
copyright 2015
mittisimone@gmail.com

project: cube omniverse nodetree
*/


#include<QtWidgets>
#include<QtXml>

#include<stdlib.h>
#include<stdio.h>

#include<typeinfo>
#include<iostream>
#include<string>
#include<vector>
#include<list>
#include<omp.h>


#include "nodeitems.h"


bool endwith( std::string value, std::string ending)
{
    if(ending.size()>value.size())
        return false;

    return std::equal(ending.rbegin(),ending.rend(),value.rbegin());
}

/*
QList<QString> nodenames;
QStringList nodelist;
nodelist.append(nodenames);


enum
{
    INSERTNODE,
    INSERTCONNECTIONNODE,
    INSERTDECRIPTIONNODE,
};
*/

class ScreenCapture : public QWidget
{
    Q_OBJECT

    QTimer *timer;

    int frameCount;
    int frameCounter;
    int fps;

    float  msec;

    QWidget * source;

public:
    ~ScreenCapture()
    {
        delete timer;
        delete source;
    }

    ScreenCapture(QWidget* parent=0):QWidget(parent)
    {
        frameCount = 100;
        fps = 25;
        msec = 1000.0f/fps;
        timer  = new QTimer;
        timer->setInterval(msec);
        frameCounter = 0;
    }

    void setCaptureSource(QWidget * _source)
    {
        source = _source;
    }

    void captureFrameRange()
    {
        for(int i=0;i<frameCount;i++)
        {
            QPixmap piximage = QPixmap::grabWidget(source,source->rect());

            QString fileName = "Image"+QString::number(i)+".png";

            piximage.save(fileName);

            //piximage.save(QString(":/"));
        }
    }

public slots:

    void startCapture()
    {
        timer->start();
        frameCounter = 0;
    }

    void stopCapture()
    {
        timer->stop();
        frameCounter = 0;
    }

    void capturePerFrame()
    {
        frameCounter += 1;

        QPixmap piximage = QPixmap::grabWidget(source,source->rect());

        QString fileName = "Image"+QString::number(frameCounter)+".png";

        piximage.save(fileName);
    }

protected:

    void timerEvent(QTimerEvent *event)
    {
        if(timer)
            capturePerFrame();

        QWidget::timerEvent(event);
    }
};

class NavigatorView : public QFrame
{
    float margin = 50;

    QRectF frameRect;
    QPixmap alphaCannel;

    QGraphicsView * viewEntireScene;
    QGraphicsView * view;



public:
    float myscale = 0.1;

    ~NavigatorView()
    {
        delete viewEntireScene;
        delete view;
    }

    NavigatorView(QWidget * parent=0):QFrame(parent)
    {
        setAttribute(Qt::WA_TranslucentBackground);

        //setCursor(Qt::CrossCursor);
        setCursor(Qt::OpenHandCursor);

        viewEntireScene = new QGraphicsView;

        viewEntireScene->setParent(this);

        viewEntireScene->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        viewEntireScene->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        //viewEntireScene->hide();
    }

    void setViewScene(QGraphicsScene * scene)
    {
        viewEntireScene->setScene(scene);
    }


    void resizeEvent(QResizeEvent * event)
    {
        view =( QGraphicsView *)this->parentWidget();

        if(view)
        {
            viewEntireScene->setScene(view->scene());

            //float aspectratio = qMax(this->size().width(),this->size().height());
            //QRectF  viewrect = view->sceneRect().adjusted(1,1,-1,-1);
            //QSizeF s = viewrect.size().toSize();

            //viewEntireScene->resize();
            viewEntireScene->resize(this->size());
            //viewEntireScene->centerOn();
            //viewEntireScene->move(this->pos());
        }
    }



    /*
     * slow  approach
    bool resized = false;
    void paintEvent(QPaintEvent *event)
    {
        QPainter painter;

        painter.begin(this);

        view =( QGraphicsView *)this->parentWidget();

        if(view)
        {
            if(!resized)
            {
                viewEntireScene->resize(view->sceneRect().size().toSize());
                viewEntireScene->setScene(view->scene());
                resized = true;
            }

            hide();
            QPixmap piximage = QPixmap::grabWidget(viewEntireScene,viewEntireScene->rect());
            show();
            piximage.scaledToWidth(height());

            alphaCannel = piximage;
            alphaCannel.fill(Qt::gray);
            piximage.setAlphaChannel(alphaCannel);
            painter.drawPixmap(rect(),piximage);
        }

        painter.drawRect(rect().adjusted(1,1,-1,-1));
        painter.end();
    }
    */

    /*

    void mousePressEvent(QMouseEvent *event)
    {
        printf("mouse press enter\n");

        QFrame::mousePressEvent(event);
    }

    void mouseReleaseEvent(QMouseEvent *event)
    {
        printf("mouse release\n");

        QFrame::mouseReleaseEvent(event);
    }
    void mouseMoveEvent(QMouseEvent *event)
    {
        printf("mouse move\n");
        QFrame::mouseMoveEvent(event);
    }

    */
};

class Navigator : public QFrame
{

    float margin = 50;
    QRectF frameRect;
    QPixmap alphaCannel;

public:
    float myscale = .1;

    Navigator(QWidget * parent=0):QFrame(parent)
    {
        setAttribute(Qt::WA_TranslucentBackground);

        //setCursor(Qt::CrossCursor);
        setCursor(Qt::OpenHandCursor);
    }


    void paintEvent(QPaintEvent *event)
    {
        QPainter painter;

        painter.begin(this);

        QGraphicsView * view =( QGraphicsView *)this->parentWidget();

        if(view)
        {
            hide();
            QPixmap piximage = QPixmap::grabWidget(view,view->rect());
            show();
            piximage.scaledToWidth(height());
            alphaCannel = piximage;
            alphaCannel.fill(Qt::gray);
            //piximage.setAlphaChannel(alphaCannel);

            //piximage.setMask(alphaCannel.toImage().);
            painter.drawPixmap(rect(),piximage);
        }

        painter.drawRect(rect().adjusted(1,1,-1,-1));
        painter.end();
    }

    /*

    void mousePressEvent(QMouseEvent *event)
    {
        printf("mouse press enter\n");

        QFrame::mousePressEvent(event);
    }

    void mouseReleaseEvent(QMouseEvent *event)
    {
        printf("mouse release\n");

        QFrame::mouseReleaseEvent(event);
    }
    void mouseMoveEvent(QMouseEvent *event)
    {
        printf("mouse move\n");
        QFrame::mouseMoveEvent(event);
    }
    */

};

class QNodesListView : public QListWidget//QListView
{
    bool _debug = false;

public:
    void setDebugging(bool print = false)
    {
      _debug = print;
    }

    QNodesListView(QWidget* parent =0):QListWidget(parent)
    {
        setIconSize(QSize(15,15));


    }



    void resizeEvent(QResizeEvent *event)
    {
        //setGeometry(this->rect());
        showMaximized();

        QListWidget::resizeEvent(event);
    }



    void mouseReleaseEvent(QMouseEvent *event)
    {
        setCursor(Qt::OpenHandCursor);
        QListWidget::mouseReleaseEvent(event);
    }


    void selectionChanged(const QItemSelection &selected, const QItemSelection &deselected)
    {
        const QModelIndex index = this->selectionModel()->currentIndex();

        QString selectedText = index.data(Qt::DisplayRole).toString();

        if(_debug)qDebug()<<"Selection Change:"<<index;
        if(_debug)qDebug()<<"Selection Text:"<<selectedText;

        QListWidget::selectionChanged(selected,deselected);
    }

    void mousePressEvent(QMouseEvent *event)
    {
        setCursor(Qt::ClosedHandCursor);
        QListWidget::mousePressEvent(event);
    }

    void mouseMoveEvent(QMouseEvent *event)
    {
        QDrag * drag = new QDrag(this);

        QMimeData * mime = new QMimeData;

        drag->setMimeData(mime);

        const QModelIndex index = this->selectionModel()->currentIndex();

        QString selectedText = index.data(Qt::DisplayRole).toString();

        if(_debug)qDebug()<<"Selection Change:"<<index;
        if(_debug)qDebug()<<"Selection Text:"<<selectedText;

        //QString str("Node/name");
        mime->setText(selectedText);

        drag->exec();
        setCursor(Qt::OpenHandCursor);

        QListWidget::mouseMoveEvent(event);
    }
};


class QSearch : public QFrame
{
    Q_OBJECT

protected:

    QStringList nodeslists;

    QStringList hitslist;

    QLineEdit * lineEdit;

    QListView * listview;

    QStringListModel * model;

    QString selectedText;

public:

    ~QSearch()
    {
        delete model;
        delete lineEdit;
        delete listview;

    }


    QString getSelectedText()
    {
        return selectedText;
    }


    void _search(QString filter)
    {
        hitslist.clear();

        foreach( QString str, nodeslists)
        {
            if (str.contains(filter,Qt::CaseInsensitive))
            {
                hitslist.append(str);
            }
        }
    }

    QSearch(QStringList list,QWidget *parent = 0) : QFrame(parent)
    {
        nodeslists =  list;

        init();

        //setWindowFlags(Qt::FramelessWindowHint);

        setAttribute(Qt::WA_NoSystemBackground);
    }

    void init()
    {
        //list.removeDuplicates();
        nodeslists.sort();


        lineEdit = new QLineEdit;
        listview = new QListView;

        QPushButton * button =  new QPushButton;
        button->setIcon(QIcon(QString(":/search_icon.svg")));
        button->setDisabled(true);

        QHBoxLayout *slayout = new QHBoxLayout;
        slayout->addWidget(button);
        slayout->addWidget(lineEdit);
        QWidget * sframe  = new QWidget;
        sframe->setLayout(slayout);


        QVBoxLayout * layout =  new QVBoxLayout;

        layout->addWidget(sframe);
        layout->addWidget(listview);

        setLayout(layout);

        connect(lineEdit,SIGNAL(textChanged(QString)),this,SLOT(populateListView()));
        connect(listview,SIGNAL(clicked(QModelIndex)),this,SLOT(getSearchResults()));
        connect(lineEdit,SIGNAL(returnPressed()),this,SLOT(getSearchResults()));

        model = new QStringListModel;
        model->setStringList(nodeslists);
        listview->setModel(model);
    }

    void setFocus()
    {

        lineEdit->setFocus();
        lineEdit->setCursorPosition(0);
    }


private slots:

    void populateListView()
    {
        if(lineEdit->text().size()==0)
        {
            delete model;
            model = new QStringListModel;
            model->setStringList(nodeslists);
        }
        else
        {
            _search(lineEdit->text());
            delete model;
            model = new QStringListModel;
            model->setStringList(hitslist);
        }

        listview->setModel(model);

    }

    void getSearchResults()
    {
        QModelIndex index = listview->currentIndex();

        qDebug()<< index.data().toString();

        lineEdit->setText(index.data().toString());

        selectedText = index.data().toString();

        hide();

        emit valueChanged(selectedText);

        lineEdit->setText(QString(""));
        listview->reset();
        listview->clearSelection();
    }



signals:
    void valueChanged(QString filter);
};

class QSearchEx : public QFrame
{
    Q_OBJECT

    QIcon  icon;

    QString selectedText;

    QStringList nodeslists;

    QStringList hitslist;

    QStringListModel * model;

    QLineEdit * lineEdit;

    QListView * listview;

    QNodesListView * listviewWidget;

public:

    ~QSearchEx()
    {
        delete model;
        delete lineEdit;
        delete listview;
        delete listviewWidget;
    }

    QString getSelectedText()
    {
        return selectedText;
    }


    void _search(QString filter)
    {
        hitslist.clear();

        foreach( QString str, nodeslists)
        {
            if (str.contains(filter,Qt::CaseInsensitive))
            {
                hitslist.append(str);
            }
        }
    }

    QSearchEx(QStringList list,QWidget *parent = 0) : QFrame(parent)
    {
        icon = QIcon(QString(":/cubeomniverse.svg"));

        nodeslists =  list;

        init();

        //setWindowFlags(Qt::FramelessWindowHint);

        //setAttribute(Qt::WA_NoSystemBackground);
    }

    void init()
    {
        //list.removeDuplicates();
        nodeslists.sort();


        lineEdit = new QLineEdit;
        listview = new QListView;
        listviewWidget = new QNodesListView;


        QPushButton * button =  new QPushButton;
        button->setIcon(QIcon(QString(":/search_icon.svg")));
        button->setDisabled(true);

        QHBoxLayout *slayout = new QHBoxLayout;
        slayout->addWidget(button);
        slayout->addWidget(lineEdit);
        QWidget * sframe  = new QWidget;
        sframe->setLayout(slayout);


        QHBoxLayout * hlayout =  new QHBoxLayout;

        QWidget * frame  = new QWidget;

        QVBoxLayout * layout =  new QVBoxLayout;

        //layout->addWidget(lineEdit);
        layout->addWidget(sframe);
        layout->addWidget(listview);

        frame->setLayout(layout);

        QSplitter * splitter = new QSplitter(Qt::Horizontal);

        splitter->addWidget(frame);
        splitter->addWidget(listviewWidget);
        //hlayout->addLayout(layout);
        //hlayout->addWidget(listviewWidget);

        hlayout->addWidget(splitter);
        //setLayout(hlayout);
        setLayout(hlayout);

        connect(lineEdit,SIGNAL(textChanged(QString)),this,SLOT(populateListView()));
        connect(listview,SIGNAL(clicked(QModelIndex)),this,SLOT(getSearchResults()));
        connect(lineEdit,SIGNAL(returnPressed()),this,SLOT(getSearchResults()));

        model = new QStringListModel;
        model->setStringList(nodeslists);
        listview->setModel(model);

        listviewWidget->clear();

        foreach(QString nodename,nodeslists)
        {
            listviewWidget->addItem(new QListWidgetItem(icon,nodename));
        }

        listviewWidget->setViewMode(QListView::IconMode);

    }

    void setFocus()
    {
        lineEdit->setFocus();
        lineEdit->setCursorPosition(0);
    }


private slots:

    void populateListView()
    {
        if(lineEdit->text().size()==0)
        {
            delete model;
            model = new QStringListModel;
            model->setStringList(nodeslists);


            foreach(QString nodename,nodeslists)
            {
                listviewWidget->addItem(new QListWidgetItem(icon,nodename));
            }
        }
        else
        {
            _search(lineEdit->text());

            delete model;

            model = new QStringListModel;
            model->setStringList(hitslist);

            listviewWidget->clear();

            foreach(QString nodename,hitslist)
            {
                listviewWidget->addItem(new QListWidgetItem(icon,nodename));
            }
        }

        listviewWidget->setViewMode(QListView::IconMode);
        //listviewWidget->setMaximumHeight(150);

        listview->setModel(model);

    }

    void getSearchResults()
    {
        QModelIndex index = listview->currentIndex();

        qDebug()<< index.data().toString();

        lineEdit->setText(index.data().toString());

        selectedText = index.data().toString();

        //hide();

        emit valueChanged(selectedText);

        //lineEdit->setText(QString(""));
        //listview->reset();
        //listview->clearSelection();
    }



signals:
    void valueChanged(QString filter);
};

class NodeCollection : public QGraphicsView
{
    Q_OBJECT
public:
    enum NodeDragMode
    {
        CREATING,
        RESIZING,
        DRAGGING,
        NONE,
    };

private:

    NodeDragMode nodedragmode;

    int nodeIndex;
    int insertNodeMode;

    QList< NodeBaseItem* > nodes;
    QList< ConnectionItem* > connections;

    //Navigator * navigator;
    NavigatorView * navigatorviewEntireScene;
    //NavigatorViewExt *navigatorView;

    QMenu mainmenu;
    QMenu vectorsMenu;
    QMenu ArithmeticMenu;
    QMenu FloatValuesMenu;
    QMenu MathFunctionsMenu;
    QMenu groupsMenu;
    QMenu logicMenu;


    QStringList VectornodeList;
    QStringList ArithmeticNodeList;
    QStringList FloatValuesNodeList;
    QStringList MathFunctionsNodeList;
    QStringList groupsNodeList;
    QStringList logicNodeList;

    QStringList MatrixnodeList;
    QStringList QuatnodeList;
    QLineEdit *lineEdit;

    //TabStringListQLineEdit *completer;
    //self.tabstringlistWidget = TabStringListQLineEdit(self)  # TabStringListCombo(self)  # TabStringListWidget(self)
    //self.tabstringlistWidget.hide()
    bool _debug = false;

    QSearch * search;

public:

    ~NodeCollection()
    {
        delete search;
        delete lineEdit;
    }

    void setDebugging(bool print = false)
    {
        _debug =  print;
    }

     QStringList allnodes;

    void createMenu()
    {
        QIcon icon(QString(":/cubeomniverse.svg"));        

        VectornodeList.append(QString("Vector Addition"));
        VectornodeList.append(QString("Vector Subtraction"));
        VectornodeList.append(QString("Vector Compose"));
        VectornodeList.append(QString("Vector Decompose"));
        VectornodeList.append(QString("Vector Cross"));

        VectornodeList.append(QString("Vector Dot"));
        VectornodeList.append(QString("Vector Reflect"));
        VectornodeList.append(QString("Vector Refract"));
        VectornodeList.append(QString("Vector Scalar"));
        VectornodeList.append(QString("Vector Resize"));

        VectornodeList.append(QString("Vector Length"));
        VectornodeList.append(QString("Vector Distance"));
        VectornodeList.append(QString("Vector Project"));
        VectornodeList.append(QString("Vector Orthogonolize"));
        VectornodeList.append(QString("Vector Normalized"));
        VectornodeList.append(QString("Vector Random"));

        VectornodeList.sort();

        FloatValuesNodeList.append(QString("Float PIE"));
        FloatValuesNodeList.append(QString("Float E"));
        FloatValuesNodeList.append(QString("Float Value"));
        FloatValuesNodeList.append(QString("Float Random"));
        FloatValuesNodeList.sort();

        ArithmeticNodeList.append(QString("Add"));
        ArithmeticNodeList.append(QString("Subtract"));
        ArithmeticNodeList.append(QString("Multiply"));
        ArithmeticNodeList.append(QString("Divide"));

        ArithmeticNodeList.sort();

        MathFunctionsNodeList.append(QString("Cosh"));
        MathFunctionsNodeList.append(QString("Sinh"));
        MathFunctionsNodeList.append(QString("Tanh"));


        MathFunctionsNodeList.append(QString("Cos"));
        MathFunctionsNodeList.append(QString("Sin"));
        MathFunctionsNodeList.append(QString("Tan"));
        MathFunctionsNodeList.append(QString("Acos"));
        MathFunctionsNodeList.append(QString("Asin"));
        MathFunctionsNodeList.append(QString("Atan"));
        MathFunctionsNodeList.append(QString("Log"));
        //MathFunctionsNodeList.append(QString("LogE"));
        MathFunctionsNodeList.append(QString("Pow"));
        MathFunctionsNodeList.append(QString("Sqrt"));
        MathFunctionsNodeList.append(QString("Abs"));
        MathFunctionsNodeList.append(QString("Floor"));
        MathFunctionsNodeList.append(QString("Ceil"));
        MathFunctionsNodeList.append(QString("Round"));
        MathFunctionsNodeList.append(QString("Modulus"));
        MathFunctionsNodeList.append(QString("Exponent"));
        MathFunctionsNodeList.sort();

        groupsNodeList.append(QString("Description Note"));
        groupsNodeList.append(QString("Group"));
        groupsNodeList.append(QString("Socket Preview"));
        groupsNodeList.append(QString("Time"));
        MathFunctionsNodeList.sort();

        logicNodeList.append(QString("Equals"));
        logicNodeList.append(QString("LessThan"));
        logicNodeList.append(QString("GreaterThan"));
        logicNodeList.append(QString("Less or Equal"));
        logicNodeList.append(QString("Greater or Equal"));
        logicNodeList.append(QString("If Else"));
        logicNodeList.sort();

        vectorsMenu.setTitle(QString("Vector Maths"));
        FloatValuesMenu.setTitle(QString("Float Values"));
        MathFunctionsMenu.setTitle(QString("Math Functions"));
        ArithmeticMenu.setTitle(QString("Arithmetics"));
        groupsMenu.setTitle(QString("Groups"));
        logicMenu.setTitle(QString("Logic"));

        foreach(QString nodename,VectornodeList)
        {
            vectorsMenu.addAction(icon,nodename,this,SLOT(addNode()));
            allnodes.append(nodename);
        }

        foreach(QString nodename,FloatValuesNodeList)
        {
            FloatValuesMenu.addAction(icon,nodename,this,SLOT(addNode()));
            allnodes.append(nodename);
        }
        foreach(QString nodename,MathFunctionsNodeList)
        {
            MathFunctionsMenu.addAction(icon,nodename,this,SLOT(addNode()));
            allnodes.append(nodename);
        }
        foreach(QString nodename,ArithmeticNodeList)
        {
            ArithmeticMenu.addAction(icon,nodename,this,SLOT(addNode()));
            allnodes.append(nodename);
        }
        foreach(QString nodename,groupsNodeList)
        {
            groupsMenu.addAction(icon,nodename,this,SLOT(addNode()));
            allnodes.append(nodename);
        }

        foreach(QString nodename,logicNodeList)
        {
            logicMenu.addAction(icon,nodename,this,SLOT(addNode()));
            allnodes.append(nodename);
        }

        allnodes.sort();
        allnodes.removeDuplicates();

        search = new QSearch(allnodes,this);
        search->hide();

        connect(search,SIGNAL(valueChanged(QString)),this,SLOT(addNodeEx()));



        lineEdit = new QLineEdit(this);

        QCompleter *completer = new QCompleter(allnodes, this);

        completer->setMaxVisibleItems(15);
        completer->setCompletionMode(QCompleter::UnfilteredPopupCompletion);
        completer->setCaseSensitivity(Qt::CaseInsensitive);
        completer->setModelSorting(QCompleter::CaseInsensitivelySortedModel);


        lineEdit->setFixedWidth(250);
        lineEdit->setCompleter(completer);
        lineEdit->hide();
        lineEdit->setTextMargins(10, 5, 10, 5);

        QFont font;
        font.setPointSize(12);
        lineEdit->setFont(font);




        connect(lineEdit,SIGNAL(returnPressed()),this,SLOT(addNode()));
        //connect(lineEdit,SIGNAL(editingFinished()),this,SLOT(addNode()));



        mainmenu.addMenu(&vectorsMenu);
        mainmenu.addMenu(&FloatValuesMenu);
        mainmenu.addMenu(&ArithmeticMenu);
        mainmenu.addMenu(&MathFunctionsMenu);
        mainmenu.addMenu(&groupsMenu);
        mainmenu.addMenu(&logicMenu);

        QFile file(":/glowBlue.stylesheet");


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {

           QByteArray  style =file.readAll();
           mainmenu.setStyleSheet(style);
           vectorsMenu.setStyleSheet(style);
           ArithmeticMenu.setStyleSheet(style);
           FloatValuesMenu.setStyleSheet(style);
           MathFunctionsMenu.setStyleSheet(style);
           groupsMenu.setStyleSheet(style);
           logicMenu.setStyleSheet(style);

           lineEdit->setStyleSheet(style);

           /*
           lineEdit->setStyleSheet("color: blue;"
                                   "background-color: yellow;"
                                   "selection-color: yellow;"
                                    "selection-background-color: blue;"
                                  "item:alternate {  background: #EEEEEE;}"
                                  );
                                  */
           file.close();

        }
    }

    void processAddItemMenu(QKeyEvent * event)
    {
        if(event->modifiers()&Qt::ShiftModifier &&  event->key()==Qt::Key_A)
        {
            QPoint p = QCursor::pos();

            p += QPoint(-50,-10);

           mainmenu.move(p);
           mainmenu.show();

           QAction *selectedAction = mainmenu.exec();            

           if ( selectedAction != 0 )
           {
                 if(_debug)
                     printf("Clicked Action:\n");

                 addNode(selectedAction->text(),p);
                 printf(qPrintable(selectedAction->text()));
           }
        }
    }


    void processTabString(QKeyEvent *event)
    {
        if(event->key()==Qt::Key_Tab)
        {
            printf("Tab string List");

            QPoint p = mapFromGlobal(QCursor::pos());

            //completer->setPosition(p);
            //completer->processVisibility();
            //lineEdit->setPlaceholderText("Search for Nodes");
            lineEdit->setText(QString(""));


            lineEdit->move(p);
            lineEdit->setFocus();
            lineEdit->setCursorPosition(0);


            QCursor::setPos(p);

            if(lineEdit->isVisible())
            {
                lineEdit->hide();
            }
            else
            {
                lineEdit->show();
            }
        }

        if(event->key()==Qt::Key_Space)
        {
            printf("Tab string List");

            QPoint p = mapFromGlobal(QCursor::pos());

            search->move(p);

            if(search->isVisible())
            {
                search->hide();
            }
            else
            {
                search->show();
            }
        }
    }

    QList< ConnectionItem* > getCOnnections()
    {
        return connections;
    }

    NodeCollection( QWidget *parent = 0 ):QGraphicsView(parent)
    {

        //setViewport(new QGLWidget(QGLFormat(QGL::SampleBuffers)));
        /*
        navigator = new Navigator;
        navigator->setParent(this);
        navigator->resize(navigator->myscale *width(), navigator->myscale * height());
        navigator->move(width()*(1 - .15), height()*(1 - .15));

        */
        /*
        navigatorviewEntireScene = new NavigatorView;
        navigatorviewEntireScene->setParent(this);
        navigatorviewEntireScene->resize(navigatorviewEntireScene->myscale *width(), navigatorviewEntireScene->myscale * height());
        navigatorviewEntireScene->move(width()*(1 - .15), height()*(1 - .15));


        navigatorView = new NavigatorViewExt;
        navigatorView->setParent(this);
        navigatorView->resize(.1 *width(), .1 * height());
        navigatorView->move(width()*(1 - .15), height()*(1 - .15));
        navigatorView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        navigatorView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        */

        //setCacheMode(QGraphicsView::CacheBackground);
        setViewportUpdateMode(QGraphicsView::BoundingRectViewportUpdate);
        //setViewportUpdateMode(QGraphicsView::FullViewportUpdate);
        //setRenderHint(QPainter::Antialiasing);

        //setViewportUpdateMode(QGraphicsView::SmartViewportUpdate);

        setRenderHints(QPainter::Antialiasing | QPainter::SmoothPixmapTransform);

        timerId =0;
        nodeIndex = 0;
        insertNodeMode = 0;

        //setInteractiveMode(CREATING);
        setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        setDragMode(ScrollHandDrag); //panning

        setInteractive(true);

        createMenu();
    }

    class HitSocketInfo
    {
    public:

        HitSocketInfo(){}

        SocketItem * startStocketItem;
        SocketItem * endSocketItem;

        QPointF p1;
        QPointF p2;
    };

    HitSocketInfo hitselection;
    QPointF  prevPoint;
    QGraphicsLineItem * InteractiveLine;


    int timerId;
    bool createdConnection = false;

    SocketItem * getSocketAtPos(QPointF pos)
    {
        QList<QGraphicsItem*> items = scene()->items(pos);

        if(items.size()>0)
        {
            foreach( QGraphicsItem *item ,items)
            {
                if(endwith(typeid(*item).name(),"SocketItem") == 1) //safe guard check
                {
                    SocketItem * socket =  qgraphicsitem_cast<SocketItem*>(item);

                    if(socket)
                    {
                        if(_debug)
                        {
                            printf("SocketItem: %s\n",qPrintable(socket->socketNameItem->toPlainText()));
                        }

                        return socket;

                    }
                }
            }
        }

        return NULL;
    }



    void createInteractiveLine(QMouseEvent * event)
    {
        if(scene()->selectedItems().size()>0)
        {
            SocketItem * socket = getSocketAtPos(mapToScene( event->pos()));

            if(socket)
            {
                if(socket->getSocketType() == SocketItem::OutPut)
                {
                    InteractiveLine = new QGraphicsLineItem;
                    InteractiveLine->setZValue(-100);

                    createdConnection = true;

                    QPen pen;

                    pen.setWidthF(1.5f);
                    pen.setColor(Qt::cyan);
                    pen.setStyle(Qt::DashDotLine);
                    pen.setCapStyle(Qt::RoundCap);
                    pen.setJoinStyle(Qt::RoundJoin);

                    InteractiveLine->setPen(pen);

                    hitselection.startStocketItem =  socket;

                    if(_debug)
                    {
                        qDebug()<<"Socket Details:"<<socket<<"ScenePose:"<<socket->scenePos();
                    }

                    QLineF line(mapToScene( event->pos()), mapToScene(event->pos()));

                    InteractiveLine->setLine(line);

                    scene()->addItem(InteractiveLine);                   

                }               
            }           
        }
    }

    void updateInteractiveLine(QMouseEvent *event)
    {
        if(createdConnection)
        {
            if(InteractiveLine)
            {
                QLineF line = InteractiveLine->line();

                line.setP2( mapToScene( event->pos()) );

                InteractiveLine->setLine(line);
            }
        }
    }

    void removeConnection(ConnectionItem * con)
    {
        int index = connections.indexOf(con);

        if (index != -1)
        {
            connections.removeAt(index); //hopefully delete connector;
        }

    }

    void newConnection(QMouseEvent *event)
    {
        if(createdConnection)
        {
            if(InteractiveLine)
            {
                SocketItem * startSocketItem = getSocketAtPos( mapToScene( event->pos() ) );

                if( startSocketItem )
                {
                   if(_debug)
                       printf("Socket \n");

                    hitselection.endSocketItem =  startSocketItem;

                    /// handle illigal connections and create the right connection

                    if( hitselection.startStocketItem->ID != hitselection.endSocketItem->ID )
                    {
                        if(hitselection.endSocketItem->getConnections().size()==0)
                        {
                            if(hitselection.endSocketItem->getSocketDataType()== hitselection.startStocketItem->getSocketDataType()
                                    || hitselection.endSocketItem->getSocketDataType()== NODE_MULTI_DATA_TYPE)
                            {
                                NodeBaseItem * sitem = (NodeBaseItem *)hitselection.startStocketItem->parentItem();
                                NodeBaseItem * eitem = (NodeBaseItem *)hitselection.endSocketItem->parentItem();

                                if(sitem->ID != eitem->ID)
                                {
                                    createConnection();
                                }
                            }
                        }
                        else
                        {

                        }
                    }
                }

                scene()->removeItem(InteractiveLine);

                delete InteractiveLine;

                InteractiveLine  = NULL;

                createdConnection = false;
            }
        }
    }

    void createConnection()
    {
        if(hitselection.startStocketItem && hitselection.endSocketItem)
        {
            if(hitselection.startStocketItem->ID != hitselection.endSocketItem->ID)
            {
                ConnectionItem * connection  = new ConnectionItem(hitselection.startStocketItem,hitselection.endSocketItem);

                connection->p1 = hitselection.startStocketItem->scenePos();
                connection->p2 = hitselection.endSocketItem->scenePos();

                connection->setConnectionType(ConnectionItem::BEZIER);

                hitselection.startStocketItem->addConnection(connection);
                hitselection.endSocketItem->addConnection(connection);

                hitselection.startStocketItem->update();
                hitselection.endSocketItem->update();


                scene()->addItem(connection);

                connections.append(connection);

                if(_debug)
                {
                    printf("Connection Created \n");
                }
            }
        }
    }



    void mousePressEvent(QMouseEvent *event)
    {
        createInteractiveLine(event);
        QGraphicsView::mousePressEvent(event);
    }

    void mouseReleaseEvent(QMouseEvent *event)
    {
        newConnection(event);
        QGraphicsView::mouseReleaseEvent(event);
    }

    void mouseMoveEvent(QMouseEvent *event)
    {
        updateInteractiveLine(event);
        QGraphicsView::mouseMoveEvent(event);
    }

    void panView(QMouseEvent *event)
    {
        if(event->buttons() & Qt::LeftButton && event->modifiers()& Qt::AltModifier)
        {
            ///more work required

            QPointF c = QPointF(event->pos());

            QPointF  delta =  c - prevPoint;

            if(_debug)qDebug()<<"View Translate:"<<delta;

            //translate(delta.x(),delta.y());

            scrollContentsBy((int)delta.x(),(int)delta.y());

            prevPoint = c;

            //update();
        }
    }

    void StartTimer()
    {
        if (timerId)
            timerId = startTimer(1000 / 25);
    }

    void stopTimer()
    {
        killTimer(timerId);
        timerId = 0;
    }

    void centerOnNode(QGraphicsItem * centerItem)
    {
        centerOn(centerItem);
    }

    void fitNodesInView()
    {
        //fitInView()
    }

    void viewTransfromations()
    {
        this->setGeometry(QRect(50, 50, 400, 200));

        /*
        this->rotate();
        this->translate();
        this->scale();
        this->transform();
        */
    }

    void ZoomViewAtPoint(QWheelEvent* event)
    {
        double scaleFactor = 1.05;

        if (event->modifiers() & Qt::ControlModifier)
            scaleFactor += 0.3;

        if(event->delta() < 0)
            scaleFactor = 1.0 / scaleFactor;

        scale(scaleFactor, scaleFactor);

        centerOn( mapToScene(event->pos()) );
    }

    void scaleGraphicsView(qreal scaleFactor)
    {
        qreal factor = transform().scale(scaleFactor, scaleFactor).mapRect(QRectF(0, 0, 1, 1)).width();

        if (factor < 0.1 || factor > 1.5)
            return;

        scale(scaleFactor, scaleFactor);

        //navigatorView->scale(scaleFactor,scaleFactor);
        //navigatorView->fitInView(this->scene()->sceneRect());

    }

    void zoomView(QWheelEvent *event)
    {
        float s = pow( 2.0f ,-1.0f * event->delta() / 240.0f );

        scaleGraphicsView(s);

        //centerOn( mapToScene(event->pos()) );
    }


    void switchSelection(QKeyEvent * event)
    {
        if(event->modifiers()&Qt::ShiftModifier)
        {
           setDragMode(RubberBandDrag);
        }
        else
        {
            setDragMode(ScrollHandDrag);
        }
    }

    void resizeEvent(QResizeEvent *event)
    {
        /*
        navigator->resize(navigator->myscale *width(), navigator->myscale * height());
        navigator->move(width()*(1 - .15), height()*(1 - .15));

        */

       /*
        navigatorviewEntireScene->setViewScene(this->scene());
        navigatorviewEntireScene->resize(navigatorviewEntireScene->myscale *width(), navigatorviewEntireScene->myscale * height());
        navigatorviewEntireScene->move(width()*(1 - .15), height()*(1 - .15));

        navigatorView->setScene(this->scene());

        navigatorView->resize(.1 *width(), .1 * height());
        navigatorView->move(width()*(1 - .15), height()*(1 - .15));
        */
    }

    void wheelEvent(QWheelEvent *event)
    {
        zoomView(event);

        //ZoomViewAtPoint(event);

        QGraphicsView::wheelEvent(event);
    }



    void keyPressEvent(QKeyEvent *event)
    {
        switchSelection(event);
        processTabString(event);
        processAddItemMenu(event);

        QGraphicsView::keyPressEvent(event);
    }
    /*
    void dragEnterEvent(QDragEnterEvent *event)
    {
        qDebug()<<"drag Enter function:"<<event->mimeData()->text();

        for(int i=0;i<event->mimeData()->formats().size();i++)
        {
            //qDebug()<<"format"<<event->mimeData()->formats()[i];
        }

        if(event->mimeData()->hasText())
        {
            printf("drag Enter \n");
            event->accept();
        }

        QGraphicsView::dragEnterEvent(event);
    }

    */


    void dragMoveEvent(QDragMoveEvent *event)
    {
        event->accept(); //very important
    }


    void dropEvent(QDropEvent *event)
    {
        if(event->mimeData()->hasText())
        {
            addNode(event->mimeData()->text(),QCursor::pos());

            scene()->update();
        }

        QGraphicsView::dropEvent(event);
    }

    void timerEvent(QTimerEvent *event)
    {
        // compute node tree here
    }

private slots:
    void addNode()
    {
        addSelectedNode();
        if(_debug)printf("Node added\n");
    }

    void addSelectedNode()
    {
        if(lineEdit)
        {
            if(lineEdit->isVisible())
            {
                if(_debug)printf("\n");
                //QPointF p =  mapToScene(QCursor::pos());
                //addNode(lineEdit->text(),QPoint(p.x(),p.y()));
                addNode(lineEdit->text(),QCursor::pos());
                lineEdit->hide();

                if(_debug)printf("Selected Node:%s\n",qPrintable(lineEdit->text()));

            }
        }
    }

    void addNodeEx()
    {
        addSelectedNodeEx();
        if(_debug)printf("Node added\n");
    }


    void addSelectedNodeEx()
    {
        if(search)
        {
            if(_debug)printf("\n");

            //QPoint p = mapFromGlobal(QCursor::pos());


            addNode(search->getSelectedText(),QCursor::pos());
            lineEdit->hide();

            if(_debug)printf("Selected Node:%s\n",qPrintable(search->getSelectedText()));

        }
    }


    void addNode(QString nodename,QPoint p)
    {
        if(scene())
        {
            if(nodename.endsWith("Node Base"))
            {
                NodeBaseItem  *nodeitem = new NodeBaseItem();
                //node->setFlag(QGraphicsPolygonItem::ItemIsSelectable , true);
                //node->label->setPlainText(event->mimeData()->text());
                nodeitem->setNodeName("Vector Base");
                nodeitem->setToolTip("Node Vector Base");
                nodeitem->setPos(this->mapToScene(p));

                scene()->addItem(nodeitem);
                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Vector Compose"))
            {
                NodeVectorComposeItem  * nodeitem = new NodeVectorComposeItem();
                nodeitem->setNodeName("Vector Compose");
                nodeitem->setToolTip("Node Vector Compose");

                nodeitem->setPos(this->mapToScene(p));

                scene()->addItem(nodeitem);
                nodes.append(nodeitem);

            }
            else if(nodename.endsWith("Vector Normalized"))
            {
                NodeVectorNormalizedItem  * nodeitem = new NodeVectorNormalizedItem();
                nodeitem->setNodeName("Vector Normalized");
                nodeitem->setToolTip("Node Vector Normalized");

                nodeitem->setPos(this->mapToScene(p));

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);

                if(_debug)printf("Tested \n");

            }
            else if(nodename.endsWith("Vector Decompose"))
            {
                NodeVectorDeComposeItem  * nodeitem = new NodeVectorDeComposeItem();
                nodeitem->setNodeName("Vector Decompose");
                nodeitem->setToolTip("Node Vector Decompose");

                nodeitem->setPos(this->mapToScene(p));


                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Float Value"))
            {
                NodeFloatItem  * nodeitem = new NodeFloatItem();

                nodeitem->setPos(this->mapToScene(p));
                nodeitem->setNodeName("Float Value");
                nodeitem->setToolTip("Node Float Value");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);

            }

            else if(nodename.endsWith("Vector Addition"))
            {
                NodeVectorAddItem  * nodeitem = new NodeVectorAddItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Vector Addition");
                nodeitem->setToolTip("Node Vector Add");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);

            }
            else if(nodename.endsWith("Vector Subtraction"))
            {
                NodeVectorSubtractionItem  * nodeitem = new NodeVectorSubtractionItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Vector Subtraction");
                nodeitem->setToolTip("Node Vector Sub");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);

            }
            else if(nodename.endsWith("Vector Cross"))
            {
                NodeVectorCrossItem  * nodeitem = new NodeVectorCrossItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Vector Cross");
                nodeitem->setToolTip("Node Vector Cross");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);

            }
            else if(nodename.endsWith("Vector Dot"))
            {
                NodeVectorDotItem  * nodeitem = new NodeVectorDotItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Vector Dot");
                nodeitem->setToolTip("Node Vector Dot");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);

            }
            else if(nodename.endsWith("Vector Length"))
            {
                NodeVectorLengthItem  * nodeitem = new NodeVectorLengthItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Vector Length");
                nodeitem->setToolTip("Node Vector Length");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Vector Random"))
            {
                NodeVectorRandomItem  * nodeitem = new NodeVectorRandomItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Vector Random");
                nodeitem->setToolTip("Node Vector Random");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Vector Distance"))
            {
                NodeVectorDistanceItem  * nodeitem = new NodeVectorDistanceItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Vector Distance");
                nodeitem->setToolTip("Node Vector Distance");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Vector Scalar"))
            {
                NodeVectorScalarItem  * nodeitem = new NodeVectorScalarItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Vector Scalar");
                nodeitem->setToolTip("Node Vector Scalar");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Vector Reflect"))
            {
            }
            else if(nodename.endsWith("Vector Refract"))
            {
            }
            else if(nodename.endsWith("Vector Project"))
            {
            }
            else if(nodename.endsWith("Vector Orthogonolize"))
            {

            }
            else if(nodename.endsWith("Description Note"))
            {
                NodeDescriptionNoteItem  * nodeitem = new NodeDescriptionNoteItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Description Note");
                nodeitem->setToolTip("Node Description Note");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);

                /*
                 ArithmeticNodeList.append(QString("Add"));
                 ArithmeticNodeList.append(QString("Subtract"));
                 ArithmeticNodeList.append(QString("Multiply"));
                 ArithmeticNodeList.append(QString("Divide"));
                */
            }
            else if(nodename.endsWith("Socket Preview"))
            {
                NodeSocketPreviewItem  * nodeitem = new NodeSocketPreviewItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Socket Preview");
                nodeitem->setToolTip("Node Socket Preview");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);

            }
            else if(nodename.endsWith("Add"))
            {
                NodeFloatAddItem  * nodeitem = new NodeFloatAddItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Add");
                nodeitem->setToolTip("Node Add");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Subtract"))
            {
                NodeFloatSubItem  * nodeitem = new NodeFloatSubItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Subtract");
                nodeitem->setToolTip("Node Subtract");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Multiply"))
            {
                NodeFloatMultiplyItem  * nodeitem = new NodeFloatMultiplyItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Multiply");
                nodeitem->setToolTip("Node Multiply");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Divide"))
            {
                NodeFloatDivideItem * nodeitem = new NodeFloatDivideItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Divide");
                nodeitem->setToolTip("Node Divide");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Float Random"))
            {
                NodeFloatRandomItem * nodeitem = new NodeFloatRandomItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Float Random");
                nodeitem->setToolTip("Node Float Random");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Float PIE"))
            {
                NodeFloatPIEItem * nodeitem = new NodeFloatPIEItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Float PIE");
                nodeitem->setToolTip("Node Float PIE");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Float E"))
            {
                NodeFloatEItem * nodeitem = new NodeFloatEItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Float E");
                nodeitem->setToolTip("Node Float E");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Cos"))
            {
                NodeMathCosItem * nodeitem = new NodeMathCosItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Cos");
                nodeitem->setToolTip("Node Cos");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Cosh"))
            {
                NodeMathCosHItem * nodeitem = new NodeMathCosHItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Cosh");
                nodeitem->setToolTip("Node Cosh");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Acos"))
            {
                NodeMathACosItem * nodeitem = new NodeMathACosItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Acos");
                nodeitem->setToolTip("Node Acos");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Sin"))
            {
                NodeMathSinItem * nodeitem = new NodeMathSinItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Sin");
                nodeitem->setToolTip("Node Sin");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Sinh"))
            {
                NodeMathSinHItem * nodeitem = new NodeMathSinHItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Sinh");
                nodeitem->setToolTip("Node Sinh");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Asin"))
            {
                NodeMathASinItem * nodeitem = new NodeMathASinItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Asin");
                nodeitem->setToolTip("Node Asin");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Tan"))
            {
                NodeMathTanItem * nodeitem = new NodeMathTanItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Tan");
                nodeitem->setToolTip("Node Tan");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Tanh"))
            {
                NodeMathTanHItem * nodeitem = new NodeMathTanHItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Tanh");
                nodeitem->setToolTip("Node Tanh");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Atan"))
            {
                NodeMathATanItem * nodeitem = new NodeMathATanItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Atan");
                nodeitem->setToolTip("Node Atan");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Log"))
            {
                NodeMathLogItem * nodeitem = new NodeMathLogItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Log");
                nodeitem->setToolTip("Node Log");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Pow"))
            {
                NodeMathPowItem * nodeitem = new NodeMathPowItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Pow");
                nodeitem->setToolTip("Node Pow");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Sqrt"))
            {
                NodeMathSqrtItem * nodeitem = new NodeMathSqrtItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Sqrt");
                nodeitem->setToolTip("Node Sqrt");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Abs"))
            {
                NodeMathAbsItem * nodeitem = new NodeMathAbsItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Abs");
                nodeitem->setToolTip("Node Abs");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Floor"))
            {
                NodeMathFloorItem * nodeitem = new NodeMathFloorItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Floor");
                nodeitem->setToolTip("Node Floor");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Ceil"))
            {
                NodeMathCeilItem * nodeitem = new NodeMathCeilItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Ceil");
                nodeitem->setToolTip("Node Ceil");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Round"))
            {
                NodeMathRoundItem * nodeitem = new NodeMathRoundItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Round");
                nodeitem->setToolTip("Node Round");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Modulus"))
            {
                NodeMathModulusItem * nodeitem = new NodeMathModulusItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Modulus");
                nodeitem->setToolTip("Node Modulus");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Exponent"))
            {
                NodeMathExpItem * nodeitem = new NodeMathExpItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Exponent");
                nodeitem->setToolTip("Node Exponent");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }            
            else if(nodename.endsWith("Description Note"))
            {
                NodeDescriptionNoteItem * nodeitem = new NodeDescriptionNoteItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Description Note");
                nodeitem->setToolTip("Node Description Note");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Equals"))
            {
                NodeValueEqualItem * nodeitem = new NodeValueEqualItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Equals");
                nodeitem->setToolTip("Node Equals");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("LessThan"))
            {
                NodeValueLessThanItem * nodeitem = new NodeValueLessThanItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Less Than");
                nodeitem->setToolTip("Node Less Than");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("GreaterThan"))
            {
                NodeValueGreaterThanItem * nodeitem = new NodeValueGreaterThanItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Greater Than");
                nodeitem->setToolTip("Node Greater Than");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }

            else if(nodename.endsWith("Less or Equal"))
            {
                NodeValueLessOrEqualItem * nodeitem = new NodeValueLessOrEqualItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Less or Equal");
                nodeitem->setToolTip("Node Less or Equal");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Greater or Equal"))
            {
                NodeValueGreaterOrEqualItem * nodeitem = new NodeValueGreaterOrEqualItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Greater or Equal");
                nodeitem->setToolTip("Node Greater or Equal");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
            else if(nodename.endsWith("Time"))
            {
                NodeTimeItem * nodeitem = new NodeTimeItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("Time");
                nodeitem->setToolTip("Node Time");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);

            }
            else if(nodename.endsWith("If Else"))
            {
                NodeIFlItem * nodeitem = new NodeIFlItem();

                nodeitem->setPos(this->mapToScene(p));

                nodeitem->setNodeName("If Else");
                nodeitem->setToolTip("Node If Else");

                scene()->addItem(nodeitem);

                nodes.append(nodeitem);
            }
        }
    }
};

class GraphicsScene : public QGraphicsScene
{
    Q_OBJECT

    GridItem * grid;

    QMenu menu;

    QIcon icon;

    bool _debug = false;

public:

    void setDebugging(bool print = false)
    {
      _debug = print;
    }

    GraphicsScene(QObject *parent =0):QGraphicsScene(parent)
    {
        //QGraphicsScene *g = new QGraphicsScene()

        //grid = new Grid;

        //addItem(grid);

        setSceneRect(QRectF(0, 0, 7000, 7000));

        createContextMenu();


    }

    ~GraphicsScene()
    {
        delete grid;

    }

    void createContextMenu()
    {
        icon = QIcon(QString(":/cubeomniverse.svg"));

        QObject * object  = new QObject(this);

        QAction * nodeColorAction  = new QAction(icon,QString("Color") ,object);
        QAction * nodeCopyAction   = new QAction(icon,QString("Copy")  ,object);
        QAction * nodeRenameAction = new QAction(icon,QString("Rename"),object);
        QAction * nodeExpandAction = new QAction(icon,QString("Expand"),object);
        QAction * deleteNodeAction     = new QAction(icon,QString("Delete Node"),object);
        QAction * deleteConnectionAction     = new QAction(icon,QString("Delete Connection"),object);


        connect(deleteNodeAction,SIGNAL(triggered()),this,SLOT(deleteNode()));
        connect(deleteConnectionAction,SIGNAL(triggered()),this,SLOT(deleteThisConnection()));

        menu.addAction(nodeColorAction);
        menu.addAction(nodeCopyAction);
        menu.addAction(nodeRenameAction);
        menu.addAction(nodeExpandAction);
        menu.addAction(deleteNodeAction);
        menu.addAction(deleteConnectionAction);

        menu.addAction(icon,QString("Resets"));
        menu.addAction(icon,QString("Mute"));
        menu.addAction(icon,QString("Hide Inputs"));
        menu.addAction(icon,QString("Hide outputs"));
        menu.addAction(icon,QString("Properties"));

        QFile file(":/glowBlue.stylesheet");

        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QByteArray  style =file.readAll();
            menu.setStyleSheet(style);
            file.close();

        }
    }

    void contextMenuEvent(QGraphicsSceneContextMenuEvent *event)
    {
        QPoint p =  QCursor::pos();

        //this->itemAt(QPointF(p))

        if(selectedItems().size()>0)
        {
            QAction *selectedAction = menu.exec(p);

            if ( selectedAction != 0 )
            {
                  printf("Clicked Action:\n");
            }
        }

        QGraphicsScene::contextMenuEvent(event);
    }

public slots:

    void deleteThisConnection()
    {
        QList<QGraphicsItem*> items =  this->selectedItems();

        foreach(QGraphicsItem* item,items)
        {
            ConnectionItem * con =(ConnectionItem *)item;

            if(con)
            {

                if(con->getStartItem())
                {
                    SocketItem * socket = con->getStartItem();

                    if(socket)
                    {
                        socket->removeConnection(con);
                        socket->update();
                    }
                }

                if(con->getEndItem())
                {
                    SocketItem * socket = con->getEndItem();

                    if(socket)
                    {
                        socket->removeConnection(con);
                        socket->update();
                    }
                }


                if(this)
                {
                    this->removeItem(con);

                    QList<QGraphicsView*> views= this->views();

                    NodeCollection * view = (NodeCollection*)views[views.size()-1];

                    view->removeConnection(con);



                    delete con;

                    this->update();

                    if(_debug)qDebug()<<"Connections:"<<view->getCOnnections().size();
                }
            }
        }

        if(_debug)printf("Connection deleted");
    }

    void deleteNode()
    {

        if(this->selectedItems().size()>0)
        {
            foreach(QGraphicsItem * item ,this->selectedItems())
            {
                if(item)
                {
                    NodeBaseItem * nbi = (NodeBaseItem *)item;

                    if(nbi)
                    {

                        foreach(SocketItem * socket , nbi->inputs)
                        {
                            foreach(ConnectionItem * connection , socket->getConnections())
                            {
                                SocketItem * s = connection->getStartItem();
                                SocketItem * e = connection->getEndItem();

                                s->removeConnection(connection);
                                e->removeConnection(connection);

                                s->update();
                                e->update();

                                this->removeItem(connection);

                                delete connection;
                            }

                            socket->removeConnections();
                            socket->update();
                        }

                        foreach(SocketItem * socket , nbi->outputs)
                        {
                            foreach(ConnectionItem * connection , socket->getConnections())
                            {
                                SocketItem * s = connection->getStartItem();
                                SocketItem * e = connection->getEndItem();

                                s->removeConnection(connection);
                                e->removeConnection(connection);

                                s->update();
                                e->update();

                                this->removeItem(connection);


                                delete connection;
                            }

                            socket->removeConnections();
                            socket->update();
                        }
                    }

                    this->removeItem(item);

                    delete item;

                    update();

                    if(_debug)printf("Item deleted \n");

                }

            }

        }

    }

    void keyPressEvent(QKeyEvent * event)
    {
        if(event->modifiers()&Qt::AltModifier && event->key() == Qt::Key_Delete)
        {
            deleteNode();
        }


        //QGraphicsScene::keyPressEvent(event);
    }
};

class NodesConsole : public QListView
{
    QStringListModel * model;
    QStringList stringList;

public:

    NodesConsole(QWidget* parent =0):QListView(parent)
    {
        model = new QStringListModel;

        stringList.append(QString(">>Node tree Console Ready"));
        stringList.append(QString(">> Start Time:" + QTime::currentTime().toString()));

        this->setModel(model);

        model->setStringList(stringList);
    }
    ~NodesConsole()
    {
        delete model;
    }

    void printToConsole(QString message)
    {
        stringList.append(">>"+message);
    }

    void clearConsole()
    {
        foreach(QString str, stringList)
        {
           stringList.removeAll(str);
        }

        stringList.clear();
    }

};


/*

class nodeTreeXml
{
    QDomDocument * doc;

    QFile *file;

    QString xmlfileEmbedded;

    QXmlReader *xmlreader;

public:

    class ParentChildren
    {
    public:
        ParentChildren(){}

        QString name;

        QStringList childrenList;
    };

     QList<ParentChildren> rootNodesLists;


    nodeTreeXml()
    {
        doc  = new QDomDocument("NodeTree");

        ReadNodeTree();

        printAllNodeNames();
    }

    void printAllNodeNames()
    {
        printf("Parent Node: \n\n");

        for(int i=0;i<rootNodesLists.size();i++)
        {
            printf("Parent Node: %s \n",qPrintable(rootNodesLists[i].name));


            for(int j=0;j<rootNodesLists[i].childrenList.size();j++)
            {
                printf("child  Node: %s \n",qPrintable(rootNodesLists[i].childrenList[j]));

            }
        }

    }

    void ReadNodeTree()
    {

        file = new QFile(":/cubeOmniverseNodetree.xml");//file must be added in the resource file

        printf("Reading xml file %s\n",qPrintable(file->fileName()));

        if (file->open(QIODevice::ReadOnly)==false)
        {
             printf("Reading xml file failed \n");

             return;
        }

        if (doc->setContent(file)== false)
        {
            file->close();

            return;
        }

         file->close();

         printf("Parsing xml content \n");

         // print out the element names of all elements that are direct children
         // of the outermost element.
         QDomElement docElem = doc->documentElement();

         printf("Root Node: %s \n",qPrintable(docElem.nodeName()));

         QDomNodeList parentNodelist = docElem.childNodes();

         for(int i =0;i<parentNodelist.count();i++)
         {
             QDomNode parentNode = parentNodelist.at(i);

             printf("%s:\n",qPrintable(parentNode.nodeName()));

             if(parentNode.nodeName()=="copyright")
             {

             }

             if(parentNode.nodeName()=="NodeTypes")
             {

             }

             if(parentNode.nodeName()=="NodeTree")
             {
                 QDomNodeList childNodelist = parentNode.childNodes();

                 for(int child=0;child<childNodelist.count();child++)
                 {
                     QDomNode childnode = childNodelist.at(child);

                     printf("%s \n",qPrintable(childnode.nodeName()));


                     ParentChildren parentChildren;
                     parentChildren.name = childnode.nodeName();



                     if(childnode.hasAttributes())
                     {
                         QDomElement element = childnode.toElement();

                         for(int attributeIndex=0;attributeIndex<element.attributes().count();attributeIndex++)
                         {
                             QDomAttr attribute = element.attributeNode(QString("name"));

                             printf("Has attributes: %s \n",qPrintable(attribute.value()));
                         }
                     }


                     QDomNode sibling = childnode.firstChild();

                     while(sibling.isNull() == false)
                     {
                         QDomElement element = sibling.toElement();

                         if(element.isNull() == false)
                         {
                             QDomAttr attribute  = element.attributeNode(QString("name"));
                             QDomAttr attribute1 = element.attributeNode(QString("class"));

                             printf("Sibling Name: %s \n",qPrintable(element.nodeName()));

                             printf("Attribute Name: %s \n",qPrintable(attribute.value()));
                             printf("Attribute Class: %s \n",qPrintable(attribute1.value()));

                             parentChildren.childrenList.append(attribute.value());

                         }

                         sibling = sibling.nextSibling();
                     }


                     rootNodesLists.append(parentChildren);
                 }
             }
         }
    }
};
*/

class nodeTreeEditor : public QWidget
{
    Q_OBJECT

public:

    NodeCollection * graphicsview;

    GraphicsScene * scene;

    //NodesListView * listview;

    QSearchEx * listview;

    TimeLineWidget * timeline;

    QPropertiesWidget* propertiesWidget;
    //NodesConsole *console;



    nodeTreeEditor(QWidget * parent = 0):QWidget(parent)
    {
        setTheme();
        setTitleDetails();

        // Widget layout and child widgets:
        QVBoxLayout * layout   = new QVBoxLayout;
        QSplitter * splitter   = new QSplitter;

        splitter->setOrientation(Qt::Vertical);
        propertiesWidget = new QPropertiesWidget;


        graphicsview  = new NodeCollection;
        scene         = new GraphicsScene;
        timeline      = new TimeLineWidget;
        //listview      = new NodesListView;
        listview = new QSearchEx(graphicsview->allnodes);


        //console  = new NodesConsole;
        graphicsview->setScene(scene);
        scene->setStickyFocus(true);

        /*


        QIcon  icon(QString(":/cubeomniverse.svg"));

        foreach(QString nodename,graphicsview->allnodes)
        {
            listview->addItem(new QListWidgetItem(icon,nodename));
        }

        listview->setViewMode(QListView::IconMode);
        listview->setMaximumHeight(150);
        */

        QSplitter * hsplitter = new QSplitter;
        hsplitter->setOrientation(Qt::Horizontal);

        hsplitter->addWidget(graphicsview);
        hsplitter->addWidget(propertiesWidget);

        splitter->addWidget(hsplitter);

        splitter->addWidget(listview);
        //splitter->addWidget(console);
        splitter->addWidget(timeline);





        layout->addWidget(splitter);
        setLayout(layout);

    }

    ~nodeTreeEditor()
    {
        delete scene;
        delete graphicsview;
        delete listview;
        delete timeline;
        delete propertiesWidget;
    }

public slots:
    void compute()
    {

    }
    /*

    void selectionChangedSlot(const QItemSelection & , const QItemSelection & )
     {
         //get the text of the selected item
         const QModelIndex index = listview->selectionModel()->currentIndex();

         QString selectedText = index.data(Qt::DisplayRole).toString();

         qDebug()<<"Selection Change:"<<selectedText;

     }
    */

public:

    void setTheme()
    {
        //QFile file(":/metro.stylesheet");

        //QFile file(":/test.stylesheet");
         QFile file(":/glowBlue.stylesheet");
        //QFile file(":/darkorange.stylesheet");
        //QFile file(":/levefour.stylesheet");

        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
           setStyleSheet(file.readAll());
           file.close();
        }

        setWindowIcon(QIcon(":/cubeomniverse.svg"));

    }

    void setTitleDetails()
    {
       setWindowTitle(QString("CUBE Omniverse: node tree"));
    }
};



//#include
#include "main.moc"
//vtable problems solved
//If a moc file is missing, rerun qmake and it should work.
//main menu->Build->Run qmake

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    a.setAttribute( Qt::AA_UseDesktopOpenGL );



    qsrand(QDateTime().currentDateTime().time().msec());


    /*

    QWidget * mainw  = new QWidget;

    QVBoxLayout *layout = new QVBoxLayout;
    QSplitter * splitter = new QSplitter;
    splitter->setOrientation(Qt::Horizontal);


    QWidget * w  = new QWidget;
    */




    nodeTreeEditor *nte = new nodeTreeEditor;
    nte->showMaximized();
    //QScopedPointer<nodeTreeEditor>nte(new nodeTreeEditor());

    //nte.data()->showMaximized();




    //TimeLineWidget * tl =   new TimeLineWidget;
    //tl->show();



    /*

    splitter->addWidget(w);
    splitter->addWidget(&nte);
    mainw->setLayout(layout);
    mainw->showMaximized();
    */


    return a.exec();
}
