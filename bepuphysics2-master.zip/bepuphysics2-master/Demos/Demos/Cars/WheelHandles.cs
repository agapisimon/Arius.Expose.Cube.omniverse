﻿namespace Demos.Demos.Cars
{
    struct WheelHandles
    {
        public int Wheel;
        public int SuspensionSpring;
        public int SuspensionTrack;
        public int Hinge;
        public int Motor;
    }
}